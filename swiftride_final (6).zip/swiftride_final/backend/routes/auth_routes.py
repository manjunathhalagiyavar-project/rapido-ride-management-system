"""
Authentication routes (No-OTP direct login):
  POST /api/register   — register with name + email/phone
  POST /api/login      — login with email or Indian phone number
  POST /api/logout
  GET  /api/me
  GET  /api/profile/<user_id>
"""

import re
from flask import Blueprint, request, jsonify, session

from backend.extensions import db
from backend.models.models import User

auth_bp = Blueprint("auth", __name__, url_prefix="/api")


# ─── Helpers ─────────────────────────────────────────────────────────────────

def _bad(msg, code=400):
    return jsonify({"success": False, "message": msg}), code

def _ok(msg, **kwargs):
    return jsonify({"success": True, "message": msg, **kwargs})

def _valid_email(email):
    return re.match(r'^[^@\s]+@[^@\s]+\.[^@\s]+$', email) is not None

def _valid_indian_phone(phone):
    """Accept 10-digit Indian numbers, optionally prefixed with +91 or 91."""
    cleaned = re.sub(r'[\s\-()]', '', phone)
    return re.match(r'^(\+91|91)?[6-9]\d{9}$', cleaned) is not None

def _normalise_phone(phone):
    cleaned = re.sub(r'[\s\-()]', '', phone)
    # Strip country code prefix
    cleaned = re.sub(r'^(\+91|91)', '', cleaned)
    return cleaned


# ─── Register ────────────────────────────────────────────────────────────────

@auth_bp.route("/register", methods=["POST"])
def register():
    """
    Body: { name, contact_type: "email"|"phone", email?, phone? }
    Direct registration — no OTP required.
    """
    try:
        data         = request.get_json(silent=True) or {}
        name         = (data.get("name") or "").strip()
        contact_type = data.get("contact_type", "email")
        email        = (data.get("email") or "").strip().lower() or None
        phone        = (data.get("phone") or "").strip() or None

        if not name:
            return _bad("Full name is required.")

        if contact_type == "email":
            if not email:
                return _bad("Email address is required.")
            if not _valid_email(email):
                return _bad("Please enter a valid email address.")
            if User.query.filter_by(email=email).first():
                return _bad("An account with this email already exists.")
            user = User(name=name, email=email, phone=None, verified=True)

        elif contact_type == "phone":
            if not phone:
                return _bad("Phone number is required.")
            if not _valid_indian_phone(phone):
                return _bad("Please enter a valid 10-digit Indian mobile number (starting with 6-9).")
            phone = _normalise_phone(phone)
            if User.query.filter_by(phone=phone).first():
                return _bad("An account with this phone number already exists.")
            user = User(name=name, email=None, phone=phone, verified=True)

        else:
            return _bad("contact_type must be 'email' or 'phone'.")

        db.session.add(user)
        db.session.commit()

        session["user_id"]   = user.id
        session["user_name"] = user.name
        session.permanent    = True

        return _ok("Registration successful! Welcome to Rapido.", user=user.to_dict())

    except Exception as e:
        db.session.rollback()
        import logging, traceback
        logging.getLogger(__name__).error("Register error: %s\n%s", e, traceback.format_exc())
        return _bad(f"Registration failed: {str(e)}", 500)


# ─── Login ───────────────────────────────────────────────────────────────────

@auth_bp.route("/login", methods=["POST"])
def login():
    """
    Body: { contact, contact_type: "email"|"phone" }
    Direct login — user must exist. No OTP required.
    """
    try:
        data         = request.get_json(silent=True) or {}
        contact      = (data.get("contact") or "").strip()
        contact_type = data.get("contact_type", "email")

        if not contact:
            return _bad("Email or phone number is required.")

        if contact_type == "email":
            contact = contact.lower()
            if not _valid_email(contact):
                return _bad("Please enter a valid email address.")
            user = User.query.filter_by(email=contact).first()
            if not user:
                return _bad("No account found with this email. Please register first.")

        elif contact_type == "phone":
            if not _valid_indian_phone(contact):
                return _bad("Please enter a valid 10-digit Indian mobile number (starting with 6-9).")
            contact = _normalise_phone(contact)
            user = User.query.filter_by(phone=contact).first()
            if not user:
                return _bad("No account found with this phone number. Please register first.")

        else:
            return _bad("contact_type must be 'email' or 'phone'.")

        session["user_id"]   = user.id
        session["user_name"] = user.name
        session.permanent    = True

        return _ok("Login successful!", user=user.to_dict())

    except Exception as e:
        import logging, traceback
        logging.getLogger(__name__).error("Login error: %s\n%s", e, traceback.format_exc())
        return _bad(f"Login failed: {str(e)}", 500)


# ─── Logout ──────────────────────────────────────────────────────────────────

@auth_bp.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return _ok("Logged out successfully.")


# ─── Current User ────────────────────────────────────────────────────────────

@auth_bp.route("/me", methods=["GET"])
def me():
    user_id = session.get("user_id")
    if not user_id:
        return _bad("Not authenticated.", 401)
    user = User.query.get(user_id)
    if not user:
        session.clear()
        return _bad("User not found.", 401)
    return _ok("Authenticated.", user=user.to_dict())


# ─── Profile — any registered user by ID ─────────────────────────────────────

@auth_bp.route("/profile/<int:user_id>", methods=["GET"])
def profile(user_id):
    """Return public profile of a registered user."""
    user_id_sess = session.get("user_id")
    if not user_id_sess:
        return _bad("Not authenticated.", 401)
    user = User.query.get(user_id)
    if not user:
        return _bad("User not found.", 404)
    return _ok("Profile fetched.", user=user.to_dict())


# ─── Admin Login ──────────────────────────────────────────────────────────────
# Restricted to a single hardcoded admin account only.

ADMIN_EMAIL    = "manjunathhalagiyavar@gmail.com"
ADMIN_PHONE    = "9535869995"
ADMIN_PASSWORD = "Manju@282005"

@auth_bp.route("/admin/login", methods=["POST"])
def admin_login():
    data     = request.get_json(silent=True) or {}
    contact  = (data.get("contact") or "").strip().lower()
    password = (data.get("password") or "").strip()

    if not contact or not password:
        return _bad("Contact and password are required.")

    # Normalise phone
    contact_norm = re.sub(r'^(\+91|91)', '', re.sub(r'[\s\-()]', '', contact))

    allowed = contact == ADMIN_EMAIL or contact_norm == ADMIN_PHONE
    if not allowed or password != ADMIN_PASSWORD:
        return _bad("Invalid admin credentials.", 401)

    session["admin_logged_in"] = True
    session["admin_contact"]   = contact
    session.permanent = True
    return _ok("Admin login successful.", admin={"contact": contact})


@auth_bp.route("/admin/logout", methods=["POST"])
def admin_logout():
    session.pop("admin_logged_in", None)
    session.pop("admin_contact", None)
    return _ok("Admin logged out.")


@auth_bp.route("/admin/me", methods=["GET"])
def admin_me():
    if not session.get("admin_logged_in"):
        return _bad("Not authenticated as admin.", 401)
    return _ok("Authenticated.", admin={"contact": session.get("admin_contact")})
