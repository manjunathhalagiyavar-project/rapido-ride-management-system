"""
SQLAlchemy models — Rapido Clone (Full Feature Set)
New tables: user_wallets, wallet_transactions, promo_codes, promo_usages,
  ride_ratings, ride_stops, scheduled_rides, ride_pools,
  captain_bonuses, fraud_logs, sos_alerts
"""
from datetime import datetime
from backend.extensions import db
import hashlib, os

class User(db.Model):
    __tablename__ = "users"
    id         = db.Column(db.Integer, primary_key=True)
    name       = db.Column(db.String(100), nullable=False)
    email      = db.Column(db.String(150), unique=True, nullable=True)
    phone      = db.Column(db.String(15),  unique=True, nullable=True)
    verified   = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    rides    = db.relationship("Ride", backref="user", lazy=True)
    wallet   = db.relationship("UserWallet", backref="user", uselist=False, lazy=True)
    ratings  = db.relationship("RideRating", backref="user", lazy=True)
    def to_dict(self):
        return {"id":self.id,"name":self.name,"email":self.email,"phone":self.phone,"verified":self.verified,"created_at":self.created_at.isoformat()}

class Driver(db.Model):
    __tablename__ = "drivers"
    id        = db.Column(db.Integer, primary_key=True)
    name      = db.Column(db.String(100), nullable=False)
    email     = db.Column(db.String(150), unique=True, nullable=True)
    phone     = db.Column(db.String(15),  nullable=False, unique=True)
    password_hash = db.Column(db.String(128), nullable=True)
    vehicle        = db.Column(db.String(100), nullable=False)
    vehicle_type   = db.Column(db.String(50),  default="Bike")
    vehicle_model  = db.Column(db.String(100), nullable=True)
    vehicle_color  = db.Column(db.String(50),  nullable=True)
    lat       = db.Column(db.Float, nullable=False, default=15.3647)
    lng       = db.Column(db.Float, nullable=False, default=75.1240)
    available = db.Column(db.Boolean, default=False)
    is_online = db.Column(db.Boolean, default=False)
    rating    = db.Column(db.Float, default=4.5)
    total_ratings           = db.Column(db.Integer, default=0)
    acceptance_rate         = db.Column(db.Float, default=100.0)
    total_rides_completed   = db.Column(db.Integer, default=0)
    idle_since              = db.Column(db.DateTime, nullable=True)
    verification_status = db.Column(db.String(20), default="pending")
    rejection_reason    = db.Column(db.String(500), nullable=True)
    verified_at         = db.Column(db.DateTime, nullable=True)
    doc_license   = db.Column(db.String(255), nullable=True)
    doc_rc        = db.Column(db.String(255), nullable=True)
    doc_insurance = db.Column(db.String(255), nullable=True)
    doc_photo     = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    rides    = db.relationship("Ride", backref="driver", lazy=True)
    bonuses  = db.relationship("CaptainBonus", backref="driver", lazy=True)
    def set_password(self, pw):
        salt=os.urandom(16).hex(); h=hashlib.sha256((salt+pw).encode()).hexdigest(); self.password_hash=f"{salt}:{h}"
    def check_password(self, pw):
        if not self.password_hash: return False
        salt,h=self.password_hash.split(":",1); return hashlib.sha256((salt+pw).encode()).hexdigest()==h
    def to_dict(self):
        return {"id":self.id,"name":self.name,"email":self.email,"phone":self.phone,"vehicle":self.vehicle,"vehicle_type":self.vehicle_type,"vehicle_model":self.vehicle_model,"vehicle_color":self.vehicle_color,"lat":self.lat,"lng":self.lng,"available":self.available,"is_online":self.is_online,"rating":self.rating,"total_ratings":self.total_ratings,"acceptance_rate":self.acceptance_rate,"total_rides_completed":self.total_rides_completed,"verification_status":self.verification_status,"rejection_reason":self.rejection_reason,"doc_license":self.doc_license,"doc_rc":self.doc_rc,"doc_insurance":self.doc_insurance,"doc_photo":self.doc_photo,"created_at":self.created_at.isoformat() if self.created_at else None}

class RidePool(db.Model):
    __tablename__ = "ride_pools"
    id           = db.Column(db.Integer, primary_key=True)
    driver_id    = db.Column(db.Integer, db.ForeignKey("drivers.id"), nullable=True)
    vehicle_type = db.Column(db.String(50), default="Auto")
    route_key    = db.Column(db.String(100), nullable=True)
    max_seats    = db.Column(db.Integer, default=2)
    seats_taken  = db.Column(db.Integer, default=0)
    status       = db.Column(db.String(20), default="open")
    created_at   = db.Column(db.DateTime, default=datetime.utcnow)
    rides = db.relationship("Ride", backref="pool", foreign_keys="Ride.pool_id", lazy=True)
    def to_dict(self):
        return {"id":self.id,"driver_id":self.driver_id,"vehicle_type":self.vehicle_type,"max_seats":self.max_seats,"seats_taken":self.seats_taken,"status":self.status,"created_at":self.created_at.isoformat() if self.created_at else None}

class Ride(db.Model):
    __tablename__ = "rides"
    id         = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    driver_id  = db.Column(db.Integer, db.ForeignKey("drivers.id"), nullable=True)
    pickup_name  = db.Column(db.String(255), nullable=False)
    pickup_lat   = db.Column(db.Float, nullable=False)
    pickup_lng   = db.Column(db.Float, nullable=False)
    drop_name    = db.Column(db.String(255), nullable=False)
    drop_lat     = db.Column(db.Float, nullable=False)
    drop_lng     = db.Column(db.Float, nullable=False)
    vehicle_type  = db.Column(db.String(50), default="Bike")
    distance_km   = db.Column(db.Float, nullable=True)
    duration_min  = db.Column(db.Float, nullable=True)
    fare          = db.Column(db.Float, nullable=True)
    surge_multiplier = db.Column(db.Float, default=1.0)
    payment_method = db.Column(db.String(20), default="cash")
    promo_code     = db.Column(db.String(30), nullable=True)
    discount       = db.Column(db.Float, default=0.0)
    final_fare     = db.Column(db.Float, nullable=True)
    paid           = db.Column(db.Boolean, default=False)
    status         = db.Column(db.String(20), default="requested")
    ride_pin       = db.Column(db.String(4),  nullable=True)
    share_token    = db.Column(db.String(64), nullable=True)
    reassign_count    = db.Column(db.Integer, default=0)
    declined_drivers  = db.Column(db.Text, nullable=True)
    pool_id = db.Column(db.Integer, db.ForeignKey("ride_pools.id"), nullable=True)
    requested_at = db.Column(db.DateTime, default=datetime.utcnow)
    accepted_at  = db.Column(db.DateTime, nullable=True)
    started_at   = db.Column(db.DateTime, nullable=True)
    completed_at = db.Column(db.DateTime, nullable=True)
    stops    = db.relationship("RideStop",   backref="ride", lazy=True, cascade="all, delete-orphan")
    rating   = db.relationship("RideRating", backref="ride", uselist=False, lazy=True)
    messages = db.relationship("RideMessage", backref="ride", lazy=True, cascade="all, delete-orphan")
    def to_dict(self):
        return {"id":self.id,"user_id":self.user_id,"driver_id":self.driver_id,"pickup_name":self.pickup_name,"pickup_lat":self.pickup_lat,"pickup_lng":self.pickup_lng,"drop_name":self.drop_name,"drop_lat":self.drop_lat,"drop_lng":self.drop_lng,"vehicle_type":self.vehicle_type,"distance_km":self.distance_km,"duration_min":self.duration_min,"fare":self.fare,"surge_multiplier":self.surge_multiplier,"payment_method":self.payment_method,"promo_code":self.promo_code,"discount":self.discount,"final_fare":self.final_fare,"paid":self.paid,"status":self.status,"ride_pin":self.ride_pin,"share_token":self.share_token,"reassign_count":self.reassign_count,"pool_id":self.pool_id,"requested_at":self.requested_at.isoformat() if self.requested_at else None,"accepted_at":self.accepted_at.isoformat() if self.accepted_at else None,"started_at":self.started_at.isoformat() if self.started_at else None,"completed_at":self.completed_at.isoformat() if self.completed_at else None,"driver":self.driver.to_dict() if self.driver else None,"stops":[s.to_dict() for s in self.stops],"rating":self.rating.to_dict() if self.rating else None}

class RideStop(db.Model):
    __tablename__ = "ride_stops"
    id         = db.Column(db.Integer, primary_key=True)
    ride_id    = db.Column(db.Integer, db.ForeignKey("rides.id"), nullable=False)
    stop_order = db.Column(db.Integer, nullable=False)
    name       = db.Column(db.String(255), nullable=False)
    lat        = db.Column(db.Float, nullable=False)
    lng        = db.Column(db.Float, nullable=False)
    reached    = db.Column(db.Boolean, default=False)
    reached_at = db.Column(db.DateTime, nullable=True)
    def to_dict(self):
        return {"id":self.id,"ride_id":self.ride_id,"stop_order":self.stop_order,"name":self.name,"lat":self.lat,"lng":self.lng,"reached":self.reached}

class UserWallet(db.Model):
    __tablename__ = "user_wallets"
    id         = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, unique=True)
    balance    = db.Column(db.Float, default=0.0)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)
    transactions = db.relationship("WalletTransaction", backref="wallet", lazy=True)
    def to_dict(self):
        return {"id":self.id,"user_id":self.user_id,"balance":round(self.balance,2),"updated_at":self.updated_at.isoformat() if self.updated_at else None}

class WalletTransaction(db.Model):
    __tablename__ = "wallet_transactions"
    id            = db.Column(db.Integer, primary_key=True)
    wallet_id     = db.Column(db.Integer, db.ForeignKey("user_wallets.id"), nullable=False)
    user_id       = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    ride_id       = db.Column(db.Integer, db.ForeignKey("rides.id"), nullable=True)
    txn_type      = db.Column(db.String(20), nullable=False)
    amount        = db.Column(db.Float, nullable=False)
    description   = db.Column(db.String(255), nullable=False)
    balance_after = db.Column(db.Float, nullable=False)
    created_at    = db.Column(db.DateTime, default=datetime.utcnow)
    def to_dict(self):
        return {"id":self.id,"wallet_id":self.wallet_id,"user_id":self.user_id,"ride_id":self.ride_id,"txn_type":self.txn_type,"amount":round(self.amount,2),"description":self.description,"balance_after":round(self.balance_after,2),"created_at":self.created_at.isoformat() if self.created_at else None}

class PromoCode(db.Model):
    __tablename__ = "promo_codes"
    id              = db.Column(db.Integer, primary_key=True)
    code            = db.Column(db.String(30), unique=True, nullable=False)
    discount_type   = db.Column(db.String(10), default="percent")
    discount_value  = db.Column(db.Float, nullable=False)
    max_discount    = db.Column(db.Float, nullable=True)
    min_fare        = db.Column(db.Float, default=0.0)
    max_uses        = db.Column(db.Integer, default=100)
    uses_per_user   = db.Column(db.Integer, default=1)
    used_count      = db.Column(db.Integer, default=0)
    valid_from      = db.Column(db.DateTime, default=datetime.utcnow)
    valid_until     = db.Column(db.DateTime, nullable=True)
    is_active       = db.Column(db.Boolean, default=True)
    cashback_percent= db.Column(db.Float, default=0.0)
    description     = db.Column(db.String(255), nullable=True)
    created_at      = db.Column(db.DateTime, default=datetime.utcnow)
    usages = db.relationship("PromoUsage", backref="promo", lazy=True)
    def is_valid(self):
        now=datetime.utcnow()
        if not self.is_active: return False,"Promo code is inactive."
        if self.used_count>=self.max_uses: return False,"Promo code usage limit reached."
        if self.valid_until and now>self.valid_until: return False,"Promo code has expired."
        if now<self.valid_from: return False,"Promo code not yet active."
        return True,"OK"
    def to_dict(self):
        return {"id":self.id,"code":self.code,"discount_type":self.discount_type,"discount_value":self.discount_value,"max_discount":self.max_discount,"min_fare":self.min_fare,"max_uses":self.max_uses,"uses_per_user":self.uses_per_user,"used_count":self.used_count,"cashback_percent":self.cashback_percent,"description":self.description,"is_active":self.is_active,"valid_until":self.valid_until.isoformat() if self.valid_until else None}

class PromoUsage(db.Model):
    __tablename__ = "promo_usages"
    id       = db.Column(db.Integer, primary_key=True)
    promo_id = db.Column(db.Integer, db.ForeignKey("promo_codes.id"), nullable=False)
    user_id  = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    ride_id  = db.Column(db.Integer, db.ForeignKey("rides.id"), nullable=True)
    used_at  = db.Column(db.DateTime, default=datetime.utcnow)

class RideRating(db.Model):
    __tablename__ = "ride_ratings"
    id        = db.Column(db.Integer, primary_key=True)
    ride_id   = db.Column(db.Integer, db.ForeignKey("rides.id"), nullable=False, unique=True)
    user_id   = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    driver_id = db.Column(db.Integer, db.ForeignKey("drivers.id"), nullable=False)
    stars     = db.Column(db.Integer, nullable=False)
    review    = db.Column(db.String(500), nullable=True)
    created_at= db.Column(db.DateTime, default=datetime.utcnow)
    def to_dict(self):
        return {"id":self.id,"ride_id":self.ride_id,"user_id":self.user_id,"driver_id":self.driver_id,"stars":self.stars,"review":self.review,"created_at":self.created_at.isoformat() if self.created_at else None}

class ScheduledRide(db.Model):
    __tablename__ = "scheduled_rides"
    id           = db.Column(db.Integer, primary_key=True)
    user_id      = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    pickup_name  = db.Column(db.String(255), nullable=False)
    pickup_lat   = db.Column(db.Float, nullable=False)
    pickup_lng   = db.Column(db.Float, nullable=False)
    drop_name    = db.Column(db.String(255), nullable=False)
    drop_lat     = db.Column(db.Float, nullable=False)
    drop_lng     = db.Column(db.Float, nullable=False)
    vehicle_type = db.Column(db.String(50), default="Bike")
    scheduled_at = db.Column(db.DateTime, nullable=False)
    status       = db.Column(db.String(20), default="pending")
    ride_id      = db.Column(db.Integer, db.ForeignKey("rides.id"), nullable=True)
    created_at   = db.Column(db.DateTime, default=datetime.utcnow)
    user = db.relationship("User", backref="scheduled_rides", lazy=True)
    def to_dict(self):
        return {"id":self.id,"user_id":self.user_id,"pickup_name":self.pickup_name,"pickup_lat":self.pickup_lat,"pickup_lng":self.pickup_lng,"drop_name":self.drop_name,"drop_lat":self.drop_lat,"drop_lng":self.drop_lng,"vehicle_type":self.vehicle_type,"scheduled_at":self.scheduled_at.isoformat() if self.scheduled_at else None,"status":self.status,"ride_id":self.ride_id,"created_at":self.created_at.isoformat() if self.created_at else None}

class CaptainBonus(db.Model):
    __tablename__ = "captain_bonuses"
    id          = db.Column(db.Integer, primary_key=True)
    driver_id   = db.Column(db.Integer, db.ForeignKey("drivers.id"), nullable=False)
    bonus_type  = db.Column(db.String(30), nullable=False)
    amount      = db.Column(db.Float, nullable=False)
    description = db.Column(db.String(255), nullable=True)
    paid        = db.Column(db.Boolean, default=False)
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)
    def to_dict(self):
        return {"id":self.id,"driver_id":self.driver_id,"bonus_type":self.bonus_type,"amount":self.amount,"description":self.description,"paid":self.paid,"created_at":self.created_at.isoformat() if self.created_at else None}

class FraudLog(db.Model):
    __tablename__ = "fraud_logs"
    id         = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    driver_id  = db.Column(db.Integer, db.ForeignKey("drivers.id"), nullable=True)
    ride_id    = db.Column(db.Integer, db.ForeignKey("rides.id"), nullable=True)
    reason     = db.Column(db.String(255), nullable=False)
    severity   = db.Column(db.String(10), default="medium")
    reviewed   = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    def to_dict(self):
        return {"id":self.id,"user_id":self.user_id,"driver_id":self.driver_id,"ride_id":self.ride_id,"reason":self.reason,"severity":self.severity,"reviewed":self.reviewed,"created_at":self.created_at.isoformat() if self.created_at else None}

class SosAlert(db.Model):
    __tablename__ = "sos_alerts"
    id         = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    ride_id    = db.Column(db.Integer, db.ForeignKey("rides.id"), nullable=True)
    lat        = db.Column(db.Float, nullable=True)
    lng        = db.Column(db.Float, nullable=True)
    message    = db.Column(db.String(255), default="SOS triggered by user")
    resolved   = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    def to_dict(self):
        return {"id":self.id,"user_id":self.user_id,"ride_id":self.ride_id,"lat":self.lat,"lng":self.lng,"message":self.message,"resolved":self.resolved,"created_at":self.created_at.isoformat() if self.created_at else None}

class OTPVerification(db.Model):
    __tablename__ = "otp_verifications"
    id           = db.Column(db.Integer, primary_key=True)
    contact      = db.Column(db.String(150), nullable=False)
    contact_type = db.Column(db.String(10),  nullable=False)
    otp          = db.Column(db.String(10),  nullable=False)
    purpose      = db.Column(db.String(20),  default="register")
    expiry_time  = db.Column(db.DateTime,    nullable=False)
    attempts     = db.Column(db.Integer, default=0)
    verified     = db.Column(db.Boolean, default=False)
    created_at   = db.Column(db.DateTime, default=datetime.utcnow)
    def is_expired(self): return datetime.utcnow()>self.expiry_time
    def to_dict(self):
        return {"id":self.id,"contact":self.contact,"contact_type":self.contact_type,"purpose":self.purpose,"expiry_time":self.expiry_time.isoformat(),"attempts":self.attempts,"verified":self.verified}

class DriverPaymentMethod(db.Model):
    __tablename__ = "driver_payment_methods"
    id          = db.Column(db.Integer, primary_key=True)
    driver_id   = db.Column(db.Integer, db.ForeignKey("drivers.id"), nullable=False)
    method_type = db.Column(db.String(10), nullable=False)
    upi_id      = db.Column(db.String(100), nullable=True)
    account_no  = db.Column(db.String(30),  nullable=True)
    ifsc        = db.Column(db.String(20),  nullable=True)
    holder_name = db.Column(db.String(100), nullable=True)
    bank_name   = db.Column(db.String(100), nullable=True)
    is_primary  = db.Column(db.Boolean, default=False)
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)
    def to_dict(self):
        return {"id":self.id,"driver_id":self.driver_id,"method_type":self.method_type,"upi_id":self.upi_id,"account_no":self.account_no,"ifsc":self.ifsc,"holder_name":self.holder_name,"bank_name":self.bank_name,"is_primary":self.is_primary}

class DriverWithdrawal(db.Model):
    __tablename__ = "driver_withdrawals"
    id           = db.Column(db.Integer, primary_key=True)
    driver_id    = db.Column(db.Integer, db.ForeignKey("drivers.id"), nullable=False)
    amount       = db.Column(db.Float, nullable=False)
    method_type  = db.Column(db.String(10), nullable=False)
    destination  = db.Column(db.String(200), nullable=False)
    status       = db.Column(db.String(20), default="pending")
    note         = db.Column(db.String(255), nullable=True)
    requested_at = db.Column(db.DateTime, default=datetime.utcnow)
    processed_at = db.Column(db.DateTime, nullable=True)
    driver = db.relationship("Driver", backref="withdrawals", lazy=True)
    def to_dict(self):
        return {"id":self.id,"driver_id":self.driver_id,"driver_name":self.driver.name if self.driver else None,"amount":self.amount,"method_type":self.method_type,"destination":self.destination,"status":self.status,"note":self.note,"requested_at":self.requested_at.isoformat() if self.requested_at else None,"processed_at":self.processed_at.isoformat() if self.processed_at else None}

class Notification(db.Model):
    __tablename__ = "notifications"
    id         = db.Column(db.Integer, primary_key=True)
    driver_id  = db.Column(db.Integer, db.ForeignKey("drivers.id"), nullable=True)
    user_id    = db.Column(db.Integer, db.ForeignKey("users.id"),   nullable=True)
    ride_id    = db.Column(db.Integer, db.ForeignKey("rides.id"),   nullable=True)
    type       = db.Column(db.String(50),  nullable=False)
    title      = db.Column(db.String(200), nullable=False)
    message    = db.Column(db.String(500), nullable=False)
    is_read    = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    def to_dict(self):
        return {"id":self.id,"driver_id":self.driver_id,"user_id":self.user_id,"ride_id":self.ride_id,"type":self.type,"title":self.title,"message":self.message,"is_read":self.is_read,"created_at":self.created_at.isoformat() if self.created_at else None}

class RideMessage(db.Model):
    __tablename__ = "ride_messages"
    id         = db.Column(db.Integer, primary_key=True)
    ride_id    = db.Column(db.Integer, db.ForeignKey("rides.id"), nullable=False)
    sender     = db.Column(db.String(10), nullable=False)
    message    = db.Column(db.String(500), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    def to_dict(self):
        return {"id":self.id,"ride_id":self.ride_id,"sender":self.sender,"message":self.message,"created_at":self.created_at.isoformat() if self.created_at else None}
