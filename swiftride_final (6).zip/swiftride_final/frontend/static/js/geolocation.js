/**
 * Rapido Clone — Geolocation Module
 * ─────────────────────────────────
 * Features:
 *   • "Use Current Location" button integration
 *   • Reverse geocoding via OpenStreetMap Nominatim (free, no API key)
 *   • Real-time watchPosition tracking
 *   • Full error handling (denied / unavailable / unsupported)
 *   • POST to Flask /api/location to persist in MySQL
 *
 * Usage:
 *   GeoLocation.useCurrentLocation()   – one-shot fetch for pickup
 *   GeoLocation.startTracking()        – continuous watchPosition
 *   GeoLocation.stopTracking()         – clear watchPosition
 */

const GeoLocation = (() => {

  /* ── State ────────────────────────────────────────────────── */
  let _watchId          = null;
  let _lastCoords       = null;
  let _isTracking       = false;
  let _trackingCallback = null;

  /* ── Nominatim reverse geocode ───────────────────────────── */
  async function reverseGeocode(lat, lng) {
    try {
      const url =
        `https://nominatim.openstreetmap.org/reverse?format=jsonv2` +
        `&lat=${lat}&lon=${lng}&zoom=16&addressdetails=1`;

      const res = await fetch(url, {
        headers: { 'Accept-Language': 'en', 'User-Agent': 'RapidoCloneApp/1.0' },
      });

      if (!res.ok) throw new Error(`Nominatim HTTP ${res.status}`);

      const data = await res.json();

      /* Build a concise, human-readable label */
      const a = data.address || {};
      const parts = [
        a.road || a.pedestrian || a.footway,
        a.suburb || a.neighbourhood || a.quarter,
        a.city || a.town || a.village || a.county,
      ].filter(Boolean);

      return parts.length
        ? parts.slice(0, 2).join(', ')
        : data.display_name?.split(',').slice(0, 2).join(', ') || `${lat.toFixed(5)}, ${lng.toFixed(5)}`;

    } catch (err) {
      console.warn('[GeoLocation] Nominatim error:', err);
      return `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
    }
  }

  /* ── POST coords to Flask backend ────────────────────────── */
  async function _persistLocation(lat, lng, address, type = 'current') {
    try {
      const res = await fetch('/api/location', {
        method:      'POST',
        credentials: 'same-origin',
        headers:     { 'Content-Type': 'application/json' },
        body: JSON.stringify({ latitude: lat, longitude: lng, address, type }),
      });
      const data = await res.json();
      if (!data.success) console.warn('[GeoLocation] persist failed:', data.message);
      return data;
    } catch (err) {
      console.warn('[GeoLocation] persist error:', err);
      return { success: false };
    }
  }

  /* ── Error message helper ────────────────────────────────── */
  function _errorMessage(err) {
    if (!err) return 'An unknown location error occurred.';
    switch (err.code) {
      case 1: // PERMISSION_DENIED
        return 'Location permission was denied. Please allow location access in your browser settings and try again.';
      case 2: // POSITION_UNAVAILABLE
        return 'Your location is currently unavailable. Please check your device\'s location settings.';
      case 3: // TIMEOUT
        return 'Location request timed out. Please try again.';
      default:
        return `Location error (${err.message || 'unknown'}).`;
    }
  }

  /* ── Update the booking form's pickup field ──────────────── */
  function _applyToPickup(lat, lng, address) {
    _lastCoords = { lat, lng, address };

    /* Update hidden fields */
    const latEl  = document.getElementById('pickup-lat');
    const lngEl  = document.getElementById('pickup-lng');
    const nameEl = document.getElementById('pickup-input');
    if (latEl)  latEl.value  = lat;
    if (lngEl)  lngEl.value  = lng;
    if (nameEl) nameEl.value = address;

    /* Tell BookingUI & MapManager */
    if (typeof BookingUI !== 'undefined' && BookingUI.setPickupFromMap) {
      BookingUI.setPickupFromMap(lat, lng, address);
    }
    if (typeof MapManager !== 'undefined') {
      MapManager.setPickup(lat, lng, address);
      if (typeof MapManager.flyTo === 'function') MapManager.flyTo(lat, lng, 15);
    }

    /* Show geo-panel address */
    _showPanel(lat, lng, address);
  }

  /* ── Render / update the location info panel ─────────────── */
  function _showPanel(lat, lng, address) {
    const panel = document.getElementById('geo-location-panel');
    if (!panel) return;

    panel.style.display = 'block';
    panel.innerHTML = `
      <div class="geo-panel-inner">
        <div class="geo-panel-row">
          <span class="geo-icon">📍</span>
          <div class="geo-details">
            <div class="geo-address">${address}</div>
            <div class="geo-coords">
              <code>${lat.toFixed(6)}</code>&nbsp;,&nbsp;<code>${lng.toFixed(6)}</code>
            </div>
          </div>
          <button class="geo-clear-btn" title="Clear location" onclick="GeoLocation.clearLocation()">✕</button>
        </div>
        <div class="geo-actions-row">
          <span id="geo-tracking-badge" class="geo-badge ${_isTracking ? 'active' : ''}">
            ${_isTracking ? '🔴 Live' : '⚪ Static'}
          </span>
          <button class="btn btn-ghost btn-xs" id="geo-track-toggle"
                  onclick="GeoLocation.toggleTracking()">
            ${_isTracking ? 'Stop Tracking' : 'Start Live Tracking'}
          </button>
        </div>
      </div>`;
  }

  function _updateTrackingBadge() {
    const badge  = document.getElementById('geo-tracking-badge');
    const toggle = document.getElementById('geo-track-toggle');
    if (badge)  badge.className  = `geo-badge ${_isTracking ? 'active' : ''}`;
    if (badge)  badge.textContent = _isTracking ? '🔴 Live' : '⚪ Static';
    if (toggle) toggle.textContent = _isTracking ? 'Stop Tracking' : 'Start Live Tracking';
  }

  /* ── Set button loading state ────────────────────────────── */
  function _setBtnState(btn, state) {
    if (!btn) return;
    if (state === 'loading') {
      btn.disabled = true;
      btn.dataset.origHtml = btn.innerHTML;
      btn.innerHTML = `<span class="geo-spinner"></span> Locating…`;
    } else if (state === 'ready') {
      btn.disabled = false;
      btn.innerHTML = btn.dataset.origHtml || '📍 Use Current Location';
    } else if (state === 'success') {
      btn.disabled = false;
      btn.innerHTML = '✅ Location Set';
      setTimeout(() => { btn.innerHTML = btn.dataset.origHtml || '📍 Use Current Location'; }, 2500);
    }
  }

  /* ═══════════════════════════════════════════════════════════
     PUBLIC API
     ═══════════════════════════════════════════════════════════ */

  /**
   * One-shot: fetch user location → reverse geocode → fill pickup.
   * Called by the "Use Current Location" button.
   */
  async function useCurrentLocation() {
    const btn = document.getElementById('use-location-btn');

    /* 1 – Browser support check */
    if (!('geolocation' in navigator)) {
      Toast.error('Your browser does not support Geolocation. Please try Chrome, Firefox, or Edge.');
      return;
    }

    _setBtnState(btn, 'loading');
    Toast.info('Requesting your location…', 2500);

    try {
      /* 2 – Get position (promise wrapper) */
      const position = await new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout:            10000,
          maximumAge:         0,
        });
      });

      const { latitude: lat, longitude: lng, accuracy } = position.coords;

      /* 3 – Reverse geocode */
      Toast.info('Fetching address…', 2000);
      const address = await reverseGeocode(lat, lng);

      /* 4 – Apply to form + map */
      _applyToPickup(lat, lng, address);

      /* 5 – Persist to backend */
      await _persistLocation(lat, lng, address, 'current');

      _setBtnState(btn, 'success');
      Toast.success(`Pickup set: ${address}`);

    } catch (err) {
      _setBtnState(btn, 'ready');
      const msg = _errorMessage(err);
      Toast.error(msg, 6000);
      console.error('[GeoLocation] useCurrentLocation error:', err);
    }
  }

  /**
   * Start watchPosition — continuously updates pickup & map.
   */
  function startTracking(onUpdate) {
    if (!('geolocation' in navigator)) {
      Toast.error('Geolocation is not supported by your browser.');
      return;
    }
    if (_watchId !== null) {
      console.info('[GeoLocation] Already tracking.');
      return;
    }

    _trackingCallback = onUpdate || null;
    _isTracking       = true;
    _updateTrackingBadge();
    Toast.info('🔴 Live location tracking started.');

    _watchId = navigator.geolocation.watchPosition(
      async (position) => {
        const { latitude: lat, longitude: lng } = position.coords;
        const address = await reverseGeocode(lat, lng);

        _lastCoords = { lat, lng, address };
        _applyToPickup(lat, lng, address);
        await _persistLocation(lat, lng, address, 'tracking');

        if (typeof _trackingCallback === 'function') {
          _trackingCallback({ lat, lng, address });
        }
      },
      (err) => {
        Toast.error(_errorMessage(err), 5000);
        stopTracking();
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 5000 }
    );
  }

  /**
   * Stop watchPosition.
   */
  function stopTracking() {
    if (_watchId !== null) {
      navigator.geolocation.clearWatch(_watchId);
      _watchId = null;
    }
    _isTracking       = false;
    _trackingCallback = null;
    _updateTrackingBadge();
    Toast.info('Live tracking stopped.');
  }

  function toggleTracking() {
    if (_isTracking) stopTracking();
    else             startTracking();
  }

  /**
   * Clear the current location from the form and panel.
   */
  function clearLocation() {
    stopTracking();
    _lastCoords = null;

    const latEl  = document.getElementById('pickup-lat');
    const lngEl  = document.getElementById('pickup-lng');
    const nameEl = document.getElementById('pickup-input');
    if (latEl)  latEl.value  = '';
    if (lngEl)  lngEl.value  = '';
    if (nameEl) nameEl.value = '';

    const panel = document.getElementById('geo-location-panel');
    if (panel) panel.style.display = 'none';

    Toast.info('Location cleared.');
  }

  /** Return last known coords. */
  function getLastCoords() { return _lastCoords; }

  return {
    useCurrentLocation,
    startTracking,
    stopTracking,
    toggleTracking,
    clearLocation,
    getLastCoords,
    reverseGeocode,
  };

})();
