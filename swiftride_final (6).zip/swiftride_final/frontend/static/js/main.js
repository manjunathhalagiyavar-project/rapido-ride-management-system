/**
 * Rapido Clone — Main Frontend JS
 * Handles: Auth (OTP), Ride Booking, Map, Real-Time Tracking
 */

/* ═══════════════════════════════════════════════════════════════
   TOAST NOTIFICATIONS
   ═══════════════════════════════════════════════════════════════ */

const Toast = (() => {
  const icons = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️' };
  const titles = { success: 'Success', error: 'Error', warning: 'Warning', info: 'Info' };

  function show(type, message, duration = 4000) {
    const container = document.getElementById('toast-container');
    const t = document.createElement('div');
    t.className = `toast ${type} animate-fade-in`;
    t.innerHTML = `
      <span class="toast-icon">${icons[type]}</span>
      <div class="toast-body">
        <div class="toast-title">${titles[type]}</div>
        <div class="toast-msg">${message}</div>
      </div>`;
    container.appendChild(t);
    setTimeout(() => {
      t.classList.add('removing');
      t.addEventListener('animationend', () => t.remove());
    }, duration);
  }

  return {
    success: (m, d) => show('success', m, d),
    error:   (m, d) => show('error', m, d),
    warning: (m, d) => show('warning', m, d),
    info:    (m, d) => show('info', m, d),
  };
})();


/* ═══════════════════════════════════════════════════════════════
   API HELPER
   ═══════════════════════════════════════════════════════════════ */

const API = {
  async request(method, url, body = null) {
    try {
      const opts = {
        method,
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
      };
      if (body) opts.body = JSON.stringify(body);
      const res  = await fetch(url, opts);
      // Try to parse JSON; if server returned HTML/500, surface the real status
      const text = await res.text();
      try {
        return JSON.parse(text);
      } catch {
        console.error('Non-JSON response from', url, res.status, text.slice(0, 300));
        return { success: false, message: `Server error (${res.status}). Check Flask console for details.` };
      }
    } catch (e) {
      console.error('Fetch failed:', e);
      return { success: false, message: 'Cannot reach server. Is Flask running?' };
    }
  },
  get:    (url)        => API.request('GET',    url),
  post:   (url, body)  => API.request('POST',   url, body),
  del:    (url)        => API.request('DELETE', url),
};


/* ═══════════════════════════════════════════════════════════════
   AUTH MODAL — Direct Login/Register (No OTP)
   ═══════════════════════════════════════════════════════════════ */

const Auth = (() => {
  let state = {
    step:        'contact',   // contact → name (register only)
    purpose:     'login',     // login | register
    contactType: 'email',     // email | phone
    contact:     '',
    name:        '',
  };

  let currentUser = null;
  const el = (id) => document.getElementById(id);

  // ── Open/Close ────────────────────────────────────────────────
  function open(purpose = 'login') {
    state = { step: 'contact', purpose, contactType: 'email', contact: '', name: '' };
    _renderModal();
    el('auth-overlay').classList.add('active');
  }

  function close() {
    el('auth-overlay').classList.remove('active');
  }

  // ── Render ────────────────────────────────────────────────────
  function _renderModal() {
    const isLogin = state.purpose === 'login';
    const title   = isLogin ? 'Welcome Back' : 'Create Account';

    el('auth-modal').innerHTML = `
      <div class="modal-header">
        <div>
          <h3 style="font-family:'Syne',sans-serif;font-size:1.4rem;font-weight:800;">${title}</h3>
          <p style="font-size:0.82rem;color:var(--text-muted);margin-top:2px;">
            ${isLogin ? 'Login with your email or phone number' : 'Register with email or Indian phone number'}
          </p>
        </div>
        <button class="modal-close" onclick="Auth.close()">✕</button>
      </div>

      <div class="steps-indicator">
        <div class="step-dot ${state.step === 'contact' ? 'active' : 'done'}"></div>
        ${!isLogin ? `<div class="step-dot ${state.step === 'name' ? 'active' : ''}"></div>` : ''}
      </div>

      ${state.step === 'contact' ? _contactStep() : _nameStep()}

      <p style="text-align:center;font-size:0.8rem;margin-top:1rem;color:var(--text-muted);">
        ${isLogin
          ? `Don't have an account? <a href="#" onclick="Auth.open('register');return false;">Register</a>`
          : `Already have an account? <a href="#" onclick="Auth.open('login');return false;">Login</a>`}
      </p>`;
  }

  function _contactStep() {
    const isLogin = state.purpose === 'login';
    const btnLabel = isLogin ? 'Login →' : 'Continue →';
    return `
      <div style="display:flex;flex-direction:column;gap:1rem;">
        <div class="tab-group">
          <button class="tab-btn ${state.contactType === 'email' ? 'active' : ''}"
                  onclick="Auth._setContactType('email')">📧 Email</button>
          <button class="tab-btn ${state.contactType === 'phone' ? 'active' : ''}"
                  onclick="Auth._setContactType('phone')">📱 Phone</button>
        </div>
        <div class="form-group">
          <label class="form-label">${state.contactType === 'email' ? 'Email Address' : 'Indian Phone Number'}</label>
          <div class="input-wrap">
            <span class="input-icon">${state.contactType === 'email' ? '✉' : '📞'}</span>
            <input class="form-input has-icon" id="contact-input"
              type="${state.contactType === 'email' ? 'email' : 'tel'}"
              placeholder="${state.contactType === 'email' ? 'you@email.com' : '9876543210 (10-digit)'}"
              value="${state.contact}"
              onkeydown="if(event.key==='Enter')Auth._onContactNext()"/>
          </div>
          ${state.contactType === 'phone'
            ? `<p style="font-size:0.75rem;color:var(--text-muted);margin-top:4px;">📍 Indian mobile numbers only (starting with 6–9)</p>`
            : ''}
        </div>
        <button class="btn btn-primary btn-lg" id="contact-next-btn" onclick="Auth._onContactNext()">
          ${btnLabel}
        </button>
      </div>`;
  }

  function _nameStep() {
    return `
      <div style="display:flex;flex-direction:column;gap:1rem;">
        <p style="font-size:0.84rem;color:var(--text-muted);">
          Registering as: <strong style="color:var(--accent);">${state.contact}</strong>
        </p>
        <div class="form-group">
          <label class="form-label">Full Name</label>
          <div class="input-wrap">
            <span class="input-icon">👤</span>
            <input class="form-input has-icon" id="name-input" type="text"
              placeholder="Your full name" value="${state.name}"
              onkeydown="if(event.key==='Enter')Auth._doRegister()"/>
          </div>
        </div>
        <button class="btn btn-primary btn-lg" id="register-btn" onclick="Auth._doRegister()">
          Create Account 🚀
        </button>
        <button class="btn btn-ghost btn-sm" onclick="Auth._goBack()"
                style="margin:0 auto;">← Change contact</button>
      </div>`;
  }

  // ── Actions ───────────────────────────────────────────────────
  function _setContactType(type) {
    state.contactType = type;
    _renderModal();
  }

  function _goBack() {
    state.step = 'contact';
    _renderModal();
  }

  async function _onContactNext() {
    const input = el('contact-input');
    if (!input) return;
    state.contact = input.value.trim();
    if (!state.contact) {
      Toast.error('Please enter your ' + (state.contactType === 'email' ? 'email' : 'phone number'));
      return;
    }

    const btn = el('contact-next-btn');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span> Please wait…';

    if (state.purpose === 'login') {
      await _doLogin();
    } else {
      // Register: move to name step
      btn.disabled = false;
      btn.innerHTML = 'Continue →';
      state.step = 'name';
      _renderModal();
    }
  }

  async function _doLogin() {
    const res = await API.post('/api/login', {
      contact:      state.contact,
      contact_type: state.contactType,
    });

    const btn = el('contact-next-btn');
    if (btn) { btn.disabled = false; btn.innerHTML = 'Login →'; }

    if (!res.success) { Toast.error(res.message); return; }

    currentUser = res.user;
    Toast.success(`Welcome back, ${currentUser.name}! 🎉`);
    close();
    _onLogin(currentUser);
  }

  async function _doRegister() {
    state.name = (el('name-input') || {}).value?.trim() || '';
    if (!state.name) { Toast.error('Please enter your full name.'); return; }

    const btn = el('register-btn');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span> Creating…';

    const body = { name: state.name, contact_type: state.contactType };
    if (state.contactType === 'email') body.email = state.contact;
    else                               body.phone = state.contact;

    const res = await API.post('/api/register', body);

    btn.disabled = false;
    btn.innerHTML = 'Create Account 🚀';

    if (!res.success) { Toast.error(res.message); return; }

    currentUser = res.user;
    Toast.success(`Account created! Welcome, ${currentUser.name}! 🎉`);
    close();
    _onLogin(currentUser);
  }

  async function checkSession() {
    const res = await API.get('/api/me');
    if (res.success) {
      currentUser = res.user;
      _onLogin(currentUser);
    }
    return res.success;
  }

  async function logout() {
    await API.post('/api/logout');
    currentUser = null;
    _onLogout();
  }

  function getUser() { return currentUser; }

  function _onLogin(user)  { window.onAuthLogin?.(user); }
  function _onLogout()     { window.onAuthLogout?.(); }

  return { open, close, checkSession, logout, getUser,
           _setContactType, _goBack, _onContactNext, _doRegister };
})();


/* ═══════════════════════════════════════════════════════════════
   UTILITY
   ═══════════════════════════════════════════════════════════════ */

function formatCurrency(val) {
  return `₹${parseFloat(val).toFixed(0)}`;
}

function formatDate(iso) {
  if (!iso) return '—';
  return new Date(iso).toLocaleString('en-IN', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
}

function formatDist(km) {
  return km < 1 ? `${(km * 1000).toFixed(0)} m` : `${parseFloat(km).toFixed(1)} km`;
}

function setButtonLoading(btn, loading, text = '') {
  if (!btn) return;
  btn.disabled = loading;
  btn.innerHTML = loading ? '<span class="spinner"></span> Loading…' : text;
}

// Auth hooks are wired via window.onAuthLogin / window.onAuthLogout in app.js
