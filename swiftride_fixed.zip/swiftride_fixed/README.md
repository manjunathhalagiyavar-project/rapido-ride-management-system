# 🏍️ SwiftRide — Hubli / Dharwad

A real-time bike/auto/cab booking app for the **Hubli–Dharwad** region, Karnataka.

---

## 🚀 Quick Start

### Windows — One Click
```
Double-click start.bat
```
Opens the Flask server and browser automatically.

### Windows — All Terminals (recommended for development)
```
Double-click run_all_terminals.bat
```
Opens **4 separate terminal windows**:
| Terminal | Purpose |
|----------|---------|
| T1 — Flask Backend | Main server + OTP codes printed here |
| T2 — OTP Log Watcher | Catches dev OTPs when SMTP not configured |
| T3 — DB Status Monitor | Row counts every 10 s |
| T4 — SocketIO Events | Real-time WebSocket event log |

### Manual
```bash
pip install -r requirements.txt
cp .env.example .env          # then edit .env
python run.py
# open http://localhost:5000
```

---

## 🗺️ Map Features (Hubli–Dharwad)

| Feature | How to use |
|---------|-----------|
| **New ride** | **Double-tap** anywhere on the map |
| **Set drop** | Single-tap map after pickup is set |
| **Quick presets** | Hubli Stn · Dharwad Bus Std · Airport · KLE Univ |
| **Search** | Type in pickup/drop box — region-biased results |
| **Real road route** | Drawn via OSRM (OpenStreetMap routing) |
| **Live driver** | Smooth real-time animation via Socket.IO |

---

## 📲 OTP Configuration

### Email OTP (Gmail)
1. Enable 2-Step Verification: https://myaccount.google.com/security
2. Create App Password: https://myaccount.google.com/apppasswords
3. In `.env`:
```
MAIL_USERNAME=yourname@gmail.com
MAIL_PASSWORD=xxxx xxxx xxxx xxxx
```

### Mobile OTP (SMS via Twilio — free trial)
1. Sign up: https://twilio.com
2. Get Account SID, Auth Token, a trial phone number
3. In `.env`:
```
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=xxxxxxxxxxxxxxxx
TWILIO_FROM_NUMBER=+1xxxxxxxxxx
```

> **Dev mode**: If SMTP/Twilio are not configured, OTP is printed to the **server terminal** (T1). Look for the `═══` bordered block.

---

## 🐛 Bugs Fixed

| # | Bug | Fix |
|---|-----|-----|
| 1 | Email OTP silently failed | Replaced flask-mail with direct `smtplib`; console fallback |
| 2 | Config placeholder not detected | Added placeholder value checks before SMTP attempt |
| 3 | Mobile OTP was just `print()` | Twilio integration + console fallback |
| 4 | Map centered on Bengaluru | Moved to Hubli–Dharwad (15.41°N 75.06°E) |
| 5 | Straight-line route only | OSRM real road routing with fallback |
| 6 | Driver jitter animation | Smooth `requestAnimationFrame` cubic-ease interpolation |
| 7 | Socket thread app-context crash | Pass `app` object explicitly into thread |
| 8 | Thread race condition | `threading.Lock()` around `_active_threads` dict |
| 9 | No error handlers | Added 404/500 JSON handlers for API routes |
| 10 | Seed drivers in Bengaluru | 7 drivers seeded across Hubli–Dharwad corridor |

---

## 📁 Project Structure

```
swiftride_fixed/
├── start.bat                  ← One-click launcher
├── run_all_terminals.bat      ← Opens 4 terminal windows
├── run.py                     ← Flask entry point
├── requirements.txt
├── .env.example               ← Copy to .env and fill in
├── backend/
│   ├── app.py                 ← App factory + seed data
│   ├── config.py              ← All config (SMTP, Twilio, DB)
│   ├── extensions.py          ← db, mail, socketio
│   ├── models/models.py       ← User, Driver, Ride, OTPVerification
│   ├── routes/
│   │   ├── auth_routes.py     ← /api/send-otp, verify-otp, register, login
│   │   ├── ride_routes.py     ← /api/book-ride, rides, estimate
│   │   └── socket_events.py  ← Real-time tracking (fixed threading)
│   └── utils/
│       ├── otp_utils.py       ← Email (smtplib) + SMS (Twilio) OTP
│       └── geo_utils.py       ← Haversine, fare, interpolation
└── frontend/
    ├── templates/
    │   ├── index.html         ← Main booking page
    │   └── history.html       ← Ride history
    └── static/
        ├── css/style.css
        └── js/
            ├── main.js        ← Toast, API, Auth modal, OTP timer
            ├── map.js         ← Map, Tracker, BookingUI, geocoder
            └── app.js         ← Bootstrap + navbar + history page
```
