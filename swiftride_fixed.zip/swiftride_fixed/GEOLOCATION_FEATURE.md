# 📍 Use Current Location — Feature Documentation

## Overview

This feature adds a **"Use Current Location"** button to the SwiftRide ride-booking form.  
It uses **only free, open-source technologies** — no paid APIs.

---

## Architecture

```
Browser (Geolocation API)
    │
    ▼
geolocation.js  ──reverse geocode──▶  OpenStreetMap Nominatim
    │                                  (free, no API key)
    │
    ├──▶  Booking form (pickup-input, pickup-lat, pickup-lng)
    │
    ├──▶  MapManager.setPickup()  ──▶  Leaflet map marker
    │
    └──▶  POST /api/location  ──▶  Flask  ──▶  MySQL (user_locations table)
```

---

## Files Added / Modified

| File | Type | Purpose |
|------|------|---------|
| `frontend/static/js/geolocation.js` | **NEW** | All geolocation logic |
| `backend/routes/location_routes.py` | **NEW** | Flask API: POST/GET `/api/location` |
| `backend/models/location_model.py` | **NEW** | SQLAlchemy `user_locations` table |
| `frontend/templates/index.html` | **MODIFIED** | Button + panel HTML; script tag |
| `frontend/static/css/style.css` | **MODIFIED** | Button, panel, badge, spinner styles |
| `backend/app.py` | **MODIFIED** | Register `location_bp`; import model |
| `setup_db.sql` | **MODIFIED** | Schema reference comment |

---

## How It Works

### 1. "Use Current Location" Button

```html
<button id="use-location-btn" onclick="GeoLocation.useCurrentLocation()">
  📍 Use Current Location
</button>
```

Clicking calls `GeoLocation.useCurrentLocation()` which:

1. Checks `navigator.geolocation` support
2. Calls `navigator.geolocation.getCurrentPosition()` with `enableHighAccuracy: true`
3. On success → sends `(lat, lng)` to **Nominatim reverse geocode**
4. Fills the booking form's pickup fields (`pickup-input`, `pickup-lat`, `pickup-lng`)
5. Moves the Leaflet map to the user's location and places a 🟢 marker
6. POSTs `{ latitude, longitude, address, type }` to `/api/location`
7. Shows a success toast and the info panel

### 2. Error Handling

| Scenario | Response |
|----------|----------|
| Browser unsupported | Toast: "Your browser does not support Geolocation" |
| Permission denied (code 1) | Toast: "Location permission was denied..." |
| Position unavailable (code 2) | Toast: "Your location is currently unavailable..." |
| Request timeout (code 3) | Toast: "Location request timed out..." |
| Nominatim fails | Falls back to `lat, lng` coordinate string |
| MySQL error | Logs server-side; returns `success: false` JSON |

### 3. Real-Time Tracking (watchPosition)

After location is set, the info panel shows a **"Start Live Tracking"** button:

- Calls `navigator.geolocation.watchPosition()` — updates on every position change
- Updates the pickup field and map marker continuously
- Saves each update to MySQL with `loc_type = 'tracking'`
- Shows a red pulsing **🔴 Live** badge while active
- Click **"Stop Tracking"** or `GeoLocation.stopTracking()` to cancel

### 4. MySQL Storage

New table: **`user_locations`**

```sql
CREATE TABLE user_locations (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  user_id      INT          REFERENCES users(id) ON DELETE SET NULL,
  latitude     FLOAT        NOT NULL,
  longitude    FLOAT        NOT NULL,
  address      VARCHAR(500) NOT NULL DEFAULT '',
  loc_type     VARCHAR(20)  NOT NULL DEFAULT 'current',
  session_id   VARCHAR(128),
  created_at   DATETIME     DEFAULT CURRENT_TIMESTAMP
);
```

- `user_id` is nullable — **guest users** (not logged in) are also stored
- `loc_type` = `'current'` for one-shot, `'tracking'` for watchPosition updates
- Table is created automatically by SQLAlchemy on first run

---

## API Endpoints

### `POST /api/location`

**Request body:**
```json
{
  "latitude": 15.3647,
  "longitude": 75.1240,
  "address": "Hubli, Karnataka",
  "type": "current"
}
```

**Success response:**
```json
{
  "success": true,
  "message": "Location saved.",
  "location_id": 42,
  "latitude": 15.3647,
  "longitude": 75.1240,
  "address": "Hubli, Karnataka"
}
```

### `GET /api/location`

Returns the most recent saved location for the logged-in user.

---

## Requirements

- Works on **localhost** (HTTP) — browsers allow Geolocation on localhost
- On production: **HTTPS is required** for Geolocation API
- No paid APIs used — only:
  - Browser `navigator.geolocation` (free)
  - OpenStreetMap Nominatim (free, rate-limited to ~1 req/sec)
  - Flask + MySQL (open-source)

---

## JavaScript API Reference

```js
// One-shot location fetch → fills pickup form
GeoLocation.useCurrentLocation()

// Start continuous tracking
GeoLocation.startTracking(optionalCallback)

// Stop tracking
GeoLocation.stopTracking()

// Toggle tracking on/off
GeoLocation.toggleTracking()

// Clear location from form
GeoLocation.clearLocation()

// Get last known {lat, lng, address}
GeoLocation.getLastCoords()

// Standalone reverse geocode (returns Promise<string>)
GeoLocation.reverseGeocode(lat, lng)
```
