"""
Flask application factory — SwiftRide (Full Feature Set)
"""
import os
from flask import Flask, render_template, jsonify, send_from_directory
from backend.config import Config
from backend.extensions import db, socketio


def create_app(config_class=Config):
    base_dir     = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    template_dir = os.path.join(base_dir, "frontend", "templates")
    static_dir   = os.path.join(base_dir, "frontend", "static")

    app = Flask(__name__, template_folder=template_dir, static_folder=static_dir)
    app.config.from_object(config_class)

    db.init_app(app)
    socketio.init_app(app, cors_allowed_origins=config_class.SOCKETIO_CORS_ALLOWED_ORIGINS,
                      async_mode="threading", logger=False, engineio_logger=False)

    from backend.routes.auth_routes   import auth_bp
    from backend.routes.ride_routes   import ride_bp
    from backend.routes.rider_routes  import rider_bp
    from backend.routes.location_routes import location_bp
    app.register_blueprint(auth_bp)
    app.register_blueprint(ride_bp)
    app.register_blueprint(rider_bp)
    app.register_blueprint(location_bp)
    from backend.routes import socket_events  # noqa

    with app.app_context():
        from backend.models.models import (
            User, Driver, Ride, RideStop, RidePool, UserWallet, WalletTransaction,
            PromoCode, PromoUsage, RideRating, ScheduledRide, CaptainBonus,
            FraudLog, SosAlert, OTPVerification, DriverPaymentMethod,
            DriverWithdrawal, Notification, RideMessage
        )
        try:
            from backend.models.location_model import UserLocation  # noqa
        except Exception:
            pass
        try:
            import pymysql
            conn = pymysql.connect(host=config_class.DB_HOST, port=config_class.DB_PORT,
                                   user=config_class.DB_USER, password=config_class.DB_PASSWORD,
                                   database=config_class.DB_NAME, connect_timeout=5)
            conn.close()
            print(f"[MySQL] ✅ Connected to '{config_class.DB_NAME}'")
        except Exception as e:
            print(f"[MySQL] ❌ Cannot connect: {e}")
            raise SystemExit(1)
        db.create_all()
        _seed_drivers()
        _seed_promos()

    # ── Frontend pages ────────────────────────────────────────────
    @app.route("/")
    def index(): return render_template("index.html")

    @app.route("/history")
    def history(): return render_template("history.html")

    @app.route("/profile")
    def profile(): return render_template("profile.html")

    @app.route("/wallet")
    def wallet_page(): return render_template("wallet.html")

    @app.route("/captain")
    def captain(): return render_template("captain.html")

    @app.route("/rider-register")
    def rider_register_page():
        from flask import redirect
        return redirect("/captain")

    @app.route("/rider-login")
    def rider_login_page():
        from flask import redirect
        return redirect("/captain")

    @app.route("/admin")
    def admin(): return render_template("admin.html")

    @app.route("/share/<token>")
    def share_ride(token): return render_template("share.html", token=token)

    # PWA files
    @app.route("/manifest.json")
    def manifest():
        return jsonify({
            "name": "SwiftRide",
            "short_name": "SwiftRide",
            "start_url": "/",
            "display": "standalone",
            "background_color": "#0f0f0f",
            "theme_color": "#f5a623",
            "description": "Fast, affordable rides across Hubli & Dharwad.",
            "icons": [
                {"src": "/static/icons/icon-192.png", "sizes": "192x192", "type": "image/png"},
                {"src": "/static/icons/icon-512.png", "sizes": "512x512", "type": "image/png"}
            ]
        })

    @app.route("/sw.js")
    def service_worker():
        return send_from_directory(static_dir, "sw.js", mimetype="application/javascript")

    @app.errorhandler(404)
    def not_found(e):
        from flask import request
        if request.path.startswith("/api/"): return jsonify({"success":False,"message":"Endpoint not found."}),404
        return render_template("index.html"),404

    @app.errorhandler(500)
    def server_error(e):
        from flask import request
        import logging; logging.getLogger(__name__).error("500: %s", e)
        if request.path.startswith("/api/"): return jsonify({"success":False,"message":"Internal server error."}),500
        return render_template("index.html"),500

    return app


def _seed_drivers():
    from backend.models.models import Driver
    if Driver.query.count() > 0: return
    sample = [
        dict(name="Ravi Kumar",   phone="9876543210",vehicle="KA-25-AB-1234",vehicle_type="Bike",vehicle_model="Honda Activa",vehicle_color="Black",lat=15.3647,lng=75.1240,rating=4.8,acceptance_rate=95,available=True,is_online=True,verification_status="approved"),
        dict(name="Suresh Patil", phone="9876543211",vehicle="KA-25-CD-5678",vehicle_type="Bike",vehicle_model="TVS Jupiter",vehicle_color="Blue",lat=15.3550,lng=75.1350,rating=4.6,acceptance_rate=90,available=True,is_online=True,verification_status="approved"),
        dict(name="Ajay Nayak",   phone="9876543212",vehicle="KA-25-EF-9012",vehicle_type="Auto",vehicle_model="Bajaj RE",vehicle_color="Yellow",lat=15.3750,lng=75.1450,rating=4.7,acceptance_rate=98,available=True,is_online=True,verification_status="approved"),
        dict(name="Priya Sharma", phone="9876543213",vehicle="KA-25-GH-3456",vehicle_type="Auto",vehicle_model="Bajaj RE",vehicle_color="Green",lat=15.4589,lng=74.9869,rating=4.9,acceptance_rate=99,available=True,is_online=True,verification_status="approved"),
        dict(name="Vikram Nair",  phone="9876543214",vehicle="KA-25-IJ-7890",vehicle_type="Car-AC",vehicle_model="Maruti Swift",vehicle_color="White",lat=15.4513,lng=75.0059,rating=4.5,acceptance_rate=85,available=True,is_online=True,verification_status="approved"),
        dict(name="Kiran Desai",  phone="9876543215",vehicle="KA-25-KL-2345",vehicle_type="Bike",vehicle_model="Hero Splendor",vehicle_color="Red",lat=15.4100,lng=75.0600,rating=4.7,acceptance_rate=92,available=True,is_online=True,verification_status="approved"),
        dict(name="Meena Kulkarni",phone="9876543216",vehicle="KA-25-MN-6789",vehicle_type="Car-NonAC",vehicle_model="Tata Indica",vehicle_color="Silver",lat=15.3900,lng=75.0900,rating=4.8,acceptance_rate=97,available=True,is_online=True,verification_status="approved"),
    ]
    for d in sample: db.session.add(Driver(**d))
    db.session.commit()
    print("[DB] Seeded 7 sample drivers.")

def _seed_promos():
    from backend.models.models import PromoCode
    if PromoCode.query.count() > 0: return
    promos=[
        PromoCode(code="FIRST50",discount_type="percent",discount_value=50,max_discount=100,min_fare=50,max_uses=1000,uses_per_user=1,cashback_percent=0,description="50% off your first ride (max ₹100)"),
        PromoCode(code="FLAT30",discount_type="flat",discount_value=30,min_fare=80,max_uses=500,uses_per_user=2,cashback_percent=10,description="Flat ₹30 off + 10% cashback"),
        PromoCode(code="WALLET20",discount_type="percent",discount_value=20,max_discount=50,min_fare=100,max_uses=200,uses_per_user=3,cashback_percent=0,description="20% off when paying with wallet"),
    ]
    for p in promos: db.session.add(p)
    db.session.commit()
    print("[DB] Seeded 3 promo codes.")
