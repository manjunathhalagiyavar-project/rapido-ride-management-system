"""
Shared Flask extensions — imported here to avoid circular imports.
"""

from flask_sqlalchemy import SQLAlchemy
from flask_socketio import SocketIO

db       = SQLAlchemy()
socketio = SocketIO()
