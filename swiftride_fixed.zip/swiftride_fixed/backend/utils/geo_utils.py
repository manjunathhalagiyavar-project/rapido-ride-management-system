"""
Geo utilities — Haversine, fare, smart driver matching, surge pricing, geo-fencing.
"""
import math
from datetime import datetime
from typing import List, Tuple

def haversine_km(lat1, lng1, lat2, lng2):
    R=6371.0; phi1,phi2=math.radians(lat1),math.radians(lat2)
    dphi=math.radians(lat2-lat1); dl=math.radians(lng2-lng1)
    a=math.sin(dphi/2)**2+math.cos(phi1)*math.cos(phi2)*math.sin(dl/2)**2
    return R*2*math.atan2(math.sqrt(a),math.sqrt(1-a))

def estimate_duration_min(distance_km, avg_speed_kmh=25.0):
    return round((distance_km/avg_speed_kmh)*60,1)

# ─── Dynamic Surge Pricing ────────────────────────────────────────────────────
VEHICLE_BASE = {"Bike":20,"Auto":30,"Car-NonAC":40,"Car-AC":50}
VEHICLE_PER_KM = {"Bike":10,"Auto":14,"Car-NonAC":16,"Car-AC":20}
VEHICLE_PER_MIN = {"Bike":0.8,"Auto":1.2,"Car-NonAC":1.5,"Car-AC":2.0}

def get_surge_multiplier(available_drivers: int, pending_rides: int) -> float:
    """Demand/supply surge: more rides vs drivers = higher multiplier."""
    if available_drivers == 0:
        return 2.5
    ratio = pending_rides / max(available_drivers, 1)
    if ratio >= 3:   return 2.0
    elif ratio >= 2: return 1.5
    elif ratio >= 1: return 1.2
    # Peak hours (7-10 AM, 5-9 PM IST)
    hour = datetime.utcnow().hour + 5  # rough IST
    if (7 <= hour <= 10) or (17 <= hour <= 21):
        return 1.15
    return 1.0

def calculate_fare(distance_km, duration_min, vehicle_type="Bike", surge=1.0):
    base    = VEHICLE_BASE.get(vehicle_type, 20)
    per_km  = VEHICLE_PER_KM.get(vehicle_type, 10)
    per_min = VEHICLE_PER_MIN.get(vehicle_type, 0.8)
    fare = (base + distance_km*per_km + duration_min*per_min) * surge
    return round(fare, 2)

# ─── Smart Driver Matching (scoring) ─────────────────────────────────────────
def score_driver(driver, pickup_lat, pickup_lng):
    dist = haversine_km(pickup_lat, pickup_lng, driver.lat, driver.lng)
    dist_score = max(0, 10 - dist)           # closer = higher score
    rating_score = (driver.rating or 4.5) * 2
    acceptance_score = (driver.acceptance_rate or 100) / 20
    # idle bonus: longer idle time = more eager
    idle_score = 0
    if driver.idle_since:
        mins_idle = (datetime.utcnow() - driver.idle_since).total_seconds() / 60
        idle_score = min(3, mins_idle / 5)
    return dist_score + rating_score + acceptance_score + idle_score, dist

def find_best_driver(pickup_lat, pickup_lng, drivers, exclude_ids=None):
    """Smart matching: score by distance, rating, acceptance rate, idle time."""
    exclude_ids = exclude_ids or []
    candidates = [d for d in drivers if d.available and d.id not in exclude_ids]
    if not candidates:
        return None, None
    scored = [(score_driver(d, pickup_lat, pickup_lng), d) for d in candidates]
    scored.sort(key=lambda x: x[0][0], reverse=True)
    (score, dist), best = scored[0]
    return best, round(dist, 2)

def find_nearest_driver(pickup_lat, pickup_lng, drivers):
    """Legacy simple nearest-driver (kept for compatibility)."""
    return find_best_driver(pickup_lat, pickup_lng, drivers)

# ─── Geo-fencing ─────────────────────────────────────────────────────────────
GEOFENCE_RADIUS_KM = 0.15  # 150 meters

def is_within_geofence(driver_lat, driver_lng, target_lat, target_lng):
    """Returns True if driver is within 150m of target (pickup/drop)."""
    dist = haversine_km(driver_lat, driver_lng, target_lat, target_lng)
    return dist <= GEOFENCE_RADIUS_KM, round(dist * 1000, 0)  # bool, meters

# ─── Route key for pool matching ─────────────────────────────────────────────
def pool_route_key(pickup_lat, pickup_lng, drop_lat, drop_lng, precision=1):
    """Encode route as string for approximate matching (1 decimal ~ 11km grid)."""
    return f"{round(pickup_lat,precision)},{round(pickup_lng,precision)}-{round(drop_lat,precision)},{round(drop_lng,precision)}"

# ─── Interpolation (simulation) ──────────────────────────────────────────────
def interpolate_position(lat1, lng1, lat2, lng2, fraction):
    return round(lat1+(lat2-lat1)*fraction, 6), round(lng1+(lng2-lng1)*fraction, 6)
