"""
OTP generation, sending (email + SMS/console simulation), and verification helpers.
FIXED: email config validation, proper error logging, SMS integration via Twilio.
"""

import random
import string
import logging
import smtplib
from datetime import datetime, timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from flask import current_app

from backend.extensions import db
from backend.models.models import OTPVerification

logger = logging.getLogger(__name__)


def generate_otp(length: int = 6) -> str:
    return "".join(random.choices(string.digits, k=length))


def _console_fallback(channel: str, contact: str, otp: str, expiry: int):
    icon = "📧" if channel == "email" else "📱"
    print("\n" + "═" * 55)
    print(f"  {icon}  DEV OTP — configure SMTP/Twilio for real delivery")
    print(f"  Contact : {contact}")
    print(f"  OTP     : {otp}")
    print(f"  Expiry  : {expiry} minutes")
    print("═" * 55 + "\n")
    logger.warning("[DEV OTP] %s -> %s", contact, otp)


def send_email_otp(email: str, otp: str) -> bool:
    username = current_app.config.get("MAIL_USERNAME", "")
    password = current_app.config.get("MAIL_PASSWORD", "")
    expiry   = current_app.config.get("OTP_EXPIRY_MINUTES", 5)

    placeholder_users = ("your_email@gmail.com", "", None)
    placeholder_pwds  = ("your_app_password_here", "xxxx xxxx xxxx xxxx", "", None)

    if username in placeholder_users or password in placeholder_pwds:
        logger.error("Email not configured — check MAIL_USERNAME / MAIL_PASSWORD in .env")
        _console_fallback("email", email, otp, expiry)
        return True

    html_body = f"""
    <div style="font-family:Arial,sans-serif;max-width:480px;margin:auto;
                background:#0f0f0f;color:#fff;border-radius:12px;overflow:hidden;">
      <div style="background:linear-gradient(135deg,#FF6B00,#FF9500);
                  padding:28px;text-align:center;">
        <h1 style="margin:0;font-size:28px;letter-spacing:2px;">SwiftRide</h1>
        <p style="margin:4px 0 0;opacity:.8;font-size:13px;">Your Ride, Your Way</p>
      </div>
      <div style="padding:32px;">
        <h2 style="margin:0 0 8px;font-size:20px;">Verification Code</h2>
        <p style="color:#aaa;margin:0 0 24px;font-size:14px;">
          Expires in {expiry} minutes.
        </p>
        <div style="background:#1a1a1a;border:2px solid #FF6B00;
                    border-radius:10px;padding:20px;text-align:center;">
          <span style="font-size:42px;font-weight:700;
                       letter-spacing:12px;color:#FF6B00;">{otp}</span>
        </div>
        <p style="color:#666;font-size:12px;margin-top:20px;">
          Never share this code. SwiftRide will never ask for your OTP.
        </p>
      </div>
    </div>"""

    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = "Your SwiftRide Verification Code"
        msg["From"]    = username
        msg["To"]      = email
        msg.attach(MIMEText(html_body, "html"))

        with smtplib.SMTP("smtp.gmail.com", 587, timeout=15) as server:
            server.ehlo()
            server.starttls()
            server.ehlo()
            server.login(username, password)
            server.sendmail(username, email, msg.as_string())

        logger.info("Email OTP sent to %s", email)
        return True

    except smtplib.SMTPAuthenticationError:
        logger.error(
            "Gmail auth failed. Use an App Password from myaccount.google.com/apppasswords"
        )
        _console_fallback("email", email, otp, expiry)
        return True
    except Exception as exc:
        logger.error("Email OTP error for %s: %s", email, exc)
        _console_fallback("email", email, otp, expiry)
        return True


def send_mobile_otp(phone: str, otp: str) -> bool:
    expiry      = current_app.config.get("OTP_EXPIRY_MINUTES", 5)
    account_sid = current_app.config.get("TWILIO_ACCOUNT_SID", "")
    auth_token  = current_app.config.get("TWILIO_AUTH_TOKEN", "")
    from_number = current_app.config.get("TWILIO_FROM_NUMBER", "")

    if account_sid and auth_token and from_number:
        try:
            from twilio.rest import Client
            client  = Client(account_sid, auth_token)
            message = client.messages.create(
                body=f"Your SwiftRide OTP is: {otp}. Valid for {expiry} min. Do not share.",
                from_=from_number,
                to=phone,
            )
            logger.info("SMS OTP sent to %s (SID: %s)", phone, message.sid)
            return True
        except ImportError:
            logger.warning("twilio package not installed. pip install twilio")
        except Exception as exc:
            logger.error("Twilio SMS error for %s: %s", phone, exc)

    _console_fallback("phone", phone, otp, expiry)
    return True


def create_and_send_otp(contact: str, contact_type: str, purpose: str = "register"):
    try:
        OTPVerification.query.filter_by(
            contact=contact, contact_type=contact_type, verified=False
        ).delete()
        db.session.commit()
    except Exception as exc:
        db.session.rollback()
        logger.error("DB error clearing old OTPs: %s", exc)

    otp_len     = current_app.config.get("OTP_LENGTH", 6)
    expiry_mins = current_app.config.get("OTP_EXPIRY_MINUTES", 5)
    otp         = generate_otp(otp_len)
    expiry      = datetime.utcnow() + timedelta(minutes=expiry_mins)

    record = OTPVerification(
        contact=contact, contact_type=contact_type,
        otp=otp, purpose=purpose, expiry_time=expiry,
    )
    try:
        db.session.add(record)
        db.session.commit()
    except Exception as exc:
        db.session.rollback()
        logger.error("DB error saving OTP: %s", exc)
        return False, "Database error. Please try again.", None

    success = send_email_otp(contact, otp) if contact_type == "email" else send_mobile_otp(contact, otp)
    if not success:
        return False, "Failed to send OTP. Please try again.", None

    return True, "OTP sent successfully.", record.id


def verify_otp(contact: str, otp_input: str):
    max_retries = current_app.config.get("OTP_MAX_RETRIES", 3)

    record = (
        OTPVerification.query
        .filter_by(contact=contact, verified=False)
        .order_by(OTPVerification.created_at.desc())
        .first()
    )

    if not record:
        return False, "No OTP request found. Please request a new OTP."
    if record.is_expired():
        return False, "OTP has expired. Please request a new one."
    if record.attempts >= max_retries:
        return False, "Too many incorrect attempts. Please request a new OTP."
    if record.otp != otp_input.strip():
        record.attempts += 1
        db.session.commit()
        remaining = max_retries - record.attempts
        return False, f"Incorrect OTP. {remaining} attempt(s) remaining."

    record.verified  = True
    record.attempts += 1
    db.session.commit()
    return True, "OTP verified successfully."
