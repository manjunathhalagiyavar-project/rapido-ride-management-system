"""
SQLAlchemy model: user_locations

Stores each "Use Current Location" / watchPosition update.
Columns:
  id          – PK
  user_id     – FK to users.id (nullable for guest sessions)
  latitude    – FLOAT
  longitude   – FLOAT
  address     – VARCHAR(500)  human-readable reverse-geocode result
  loc_type    – VARCHAR(20)   'current' | 'tracking'
  session_id  – VARCHAR(128)  Flask session ID (for guest correlation)
  created_at  – DATETIME
"""

from datetime import datetime
from backend.extensions import db


class UserLocation(db.Model):
    __tablename__ = "user_locations"

    id         = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id    = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="SET NULL"),
                           nullable=True, index=True)
    latitude   = db.Column(db.Float,       nullable=False)
    longitude  = db.Column(db.Float,       nullable=False)
    address    = db.Column(db.String(500),  nullable=False, default="")
    loc_type   = db.Column(db.String(20),   nullable=False, default="current")
    session_id = db.Column(db.String(128),  nullable=True)
    created_at = db.Column(db.DateTime,     default=datetime.utcnow, index=True)

    def to_dict(self):
        return {
            "id":         self.id,
            "user_id":    self.user_id,
            "latitude":   self.latitude,
            "longitude":  self.longitude,
            "address":    self.address,
            "type":       self.loc_type,
            "session_id": self.session_id,
            "created_at": self.created_at.isoformat(),
        }
