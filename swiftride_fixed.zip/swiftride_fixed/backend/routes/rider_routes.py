"""
Rider (Captain/Driver) routes:
  POST /api/rider/register          — full registration with documents & vehicle details
  POST /api/rider/login             — email+password or phone+password
  POST /api/rider/logout
  GET  /api/rider/me                — current logged-in rider profile
  POST /api/rider/toggle-online     — go online / offline
  POST /api/rider/reupload-docs     — re-upload docs after rejection

  GET  /api/rider/<id>/notifications         — all notifications
  POST /api/rider/<id>/notifications/read    — mark all as read

  GET  /api/rides/<ride_id>/messages         — get quick messages for a ride
  POST /api/rides/<ride_id>/messages         — send quick message (driver side)

  Admin:
  GET  /api/admin/rider-verifications        — pending rider verifications
  POST /api/admin/rider-verifications/<id>/approve
  POST /api/admin/rider-verifications/<id>/reject
"""

import os
import re
import uuid
from datetime import datetime
from flask import Blueprint, request, jsonify, session, current_app

from backend.extensions import db, socketio
from backend.models.models import Driver, Notification, RideMessage, Ride

rider_bp = Blueprint("rider", __name__, url_prefix="/api")

UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__)))), "frontend", "static", "uploads")

QUICK_MESSAGES = [
    "I'm on the way 🏍️",
    "Reached your location 📍",
    "Please call me 📞",
    "Stuck in traffic, be there soon 🚦",
    "I'm waiting outside 🕐",
    "Starting the ride now 🚀",
]

def _bad(msg, code=400):
    return jsonify({"success": False, "message": msg}), code

def _ok(msg, **kwargs):
    return jsonify({"success": True, "message": msg, **kwargs})

def _valid_email(email):
    return re.match(r'^[^\@\s]+@[^\@\s]+\.[^\@\s]+$', email) is not None

def _valid_phone(phone):
    cleaned = re.sub(r'[\s\-()]', '', phone)
    return re.match(r'^(\+91|91)?[6-9]\d{9}$', cleaned) is not None

def _normalise_phone(phone):
    cleaned = re.sub(r'[\s\-()]', '', phone)
    return re.sub(r'^(\+91|91)', '', cleaned)

def _require_rider():
    did = session.get("driver_id")
    if not did:
        return None, (_bad("Rider authentication required.", 401))
    driver = Driver.query.get(did)
    if not driver:
        session.pop("driver_id", None)
        return None, (_bad("Rider not found.", 401))
    return driver, None

def _require_admin():
    if not session.get("admin_logged_in"):
        return _bad("Admin authentication required.", 401)
    return None

def _save_upload(file, prefix):
    """Save an uploaded file and return its stored filename."""
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    ext = os.path.splitext(file.filename)[1].lower() if file.filename else ".jpg"
    filename = f"{prefix}_{uuid.uuid4().hex}{ext}"
    file.save(os.path.join(UPLOAD_FOLDER, filename))
    return filename

def _notify_driver(driver_id, ride_id, ntype, title, message):
    n = Notification(driver_id=driver_id, ride_id=ride_id,
                     type=ntype, title=title, message=message)
    db.session.add(n)


# ─── Rider Register ───────────────────────────────────────────────────────────

@rider_bp.route("/rider/register", methods=["POST"])
def rider_register():
    """
    Multipart form data:
      name, email (optional), phone, password, confirm_password,
      vehicle_type, vehicle_number, vehicle_model, vehicle_color,
      doc_license (file), doc_rc (file), doc_insurance (file), doc_photo (file)
    """
    try:
        # Text fields
        name             = (request.form.get("name") or "").strip()
        email            = (request.form.get("email") or "").strip().lower() or None
        phone            = (request.form.get("phone") or "").strip()
        password         = request.form.get("password") or ""
        confirm_password = request.form.get("confirm_password") or ""
        vehicle_type     = (request.form.get("vehicle_type") or "Bike").strip()
        vehicle_number   = (request.form.get("vehicle_number") or "").strip().upper()
        vehicle_model    = (request.form.get("vehicle_model") or "").strip()
        vehicle_color    = (request.form.get("vehicle_color") or "").strip()
        accept_terms     = request.form.get("accept_terms") == "true"

        # Validations
        if not name:
            return _bad("Full name is required.")
        if not phone:
            return _bad("Mobile number is required.")
        if not _valid_phone(phone):
            return _bad("Please enter a valid 10-digit Indian mobile number.")
        phone = _normalise_phone(phone)
        if email and not _valid_email(email):
            return _bad("Please enter a valid email address.")
        if len(password) < 6:
            return _bad("Password must be at least 6 characters.")
        if password != confirm_password:
            return _bad("Passwords do not match.")
        if not accept_terms:
            return _bad("You must accept the Terms & Conditions.")
        if not vehicle_number:
            return _bad("Vehicle number is required.")
        if vehicle_type not in ["Bike", "Auto", "Car-NonAC", "Car-AC"]:
            return _bad("Invalid vehicle type.")

        # Check duplicates
        if Driver.query.filter_by(phone=phone).first():
            return _bad("A rider account with this phone number already exists.")
        if email and Driver.query.filter_by(email=email).first():
            return _bad("A rider account with this email already exists.")

        # Document uploads
        doc_license   = request.files.get("doc_license")
        doc_rc        = request.files.get("doc_rc")
        doc_insurance = request.files.get("doc_insurance")
        doc_photo     = request.files.get("doc_photo")

        if not doc_license:
            return _bad("Driving license document is required.")

        license_file   = _save_upload(doc_license, f"license_{phone}") if doc_license else None
        rc_file        = _save_upload(doc_rc, f"rc_{phone}") if doc_rc else None
        insurance_file = _save_upload(doc_insurance, f"insurance_{phone}") if doc_insurance else None
        photo_file     = _save_upload(doc_photo, f"photo_{phone}") if doc_photo else None

        # Create driver record
        driver = Driver(
            name           = name,
            email          = email,
            phone          = phone,
            vehicle        = vehicle_number,
            vehicle_type   = vehicle_type,
            vehicle_model  = vehicle_model,
            vehicle_color  = vehicle_color,
            lat            = 15.3647,
            lng            = 75.1240,
            available      = False,
            is_online      = False,
            verification_status = "pending",
            doc_license    = license_file,
            doc_rc         = rc_file,
            doc_insurance  = insurance_file,
            doc_photo      = photo_file,
        )
        driver.set_password(password)
        db.session.add(driver)
        db.session.commit()

        # Notify admin (as a notification for driver_id=None, user_id=None)
        _notify_driver(driver.id, None, "registration",
                       "Registration Submitted",
                       "Your documents have been submitted and are under review. You'll be notified once verified.")
        db.session.commit()

        return _ok("Registration successful! Your documents are under review. Please wait for admin approval.", driver=driver.to_dict())

    except Exception as e:
        db.session.rollback()
        import logging, traceback
        logging.getLogger(__name__).error("Rider register error: %s\n%s", e, traceback.format_exc())
        return _bad(f"Registration failed: {str(e)}", 500)


# ─── Rider Login ─────────────────────────────────────────────────────────────

@rider_bp.route("/rider/login", methods=["POST"])
def rider_login():
    """Body: { contact, password, contact_type: "email"|"phone" }"""
    try:
        data         = request.get_json(silent=True) or {}
        contact      = (data.get("contact") or "").strip()
        password     = data.get("password") or ""
        contact_type = data.get("contact_type", "phone")

        if not contact or not password:
            return _bad("Contact and password are required.")

        if contact_type == "email":
            contact = contact.lower()
            if not _valid_email(contact):
                return _bad("Please enter a valid email address.")
            driver = Driver.query.filter_by(email=contact).first()
        else:
            if not _valid_phone(contact):
                return _bad("Please enter a valid 10-digit Indian mobile number.")
            contact = _normalise_phone(contact)
            driver = Driver.query.filter_by(phone=contact).first()

        if not driver:
            return _bad("No rider account found. Please register first.")
        if not driver.check_password(password):
            return _bad("Incorrect password. Please try again.")

        session["driver_id"]   = driver.id
        session["driver_name"] = driver.name
        session.permanent      = True

        return _ok("Login successful! Welcome back.", driver=driver.to_dict())

    except Exception as e:
        import logging, traceback
        logging.getLogger(__name__).error("Rider login error: %s\n%s", e, traceback.format_exc())
        return _bad(f"Login failed: {str(e)}", 500)


# ─── Rider Logout ─────────────────────────────────────────────────────────────

@rider_bp.route("/rider/logout", methods=["POST"])
def rider_logout():
    driver, err = _require_rider()
    if err:
        return err
    # Go offline when logging out
    driver.is_online = False
    driver.available = False
    db.session.commit()
    session.pop("driver_id", None)
    session.pop("driver_name", None)
    return _ok("Logged out successfully.")


# ─── Rider Me ─────────────────────────────────────────────────────────────────

@rider_bp.route("/rider/me", methods=["GET"])
def rider_me():
    driver, err = _require_rider()
    if err:
        return err
    return _ok("Authenticated.", driver=driver.to_dict())


# ─── Toggle Online / Offline ──────────────────────────────────────────────────

@rider_bp.route("/rider/toggle-online", methods=["POST"])
def toggle_online():
    driver, err = _require_rider()
    if err:
        return err

    if driver.verification_status != "approved":
        return _bad("Your account must be approved by admin before going online.")

    data       = request.get_json(silent=True) or {}
    go_online  = data.get("online", True)

    driver.is_online = go_online
    driver.available = go_online   # available for ride matching only when online
    db.session.commit()

    status = "online" if go_online else "offline"
    return _ok(f"You are now {status}.", is_online=go_online)


# ─── Re-upload Documents (after rejection) ────────────────────────────────────

@rider_bp.route("/rider/reupload-docs", methods=["POST"])
def reupload_docs():
    driver, err = _require_rider()
    if err:
        return err

    if driver.verification_status not in ["rejected", "pending"]:
        return _bad("Re-upload is only allowed when status is rejected or pending.")

    doc_license   = request.files.get("doc_license")
    doc_rc        = request.files.get("doc_rc")
    doc_insurance = request.files.get("doc_insurance")
    doc_photo     = request.files.get("doc_photo")

    if doc_license:
        driver.doc_license   = _save_upload(doc_license, f"license_{driver.phone}")
    if doc_rc:
        driver.doc_rc        = _save_upload(doc_rc, f"rc_{driver.phone}")
    if doc_insurance:
        driver.doc_insurance = _save_upload(doc_insurance, f"insurance_{driver.phone}")
    if doc_photo:
        driver.doc_photo     = _save_upload(doc_photo, f"photo_{driver.phone}")

    driver.verification_status = "pending"
    driver.rejection_reason    = None
    db.session.commit()

    _notify_driver(driver.id, None, "resubmitted",
                   "Documents Resubmitted",
                   "Your documents have been resubmitted for review.")
    db.session.commit()

    return _ok("Documents resubmitted successfully. Please wait for admin review.", driver=driver.to_dict())


# ─── Notifications ────────────────────────────────────────────────────────────

@rider_bp.route("/rider/<int:driver_id>/notifications", methods=["GET"])
def get_notifications(driver_id):
    driver = Driver.query.get(driver_id)
    if not driver:
        return _bad("Rider not found.", 404)

    notifs = Notification.query.filter_by(driver_id=driver_id)\
                               .order_by(Notification.created_at.desc())\
                               .limit(50).all()
    unread = sum(1 for n in notifs if not n.is_read)
    return _ok("Notifications fetched.", notifications=[n.to_dict() for n in notifs], unread=unread)


@rider_bp.route("/rider/<int:driver_id>/notifications/read", methods=["POST"])
def mark_notifications_read(driver_id):
    Notification.query.filter_by(driver_id=driver_id, is_read=False)\
                      .update({"is_read": True})
    db.session.commit()
    return _ok("All notifications marked as read.")


# ─── Quick Messages ───────────────────────────────────────────────────────────

@rider_bp.route("/rides/<int:ride_id>/messages", methods=["GET"])
def get_messages(ride_id):
    msgs = RideMessage.query.filter_by(ride_id=ride_id)\
                            .order_by(RideMessage.created_at.asc()).all()
    return _ok("Messages fetched.",
               messages=[m.to_dict() for m in msgs],
               quick_messages=QUICK_MESSAGES)


@rider_bp.route("/rides/<int:ride_id>/messages", methods=["POST"])
def send_message(ride_id):
    data    = request.get_json(silent=True) or {}
    text    = (data.get("message") or "").strip()
    sender  = data.get("sender", "driver")   # "driver" or "user"

    if not text:
        return _bad("Message cannot be empty.")
    if len(text) > 500:
        return _bad("Message too long.")
    if sender not in ["driver", "user"]:
        return _bad("sender must be 'driver' or 'user'.")

    ride = Ride.query.get(ride_id)
    if not ride:
        return _bad("Ride not found.", 404)

    msg = RideMessage(ride_id=ride_id, sender=sender, message=text)
    db.session.add(msg)

    # Create notification for the other party
    if sender == "driver" and ride.user_id:
        n = Notification(user_id=ride.user_id, ride_id=ride_id,
                         type="message", title="Message from your rider",
                         message=text)
        db.session.add(n)
    elif sender == "user" and ride.driver_id:
        _notify_driver(ride.driver_id, ride_id, "message", "Message from passenger", text)

    db.session.commit()
    return _ok("Message sent.", message=msg.to_dict())


# ─── Quick Messages List ──────────────────────────────────────────────────────

@rider_bp.route("/rider/quick-messages", methods=["GET"])
def quick_messages():
    return _ok("Quick messages fetched.", quick_messages=QUICK_MESSAGES)


# ─── Admin: Rider Verifications ───────────────────────────────────────────────

@rider_bp.route("/admin/rider-verifications", methods=["GET"])
def admin_rider_verifications():
    err = _require_admin()
    if err:
        return err

    status_filter = request.args.get("status", "pending")
    query = Driver.query
    if status_filter != "all":
        query = query.filter_by(verification_status=status_filter)
    drivers = query.order_by(Driver.created_at.desc()).all()
    return _ok("Riders fetched.", riders=[d.to_dict() for d in drivers])


@rider_bp.route("/admin/rider-verifications/<int:driver_id>/approve", methods=["POST"])
def admin_approve_rider(driver_id):
    err = _require_admin()
    if err:
        return err

    driver = Driver.query.get(driver_id)
    if not driver:
        return _bad("Rider not found.", 404)

    driver.verification_status = "approved"
    driver.rejection_reason    = None
    driver.verified_at         = datetime.utcnow()

    _notify_driver(driver_id, None, "approved",
                   "🎉 Account Approved!",
                   "Congratulations! Your account has been approved. You can now go online and accept rides.")
    db.session.commit()

    # Real-time push to captain if they are connected
    socketio.emit("verification_update", {
        "status": "approved",
        "message": "🎉 Your account has been approved! You can now go online and accept rides."
    }, room=f"captain_{driver_id}")

    return _ok("Rider approved successfully.", driver=driver.to_dict())


@rider_bp.route("/admin/rider-verifications/<int:driver_id>/reject", methods=["POST"])
def admin_reject_rider(driver_id):
    err = _require_admin()
    if err:
        return err

    driver = Driver.query.get(driver_id)
    if not driver:
        return _bad("Rider not found.", 404)

    data   = request.get_json(silent=True) or {}
    reason = (data.get("reason") or "Documents did not meet requirements.").strip()

    driver.verification_status = "rejected"
    driver.rejection_reason    = reason
    driver.available           = False
    driver.is_online           = False

    _notify_driver(driver_id, None, "rejected",
                   "❌ Account Rejected",
                   f"Your account was rejected: {reason}. Please re-upload your documents.")
    db.session.commit()

    # Real-time push to captain if they are connected
    socketio.emit("verification_update", {
        "status": "rejected",
        "reason": reason,
        "message": f"❌ Your account was rejected: {reason}. Please re-upload your documents."
    }, room=f"captain_{driver_id}")

    return _ok("Rider rejected.", driver=driver.to_dict())
