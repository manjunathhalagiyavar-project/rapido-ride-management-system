"""
Ride routes — full feature set:
  POST /api/book-ride            book with vehicle type, promo, payment, multi-stop
  POST /api/book-ride/pool       pool ride booking
  POST /api/schedule-ride        future booking
  GET  /api/scheduled-rides      user's scheduled rides
  DELETE /api/schedule-ride/<id> cancel scheduled
  POST /api/rides/<id>/sos       SOS alert
  GET  /api/rides/<id>/share     share token
  GET  /api/share/<token>        public ride status
  POST /api/rides/<id>/rate      rate captain
  GET  /api/rides/<id>/rate      get rating
  POST /api/promo/validate       validate promo code
  GET  /api/wallet               user wallet + transactions
  POST /api/wallet/add           add money to wallet
  POST /api/estimate             fare estimate with vehicle options
  + all existing captain/admin routes
"""
import json, random, secrets
from datetime import datetime, timedelta
from flask import Blueprint, request, jsonify, session
from backend.extensions import db
from backend.models.models import (
    Driver, Ride, RideStop, RidePool, DriverPaymentMethod, DriverWithdrawal,
    UserWallet, WalletTransaction, PromoCode, PromoUsage, RideRating,
    ScheduledRide, SosAlert, FraudLog, CaptainBonus, User
)
from backend.utils.geo_utils import (
    haversine_km, estimate_duration_min, calculate_fare,
    get_surge_multiplier, find_best_driver, find_nearest_driver,
    is_within_geofence, pool_route_key
)

ride_bp = Blueprint("rides", __name__, url_prefix="/api")

def _bad(msg, code=400): return jsonify({"success":False,"message":msg}), code
def _ok(msg, **kw): return jsonify({"success":True,"message":msg,**kw})
def _require_auth():
    uid=session.get("user_id")
    return (uid, None) if uid else (None, _bad("Authentication required.",401))
def _require_admin():
    if not session.get("admin_logged_in"): return _bad("Admin required.",401)
    return None


# ─── Estimate (multi-vehicle) ──────────────────────────────────────────────────
@ride_bp.route("/estimate", methods=["POST"])
def estimate():
    data=request.get_json(silent=True) or {}
    try:
        p_lat=float(data["pickup_lat"]); p_lng=float(data["pickup_lng"])
        d_lat=float(data["drop_lat"]);   d_lng=float(data["drop_lng"])
    except: return _bad("Valid lat/lng required.")
    dist = haversine_km(p_lat,p_lng,d_lat,d_lng)
    dur  = estimate_duration_min(dist)
    # Count available/pending for surge
    avail   = Driver.query.filter_by(available=True).count()
    pending = Ride.query.filter_by(status="requested").count()
    surge   = get_surge_multiplier(avail, pending)
    options=[]
    for vtype in ["Bike","Auto","Car-NonAC","Car-AC"]:
        fare=calculate_fare(dist,dur,vtype,surge)
        options.append({"vehicle_type":vtype,"fare":fare,"surge":round(surge,2),"distance_km":round(dist,2),"duration_min":dur})
    return _ok("Estimate ready.", options=options, surge=round(surge,2))


# ─── Book Ride ─────────────────────────────────────────────────────────────────
@ride_bp.route("/book-ride", methods=["POST"])
def book_ride():
    uid,err=_require_auth()
    if err: return err
    data=request.get_json(silent=True) or {}
    req_fields=["pickup_name","pickup_lat","pickup_lng","drop_name","drop_lat","drop_lng"]
    missing=[f for f in req_fields if not data.get(f)]
    if missing: return _bad(f"Missing: {', '.join(missing)}")
    try:
        p_lat=float(data["pickup_lat"]); p_lng=float(data["pickup_lng"])
        d_lat=float(data["drop_lat"]);   d_lng=float(data["drop_lng"])
    except: return _bad("Lat/lng must be numbers.")

    vehicle_type = data.get("vehicle_type","Bike")
    payment_method = data.get("payment_method","cash")
    promo_input = (data.get("promo_code") or "").strip().upper()

    dist = haversine_km(p_lat,p_lng,d_lat,d_lng)
    dur  = estimate_duration_min(dist)
    avail_cnt   = Driver.query.filter_by(available=True).count()
    pending_cnt = Ride.query.filter_by(status="requested").count()
    surge = get_surge_multiplier(avail_cnt, pending_cnt)
    fare  = calculate_fare(dist, dur, vehicle_type, surge)

    # Promo code validation
    discount=0.0; cashback=0.0; promo_obj=None
    if promo_input:
        promo_obj = PromoCode.query.filter_by(code=promo_input).first()
        if not promo_obj: return _bad("Invalid promo code.")
        ok, msg = promo_obj.is_valid()
        if not ok: return _bad(msg)
        if fare < (promo_obj.min_fare or 0): return _bad(f"Minimum fare ₹{promo_obj.min_fare} required.")
        # Check user usage
        user_uses = PromoUsage.query.filter_by(promo_id=promo_obj.id, user_id=uid).count()
        if user_uses >= promo_obj.uses_per_user: return _bad("You have already used this promo code.")
        if promo_obj.discount_type=="percent":
            discount=round(fare*promo_obj.discount_value/100,2)
            if promo_obj.max_discount: discount=min(discount,promo_obj.max_discount)
        else:
            discount=min(promo_obj.discount_value, fare)
        cashback=round(fare*promo_obj.cashback_percent/100,2) if promo_obj.cashback_percent else 0

    final_fare=round(max(fare-discount,0),2)

    # Wallet check
    if payment_method=="wallet":
        wallet=UserWallet.query.filter_by(user_id=uid).first()
        if not wallet or wallet.balance < final_fare:
            return _bad(f"Insufficient wallet balance. Need ₹{final_fare}.")

    # Fraud detection: >3 rides in 10 min
    ten_min_ago=datetime.utcnow()-timedelta(minutes=10)
    recent=Ride.query.filter(Ride.user_id==uid, Ride.requested_at>=ten_min_ago).count()
    if recent>3:
        db.session.add(FraudLog(user_id=uid,reason=f"User booked {recent} rides in 10 min",severity="high"))
        db.session.commit()
        return _bad("Too many ride requests. Please wait a few minutes.")

    # Find best driver (excluding declined)
    declined=json.loads(data.get("declined_drivers","[]") or "[]") if isinstance(data.get("declined_drivers"),str) else []
    avail_drivers=Driver.query.filter_by(available=True,verification_status="approved").all()
    driver,_=find_best_driver(p_lat,p_lng,avail_drivers,exclude_ids=declined)
    if not driver: return _bad("No drivers available right now.")

    ride_pin=str(random.randint(1000,9999))
    share_token=secrets.token_urlsafe(32)

    ride=Ride(
        user_id=uid, driver_id=driver.id,
        pickup_name=data["pickup_name"], pickup_lat=p_lat, pickup_lng=p_lng,
        drop_name=data["drop_name"],     drop_lat=d_lat,   drop_lng=d_lng,
        vehicle_type=vehicle_type, distance_km=round(dist,2),
        duration_min=dur, fare=fare, surge_multiplier=surge,
        payment_method=payment_method,
        promo_code=promo_input or None, discount=discount, final_fare=final_fare,
        status="accepted", ride_pin=ride_pin, share_token=share_token,
        accepted_at=datetime.utcnow(), declined_drivers=json.dumps(declined)
    )
    db.session.add(ride)
    driver.available=False
    db.session.flush()

    # Multi-stop rides
    stops_data=data.get("stops",[])
    for i,st in enumerate(stops_data):
        s=RideStop(ride_id=ride.id,stop_order=i+1,name=st.get("name","Stop"),lat=float(st["lat"]),lng=float(st["lng"]))
        db.session.add(s)

    # Promo usage
    if promo_obj:
        db.session.add(PromoUsage(promo_id=promo_obj.id,user_id=uid,ride_id=ride.id))
        promo_obj.used_count+=1

    # Wallet deduction
    if payment_method=="wallet":
        wallet=UserWallet.query.filter_by(user_id=uid).first()
        wallet.balance=round(wallet.balance-final_fare,2)
        wallet.updated_at=datetime.utcnow()
        db.session.add(WalletTransaction(wallet_id=wallet.id,user_id=uid,ride_id=ride.id,
            txn_type="debit",amount=final_fare,description=f"Ride #{ride.id} payment",balance_after=wallet.balance))
        ride.paid=True
        # Cashback
        if cashback>0:
            wallet.balance=round(wallet.balance+cashback,2)
            db.session.add(WalletTransaction(wallet_id=wallet.id,user_id=uid,ride_id=ride.id,
                txn_type="cashback",amount=cashback,description=f"Promo cashback for ride #{ride.id}",balance_after=wallet.balance))

    # Captain bonus check (milestone: every 10 rides)
    completed=(driver.total_rides_completed or 0)
    if completed>0 and completed%10==0:
        bonus_amt=50.0
        db.session.add(CaptainBonus(driver_id=driver.id,bonus_type="milestone",
            amount=bonus_amt,description=f"Completed {completed} rides bonus"))

    db.session.commit()
    return _ok("Ride booked!",ride=ride.to_dict(),share_url=f"/share/{share_token}")


# ─── Pool Ride Booking ─────────────────────────────────────────────────────────
@ride_bp.route("/book-ride/pool", methods=["POST"])
def book_pool_ride():
    uid,err=_require_auth()
    if err: return err
    data=request.get_json(silent=True) or {}
    try:
        p_lat=float(data["pickup_lat"]); p_lng=float(data["pickup_lng"])
        d_lat=float(data["drop_lat"]);   d_lng=float(data["drop_lng"])
    except: return _bad("Valid lat/lng required.")

    route_key=pool_route_key(p_lat,p_lng,d_lat,d_lng)
    # Find open pool with same route
    pool=RidePool.query.filter_by(status="open",route_key=route_key).filter(
        RidePool.seats_taken<RidePool.max_seats).first()

    dist=haversine_km(p_lat,p_lng,d_lat,d_lng)
    dur=estimate_duration_min(dist)
    fare=round(calculate_fare(dist,dur,"Auto")*0.65,2)  # 35% cheaper for pool

    if not pool:
        pool=RidePool(vehicle_type="Auto",route_key=route_key,max_seats=2)
        db.session.add(pool); db.session.flush()

    avail=Driver.query.filter_by(available=True,verification_status="approved",vehicle_type="Auto").all()
    driver,_=find_nearest_driver(p_lat,p_lng,avail)

    ride=Ride(user_id=uid,driver_id=driver.id if driver else None,
        pickup_name=data.get("pickup_name","Pickup"),pickup_lat=p_lat,pickup_lng=p_lng,
        drop_name=data.get("drop_name","Drop"),drop_lat=d_lat,drop_lng=d_lng,
        vehicle_type="Auto",distance_km=round(dist,2),duration_min=dur,
        fare=fare,final_fare=fare,payment_method=data.get("payment_method","cash"),
        status="accepted",ride_pin=str(random.randint(1000,9999)),
        share_token=secrets.token_urlsafe(32),pool_id=pool.id,
        accepted_at=datetime.utcnow())
    db.session.add(ride)
    pool.seats_taken+=1
    if pool.seats_taken>=pool.max_seats: pool.status="full"
    if driver: driver.available=False
    db.session.commit()
    return _ok("Pool ride booked!",ride=ride.to_dict(),pool=pool.to_dict(),discount_note="35% cheaper than regular ride!")


# ─── Ride History ──────────────────────────────────────────────────────────────
@ride_bp.route("/rides", methods=["GET"])
def ride_history():
    uid,err=_require_auth()
    if err: return err
    rides=Ride.query.filter_by(user_id=uid).order_by(Ride.requested_at.desc()).limit(50).all()
    return _ok("Rides fetched.",rides=[r.to_dict() for r in rides])

@ride_bp.route("/rides/<int:ride_id>", methods=["GET"])
def get_ride(ride_id):
    uid,err=_require_auth()
    if err: return err
    ride=Ride.query.filter_by(id=ride_id,user_id=uid).first()
    if not ride: return _bad("Ride not found.",404)
    return _ok("Ride fetched.",ride=ride.to_dict())

@ride_bp.route("/rides/<int:ride_id>/cancel", methods=["POST"])
def cancel_ride(ride_id):
    uid,err=_require_auth()
    if err: return err
    ride=Ride.query.filter_by(id=ride_id,user_id=uid).first()
    if not ride: return _bad("Ride not found.",404)
    if ride.status in ("completed","cancelled"): return _bad(f"Cannot cancel: ride is {ride.status}.")
    ride.status="cancelled"
    if ride.driver: ride.driver.available=True
    # Wallet refund
    if ride.payment_method=="wallet" and ride.paid:
        wallet=UserWallet.query.filter_by(user_id=uid).first()
        if wallet:
            wallet.balance=round(wallet.balance+(ride.final_fare or 0),2)
            db.session.add(WalletTransaction(wallet_id=wallet.id,user_id=uid,ride_id=ride.id,
                txn_type="refund",amount=ride.final_fare or 0,description=f"Refund for cancelled ride #{ride.id}",balance_after=wallet.balance))
    # Update driver acceptance rate (declined = lower)
    if ride.driver:
        d=ride.driver; d.acceptance_rate=max(0,round(((d.acceptance_rate or 100)*0.95),1))
    db.session.commit()
    return _ok("Ride cancelled.",ride=ride.to_dict())

@ride_bp.route("/rides/<int:ride_id>/verify-pin", methods=["POST"])
def verify_pin(ride_id):
    data=request.get_json(silent=True) or {}
    ride=Ride.query.get(ride_id)
    if not ride: return _bad("Ride not found.",404)
    if data.get("pin")==ride.ride_pin:
        ride.status="ongoing"; ride.started_at=datetime.utcnow()
        if ride.driver: ride.driver.idle_since=None
        db.session.commit()
        return _ok("PIN verified. Ride started!",ride=ride.to_dict())
    return _bad("Invalid PIN.")


# ─── SOS ──────────────────────────────────────────────────────────────────────
@ride_bp.route("/rides/<int:ride_id>/sos", methods=["POST"])
def sos_alert(ride_id):
    uid=session.get("user_id")
    data=request.get_json(silent=True) or {}
    sos=SosAlert(user_id=uid,ride_id=ride_id,
        lat=data.get("lat"),lng=data.get("lng"),
        message=data.get("message","SOS triggered"))
    db.session.add(sos)
    db.session.commit()
    return _ok("SOS alert sent! Help is on the way.",sos_id=sos.id)

@ride_bp.route("/sos/<int:sos_id>/resolve", methods=["POST"])
def resolve_sos(sos_id):
    err=_require_admin()
    if err: return err
    sos=SosAlert.query.get(sos_id)
    if not sos: return _bad("SOS not found.",404)
    sos.resolved=True; db.session.commit()
    return _ok("SOS resolved.")


# ─── Ride Sharing Link ─────────────────────────────────────────────────────────
@ride_bp.route("/rides/<int:ride_id>/share", methods=["GET"])
def get_share_link(ride_id):
    uid,err=_require_auth()
    if err: return err
    ride=Ride.query.filter_by(id=ride_id,user_id=uid).first()
    if not ride: return _bad("Ride not found.",404)
    return _ok("Share link generated.",share_url=f"/share/{ride.share_token}",token=ride.share_token)

@ride_bp.route("/share/<token>", methods=["GET"])
def public_ride_status(token):
    ride=Ride.query.filter_by(share_token=token).first()
    if not ride: return _bad("Invalid share link.",404)
    return _ok("Ride status.",ride={
        "id":ride.id,"status":ride.status,"pickup_name":ride.pickup_name,
        "drop_name":ride.drop_name,"vehicle_type":ride.vehicle_type,
        "driver_name":ride.driver.name if ride.driver else None,
        "driver_vehicle":ride.driver.vehicle if ride.driver else None,
    })


# ─── Rating ───────────────────────────────────────────────────────────────────
@ride_bp.route("/rides/<int:ride_id>/rate", methods=["POST"])
def rate_ride(ride_id):
    uid,err=_require_auth()
    if err: return err
    ride=Ride.query.filter_by(id=ride_id,user_id=uid).first()
    if not ride: return _bad("Ride not found.",404)
    if ride.status!="completed": return _bad("Can only rate completed rides.")
    if ride.rating: return _bad("Already rated.")
    data=request.get_json(silent=True) or {}
    stars=int(data.get("stars",5))
    if not 1<=stars<=5: return _bad("Stars must be 1–5.")
    r=RideRating(ride_id=ride_id,user_id=uid,driver_id=ride.driver_id,stars=stars,review=data.get("review"))
    db.session.add(r)
    # Update driver average rating
    if ride.driver:
        d=ride.driver
        total=(d.rating or 4.5)*(d.total_ratings or 1)
        d.total_ratings=(d.total_ratings or 1)+1
        d.rating=round((total+stars)/d.total_ratings,2)
    db.session.commit()
    return _ok("Rating submitted!",rating=r.to_dict())

@ride_bp.route("/rides/<int:ride_id>/rate", methods=["GET"])
def get_rating(ride_id):
    rating=RideRating.query.filter_by(ride_id=ride_id).first()
    return _ok("Rating fetched.",rating=rating.to_dict() if rating else None)


# ─── Promo Code Validation ────────────────────────────────────────────────────
@ride_bp.route("/promo/validate", methods=["POST"])
def validate_promo():
    uid,err=_require_auth()
    if err: return err
    data=request.get_json(silent=True) or {}
    code=(data.get("code") or "").strip().upper()
    fare=float(data.get("fare",0))
    if not code: return _bad("Promo code required.")
    promo=PromoCode.query.filter_by(code=code).first()
    if not promo: return _bad("Invalid promo code.")
    ok,msg=promo.is_valid()
    if not ok: return _bad(msg)
    if fare<(promo.min_fare or 0): return _bad(f"Minimum fare ₹{promo.min_fare} required.")
    uses=PromoUsage.query.filter_by(promo_id=promo.id,user_id=uid).count()
    if uses>=promo.uses_per_user: return _bad("You have already used this promo code.")
    if promo.discount_type=="percent":
        discount=round(fare*promo.discount_value/100,2)
        if promo.max_discount: discount=min(discount,promo.max_discount)
    else:
        discount=min(promo.discount_value,fare)
    cashback=round(fare*promo.cashback_percent/100,2) if promo.cashback_percent else 0
    return _ok("Promo valid!",promo=promo.to_dict(),discount=discount,cashback=cashback,
               final_fare=round(max(fare-discount,0),2))


# ─── Wallet ───────────────────────────────────────────────────────────────────
@ride_bp.route("/wallet", methods=["GET"])
def get_wallet():
    uid,err=_require_auth()
    if err: return err
    wallet=UserWallet.query.filter_by(user_id=uid).first()
    if not wallet:
        wallet=UserWallet(user_id=uid,balance=0.0)
        db.session.add(wallet); db.session.commit()
    txns=WalletTransaction.query.filter_by(user_id=uid).order_by(WalletTransaction.created_at.desc()).limit(30).all()
    return _ok("Wallet fetched.",wallet=wallet.to_dict(),transactions=[t.to_dict() for t in txns])

@ride_bp.route("/wallet/add", methods=["POST"])
def add_wallet_money():
    uid,err=_require_auth()
    if err: return err
    data=request.get_json(silent=True) or {}
    try:
        amount=float(data.get("amount",0))
        if amount<=0: raise ValueError
    except: return _bad("Valid amount required.")
    if amount>10000: return _bad("Max top-up ₹10,000 at a time.")
    wallet=UserWallet.query.filter_by(user_id=uid).first()
    if not wallet:
        wallet=UserWallet(user_id=uid,balance=0.0); db.session.add(wallet); db.session.flush()
    wallet.balance=round(wallet.balance+amount,2); wallet.updated_at=datetime.utcnow()
    db.session.add(WalletTransaction(wallet_id=wallet.id,user_id=uid,txn_type="credit",
        amount=amount,description="Wallet top-up",balance_after=wallet.balance))
    db.session.commit()
    return _ok(f"₹{amount} added to wallet.",wallet=wallet.to_dict())


# ─── Scheduled Rides ──────────────────────────────────────────────────────────
@ride_bp.route("/schedule-ride", methods=["POST"])
def schedule_ride():
    uid,err=_require_auth()
    if err: return err
    data=request.get_json(silent=True) or {}
    try:
        p_lat=float(data["pickup_lat"]); p_lng=float(data["pickup_lng"])
        d_lat=float(data["drop_lat"]);   d_lng=float(data["drop_lng"])
        sched_at=datetime.fromisoformat(data["scheduled_at"])
    except Exception as e: return _bad(f"Invalid data: {e}")
    if sched_at<=datetime.utcnow()+timedelta(minutes=14):
        return _bad("Scheduled time must be at least 15 minutes from now.")
    if sched_at>datetime.utcnow()+timedelta(days=7):
        return _bad("Can schedule at most 7 days in advance.")
    s=ScheduledRide(user_id=uid,pickup_name=data.get("pickup_name","Pickup"),
        pickup_lat=p_lat,pickup_lng=p_lng,drop_name=data.get("drop_name","Drop"),
        drop_lat=d_lat,drop_lng=d_lng,vehicle_type=data.get("vehicle_type","Bike"),
        scheduled_at=sched_at)
    db.session.add(s); db.session.commit()
    return _ok("Ride scheduled!",scheduled=s.to_dict())

@ride_bp.route("/scheduled-rides", methods=["GET"])
def get_scheduled():
    uid,err=_require_auth()
    if err: return err
    rides=ScheduledRide.query.filter_by(user_id=uid).order_by(ScheduledRide.scheduled_at).all()
    return _ok("Scheduled rides fetched.",rides=[r.to_dict() for r in rides])

@ride_bp.route("/schedule-ride/<int:sid>", methods=["DELETE"])
def cancel_scheduled(sid):
    uid,err=_require_auth()
    if err: return err
    s=ScheduledRide.query.filter_by(id=sid,user_id=uid).first()
    if not s: return _bad("Scheduled ride not found.",404)
    if s.status!="pending": return _bad("Cannot cancel: already dispatched.")
    s.status="cancelled"; db.session.commit()
    return _ok("Scheduled ride cancelled.")


# ─── Captain Routes ────────────────────────────────────────────────────────────
@ride_bp.route("/captain/rides", methods=["GET"])
def captain_rides():
    did=session.get("driver_id")
    if not did: return _bad("Captain auth required.",401)
    rides=Ride.query.filter_by(driver_id=did).order_by(Ride.requested_at.desc()).limit(50).all()
    return _ok("Rides fetched.",rides=[r.to_dict() for r in rides])

@ride_bp.route("/captain/rides/<int:ride_id>/status", methods=["POST"])
def captain_update_status(ride_id):
    did=session.get("driver_id")
    if not did: return _bad("Captain auth required.",401)
    data=request.get_json(silent=True) or {}
    new_status=data.get("status")
    valid=("accepted","ongoing","completed","cancelled")
    if new_status not in valid: return _bad(f"Invalid status.")
    ride=Ride.query.filter_by(id=ride_id,driver_id=did).first()
    if not ride: return _bad("Ride not found.",404)
    ride.status=new_status
    driver=Driver.query.get(did)
    if new_status=="ongoing":
        ride.started_at=datetime.utcnow()
    elif new_status=="completed":
        ride.completed_at=datetime.utcnow()
        if driver:
            driver.available=True; driver.idle_since=datetime.utcnow()
            driver.total_rides_completed=(driver.total_rides_completed or 0)+1
            # Peak hour bonus check
            hour=datetime.utcnow().hour+5
            if (7<=hour<=10) or (17<=hour<=21):
                db.session.add(CaptainBonus(driver_id=did,bonus_type="peak_hour",
                    amount=20.0,description="Peak hour ride bonus"))
        # Cash payment: mark paid on completion
        if ride.payment_method=="cash": ride.paid=True
    elif new_status=="cancelled":
        if driver:
            driver.available=True; driver.idle_since=datetime.utcnow()
            driver.acceptance_rate=max(0,round(((driver.acceptance_rate or 100)*0.92),1))
    db.session.commit()
    return _ok(f"Ride updated to {new_status}.",ride=ride.to_dict())

@ride_bp.route("/captain/location", methods=["POST"])
def captain_update_location():
    """Real GPS update from captain device."""
    did=session.get("driver_id")
    if not did: return _bad("Captain auth required.",401)
    data=request.get_json(silent=True) or {}
    try:
        lat=float(data["lat"]); lng=float(data["lng"])
    except: return _bad("lat/lng required.")
    driver=Driver.query.get(did)
    if not driver: return _bad("Driver not found.",404)
    driver.lat=lat; driver.lng=lng
    # Geo-fence check for active ride
    active_ride=Ride.query.filter_by(driver_id=did,status="accepted").first()
    geo_event=None
    if active_ride:
        within,meters=is_within_geofence(lat,lng,active_ride.pickup_lat,active_ride.pickup_lng)
        if within: geo_event={"type":"arrived_pickup","ride_id":active_ride.id,"meters":meters}
    db.session.commit()
    resp={"success":True,"message":"Location updated."}
    if geo_event: resp["geo_event"]=geo_event
    return jsonify(resp)

@ride_bp.route("/captain/<int:driver_id>/bonuses", methods=["GET"])
def captain_bonuses(driver_id):
    bonuses=CaptainBonus.query.filter_by(driver_id=driver_id).order_by(CaptainBonus.created_at.desc()).all()
    total_bonus=sum(b.amount for b in bonuses)
    return _ok("Bonuses fetched.",bonuses=[b.to_dict() for b in bonuses],total_bonus=round(total_bonus,2))


# ─── Admin ─────────────────────────────────────────────────────────────────────
@ride_bp.route("/drivers", methods=["GET"])
def list_drivers():
    drivers=Driver.query.filter_by(verification_status="approved").all()
    return _ok("Drivers fetched.",drivers=[d.to_dict() for d in drivers])

@ride_bp.route("/admin/stats", methods=["GET"])
def admin_stats():
    err=_require_admin()
    if err: return err
    from sqlalchemy import func
    total_users=User.query.count(); total_drivers=Driver.query.count()
    total_rides=Ride.query.count()
    completed=Ride.query.filter_by(status="completed").count()
    ongoing=Ride.query.filter_by(status="ongoing").count()
    requested=Ride.query.filter_by(status="requested").count()
    cancelled=Ride.query.filter_by(status="cancelled").count()
    revenue=db.session.query(func.sum(Ride.final_fare)).filter_by(status="completed").scalar() or 0
    pending_sos=SosAlert.query.filter_by(resolved=False).count()
    fraud_flags=FraudLog.query.filter_by(reviewed=False).count()
    return _ok("Stats fetched.",stats={"total_users":total_users,"total_drivers":total_drivers,"total_rides":total_rides,"completed":completed,"ongoing":ongoing,"requested":requested,"cancelled":cancelled,"revenue":round(float(revenue),2),"pending_sos":pending_sos,"fraud_flags":fraud_flags})

@ride_bp.route("/admin/rides", methods=["GET"])
def admin_all_rides():
    err=_require_admin()
    if err: return err
    status=request.args.get("status")
    q=Ride.query.order_by(Ride.requested_at.desc())
    if status: q=q.filter_by(status=status)
    rides=q.limit(200).all()
    return _ok("Rides fetched.",rides=[r.to_dict() for r in rides])

@ride_bp.route("/admin/users", methods=["GET"])
def admin_all_users():
    err=_require_admin()
    if err: return err
    users=User.query.order_by(User.id.desc()).all()
    return _ok("Users fetched.",users=[u.to_dict() for u in users])

@ride_bp.route("/admin/rides/<int:ride_id>/status", methods=["POST"])
def admin_update_ride(ride_id):
    err=_require_admin()
    if err: return err
    data=request.get_json(silent=True) or {}
    new_status=data.get("status")
    valid=("requested","accepted","ongoing","completed","cancelled")
    if new_status not in valid: return _bad(f"status must be one of: {', '.join(valid)}")
    ride=Ride.query.get(ride_id)
    if not ride: return _bad("Ride not found.",404)
    ride.status=new_status
    if new_status=="completed":
        ride.completed_at=datetime.utcnow()
        if ride.driver: ride.driver.available=True
    elif new_status=="cancelled":
        if ride.driver: ride.driver.available=True
    db.session.commit()
    return _ok(f"Ride updated to {new_status}.",ride=ride.to_dict())

@ride_bp.route("/admin/sos", methods=["GET"])
def admin_sos_list():
    err=_require_admin()
    if err: return err
    alerts=SosAlert.query.order_by(SosAlert.created_at.desc()).limit(100).all()
    return _ok("SOS alerts fetched.",alerts=[a.to_dict() for a in alerts])

@ride_bp.route("/admin/fraud-logs", methods=["GET"])
def admin_fraud_logs():
    err=_require_admin()
    if err: return err
    logs=FraudLog.query.order_by(FraudLog.created_at.desc()).limit(100).all()
    return _ok("Fraud logs fetched.",logs=[l.to_dict() for l in logs])

@ride_bp.route("/admin/fraud-logs/<int:log_id>/review", methods=["POST"])
def review_fraud(log_id):
    err=_require_admin()
    if err: return err
    log=FraudLog.query.get(log_id)
    if not log: return _bad("Log not found.",404)
    log.reviewed=True; db.session.commit()
    return _ok("Marked reviewed.")

@ride_bp.route("/admin/promos", methods=["GET"])
def admin_promos():
    err=_require_admin()
    if err: return err
    promos=PromoCode.query.order_by(PromoCode.created_at.desc()).all()
    return _ok("Promos fetched.",promos=[p.to_dict() for p in promos])

@ride_bp.route("/admin/promos", methods=["POST"])
def admin_create_promo():
    err=_require_admin()
    if err: return err
    data=request.get_json(silent=True) or {}
    code=(data.get("code") or "").strip().upper()
    if not code: return _bad("Code required.")
    if PromoCode.query.filter_by(code=code).first(): return _bad("Code already exists.")
    valid_until=None
    if data.get("valid_until"):
        try: valid_until=datetime.fromisoformat(data["valid_until"])
        except: pass
    p=PromoCode(code=code,discount_type=data.get("discount_type","percent"),
        discount_value=float(data.get("discount_value",10)),
        max_discount=data.get("max_discount"),min_fare=float(data.get("min_fare",0)),
        max_uses=int(data.get("max_uses",100)),uses_per_user=int(data.get("uses_per_user",1)),
        cashback_percent=float(data.get("cashback_percent",0)),
        description=data.get("description",""),valid_until=valid_until)
    db.session.add(p); db.session.commit()
    return _ok("Promo created.",promo=p.to_dict())

@ride_bp.route("/admin/promos/<int:pid>/toggle", methods=["POST"])
def toggle_promo(pid):
    err=_require_admin()
    if err: return err
    p=PromoCode.query.get(pid)
    if not p: return _bad("Promo not found.",404)
    p.is_active=not p.is_active; db.session.commit()
    return _ok(f"Promo {'activated' if p.is_active else 'deactivated'}.",promo=p.to_dict())

@ride_bp.route("/admin/heatmap-data", methods=["GET"])
def admin_heatmap():
    err=_require_admin()
    if err: return err
    rides=Ride.query.with_entities(Ride.pickup_lat,Ride.pickup_lng).filter(
        Ride.pickup_lat!=None).limit(500).all()
    points=[{"lat":r[0],"lng":r[1],"intensity":1} for r in rides]
    return _ok("Heatmap data.",points=points)

# ─── Captain payment/withdrawal routes (unchanged) ────────────────────────────
@ride_bp.route("/captain/<int:driver_id>/payment-methods", methods=["GET"])
def get_payment_methods(driver_id):
    methods=DriverPaymentMethod.query.filter_by(driver_id=driver_id).all()
    return _ok("Methods fetched.",methods=[m.to_dict() for m in methods])

@ride_bp.route("/captain/<int:driver_id>/payment-methods", methods=["POST"])
def add_payment_method(driver_id):
    data=request.get_json(silent=True) or {}
    mtype=data.get("method_type")
    if mtype not in ("upi","bank"): return _bad("method_type must be 'upi' or 'bank'.")
    if mtype=="upi":
        upi_id=(data.get("upi_id") or "").strip()
        if not upi_id: return _bad("UPI ID required.")
        pm=DriverPaymentMethod(driver_id=driver_id,method_type="upi",upi_id=upi_id)
    else:
        an=(data.get("account_no") or "").strip(); ifsc=(data.get("ifsc") or "").strip().upper()
        hn=(data.get("holder_name") or "").strip(); bn=(data.get("bank_name") or "").strip()
        if not an or not ifsc or not hn: return _bad("account_no, ifsc, holder_name required.")
        pm=DriverPaymentMethod(driver_id=driver_id,method_type="bank",account_no=an,ifsc=ifsc,holder_name=hn,bank_name=bn)
    if DriverPaymentMethod.query.filter_by(driver_id=driver_id).count()==0: pm.is_primary=True
    db.session.add(pm); db.session.commit()
    return _ok("Payment method added.",method=pm.to_dict())

@ride_bp.route("/captain/<int:driver_id>/payment-methods/<int:pm_id>", methods=["DELETE"])
def delete_payment_method(driver_id,pm_id):
    pm=DriverPaymentMethod.query.filter_by(id=pm_id,driver_id=driver_id).first()
    if not pm: return _bad("Method not found.",404)
    db.session.delete(pm); db.session.commit()
    return _ok("Method removed.")

@ride_bp.route("/captain/<int:driver_id>/withdraw", methods=["POST"])
def request_withdrawal(driver_id):
    from sqlalchemy import func
    data=request.get_json(silent=True) or {}
    try: amount=float(data.get("amount",0)); assert amount>=50
    except: return _bad("Minimum withdrawal ₹50.")
    pm=DriverPaymentMethod.query.filter_by(id=data.get("payment_method_id"),driver_id=driver_id).first()
    if not pm: return _bad("Payment method not found.")
    total=db.session.query(func.sum(Ride.final_fare)).filter_by(driver_id=driver_id,status="completed").scalar() or 0
    bonuses=db.session.query(func.sum(CaptainBonus.amount)).filter_by(driver_id=driver_id,paid=False).scalar() or 0
    withdrawn=db.session.query(func.sum(DriverWithdrawal.amount)).filter(
        DriverWithdrawal.driver_id==driver_id,DriverWithdrawal.status.in_(["pending","approved"])).scalar() or 0
    available=float(total)+float(bonuses)-float(withdrawn)
    if amount>available: return _bad(f"Insufficient balance. Available: ₹{round(available,2)}")
    dest=pm.upi_id if pm.method_type=="upi" else pm.account_no
    w=DriverWithdrawal(driver_id=driver_id,amount=amount,method_type=pm.method_type,destination=dest)
    db.session.add(w); db.session.commit()
    return _ok("Withdrawal requested.",withdrawal=w.to_dict())

@ride_bp.route("/captain/<int:driver_id>/withdrawals", methods=["GET"])
def get_withdrawals(driver_id):
    ws=DriverWithdrawal.query.filter_by(driver_id=driver_id).order_by(DriverWithdrawal.requested_at.desc()).all()
    return _ok("Withdrawals fetched.",withdrawals=[w.to_dict() for w in ws])

@ride_bp.route("/captain/<int:driver_id>/earnings", methods=["GET"])
def get_earnings(driver_id):
    from sqlalchemy import func
    total=db.session.query(func.sum(Ride.final_fare)).filter_by(driver_id=driver_id,status="completed").scalar() or 0
    bonuses=db.session.query(func.sum(CaptainBonus.amount)).filter_by(driver_id=driver_id).scalar() or 0
    withdrawn=db.session.query(func.sum(DriverWithdrawal.amount)).filter(
        DriverWithdrawal.driver_id==driver_id,DriverWithdrawal.status.in_(["pending","approved"])).scalar() or 0
    available=float(total)+float(bonuses)-float(withdrawn)
    # Daily/weekly breakdown
    today=datetime.utcnow().date()
    week_start=today-timedelta(days=6)
    daily=db.session.query(func.sum(Ride.final_fare)).filter(
        Ride.driver_id==driver_id,Ride.status=="completed",
        db.func.date(Ride.completed_at)==today).scalar() or 0
    weekly=db.session.query(func.sum(Ride.final_fare)).filter(
        Ride.driver_id==driver_id,Ride.status=="completed",
        Ride.completed_at>=datetime.combine(week_start,datetime.min.time())).scalar() or 0
    from datetime import date; from datetime import datetime as _dt
    return _ok("Earnings fetched.",total_earned=round(float(total),2),total_bonus=round(float(bonuses),2),
        withdrawn=round(float(withdrawn),2),available=round(available,2),
        today=round(float(daily),2),this_week=round(float(weekly),2))

@ride_bp.route("/admin/withdrawals", methods=["GET"])
def admin_all_withdrawals():
    err=_require_admin()
    if err: return err
    status=request.args.get("status")
    q=DriverWithdrawal.query.order_by(DriverWithdrawal.requested_at.desc())
    if status: q=q.filter_by(status=status)
    return _ok("Withdrawals fetched.",withdrawals=[w.to_dict() for w in q.all()])

@ride_bp.route("/admin/withdrawals/<int:w_id>/process", methods=["POST"])
def admin_process_withdrawal(w_id):
    err=_require_admin()
    if err: return err
    data=request.get_json(silent=True) or {}
    action=data.get("action")
    if action not in ("approve","reject"): return _bad("action must be 'approve' or 'reject'.")
    w=DriverWithdrawal.query.get(w_id)
    if not w: return _bad("Not found.",404)
    w.status="approved" if action=="approve" else "rejected"
    w.note=data.get("note",""); w.processed_at=datetime.utcnow()
    db.session.commit()
    return _ok(f"Withdrawal {w.status}.",withdrawal=w.to_dict())

# ── Missing admin endpoint: /api/admin/drivers ────────────────────────────────
@ride_bp.route("/admin/drivers", methods=["GET"])
def admin_all_drivers():
    err = _require_admin()
    if err: return err
    drivers = Driver.query.order_by(Driver.created_at.desc()).all()
    return _ok("Drivers fetched.", drivers=[d.to_dict() for d in drivers])

# ══════════════════════════════════════════════════════════════════
#  ADVANCED FEATURES
# ══════════════════════════════════════════════════════════════════

# ── Tip Captain ───────────────────────────────────────────────────
@ride_bp.route("/rides/<int:ride_id>/tip", methods=["POST"])
def tip_captain(ride_id):
    ride = Ride.query.get(ride_id)
    if not ride: return _bad("Ride not found.", 404)
    if ride.status != "completed": return _bad("Can only tip after ride is completed.")
    data = request.get_json(silent=True) or {}
    amount = float(data.get("amount", 0))
    if amount <= 0: return _bad("Tip amount must be positive.")
    wallet = UserWallet.query.filter_by(user_id=ride.user_id).first()
    if not wallet or wallet.balance < amount: return _bad("Insufficient wallet balance.")
    wallet.balance -= amount
    wallet.updated_at = datetime.utcnow()
    db.session.add(WalletTransaction(
        wallet_id=wallet.id, user_id=ride.user_id, ride_id=ride_id,
        txn_type="debit", amount=amount,
        description=f"Tip for captain on ride #{ride_id}",
        balance_after=wallet.balance
    ))
    bonus = CaptainBonus(driver_id=ride.driver_id, bonus_type="tip",
                         amount=amount, description=f"Tip from user on ride #{ride_id}")
    db.session.add(bonus)
    db.session.commit()
    from backend.extensions import socketio
    socketio.emit("tip_received", {"amount": amount, "ride_id": ride_id},
                  room=f"captain_{ride.driver_id}")
    return _ok(f"₹{amount} tip sent to captain!", tip=amount)

# ── Geofence check ────────────────────────────────────────────────
@ride_bp.route("/geofence/check", methods=["POST"])
def check_geofence():
    data = request.get_json(silent=True) or {}
    lat, lng = data.get("lat"), data.get("lng")
    if not lat or not lng: return _bad("lat/lng required.")
    # Hubli-Dharwad bounding box
    in_zone = (14.9 <= float(lat) <= 15.7 and 74.7 <= float(lng) <= 75.5)
    return _ok("Geofence checked.", in_zone=in_zone,
               message="Within service area" if in_zone else "Outside Hubli-Dharwad service area")

# ── Admin: Revenue Analytics ──────────────────────────────────────
@ride_bp.route("/admin/analytics/revenue", methods=["GET"])
def admin_revenue_analytics():
    err = _require_admin()
    if err: return err
    from sqlalchemy import func
    period = request.args.get("period", "daily")  # daily / weekly / monthly
    today = datetime.utcnow().date()

    if period == "daily":
        days = []
        for i in range(13, -1, -1):
            d = today - timedelta(days=i)
            rev = db.session.query(func.sum(Ride.final_fare)).filter(
                Ride.status == "completed",
                db.func.date(Ride.completed_at) == d
            ).scalar() or 0
            cnt = db.session.query(func.count(Ride.id)).filter(
                Ride.status == "completed",
                db.func.date(Ride.completed_at) == d
            ).scalar() or 0
            days.append({"date": str(d), "revenue": round(float(rev), 2), "rides": cnt})
        return _ok("Revenue fetched.", data=days, period="daily")

    elif period == "weekly":
        weeks = []
        for i in range(7, -1, -1):
            start = today - timedelta(weeks=i+1)
            end   = today - timedelta(weeks=i)
            rev = db.session.query(func.sum(Ride.final_fare)).filter(
                Ride.status == "completed",
                Ride.completed_at >= datetime.combine(start, datetime.min.time()),
                Ride.completed_at < datetime.combine(end, datetime.min.time())
            ).scalar() or 0
            cnt = db.session.query(func.count(Ride.id)).filter(
                Ride.status == "completed",
                Ride.completed_at >= datetime.combine(start, datetime.min.time()),
                Ride.completed_at < datetime.combine(end, datetime.min.time())
            ).scalar() or 0
            weeks.append({"week": f"{start}", "revenue": round(float(rev), 2), "rides": cnt})
        return _ok("Revenue fetched.", data=weeks, period="weekly")

    elif period == "monthly":
        months = []
        for i in range(5, -1, -1):
            month = (today.month - i - 1) % 12 + 1
            year  = today.year - ((i - today.month + 1) // 12 if today.month <= i else 0)
            rev = db.session.query(func.sum(Ride.final_fare)).filter(
                Ride.status == "completed",
                db.func.month(Ride.completed_at) == month,
                db.func.year(Ride.completed_at) == year
            ).scalar() or 0
            cnt = db.session.query(func.count(Ride.id)).filter(
                Ride.status == "completed",
                db.func.month(Ride.completed_at) == month,
                db.func.year(Ride.completed_at) == year
            ).scalar() or 0
            months.append({"month": f"{year}-{month:02d}", "revenue": round(float(rev), 2), "rides": cnt})
        return _ok("Revenue fetched.", data=months, period="monthly")

    return _bad("Invalid period.")

# ── Admin: Surge control ──────────────────────────────────────────
_surge_override = {}

@ride_bp.route("/admin/surge", methods=["GET"])
def admin_get_surge():
    err = _require_admin()
    if err: return err
    return _ok("Surge config.", surge=_surge_override.get("multiplier", None),
               active=bool(_surge_override.get("multiplier")))

@ride_bp.route("/admin/surge", methods=["POST"])
def admin_set_surge():
    err = _require_admin()
    if err: return err
    data = request.get_json(silent=True) or {}
    multiplier = data.get("multiplier")
    if multiplier is None:
        _surge_override.clear()
        return _ok("Surge pricing reset to automatic.")
    multiplier = float(multiplier)
    if not (1.0 <= multiplier <= 5.0): return _bad("Multiplier must be between 1.0 and 5.0")
    _surge_override["multiplier"] = multiplier
    return _ok(f"Surge set to {multiplier}x manually.", surge=multiplier)

# ── Admin: Ban / Unban user or captain ───────────────────────────
@ride_bp.route("/admin/users/<int:uid>/ban", methods=["POST"])
def admin_ban_user(uid):
    err = _require_admin()
    if err: return err
    user = User.query.get(uid)
    if not user: return _bad("User not found.", 404)
    user.verified = False
    db.session.commit()
    return _ok(f"User #{uid} banned.")

@ride_bp.route("/admin/users/<int:uid>/unban", methods=["POST"])
def admin_unban_user(uid):
    err = _require_admin()
    if err: return err
    user = User.query.get(uid)
    if not user: return _bad("User not found.", 404)
    user.verified = True
    db.session.commit()
    return _ok(f"User #{uid} unbanned.")

@ride_bp.route("/admin/drivers/<int:did>/ban", methods=["POST"])
def admin_ban_driver(did):
    err = _require_admin()
    if err: return err
    driver = Driver.query.get(did)
    if not driver: return _bad("Driver not found.", 404)
    driver.available = False
    driver.is_online = False
    driver.verification_status = "rejected"
    driver.rejection_reason = "Banned by admin."
    db.session.commit()
    from backend.extensions import socketio
    socketio.emit("account_banned", {"message": "Your account has been suspended by admin."}, room=f"captain_{did}")
    return _ok(f"Driver #{did} banned.")

@ride_bp.route("/admin/drivers/<int:did>/unban", methods=["POST"])
def admin_unban_driver(did):
    err = _require_admin()
    if err: return err
    driver = Driver.query.get(did)
    if not driver: return _bad("Driver not found.", 404)
    driver.verification_status = "approved"
    driver.rejection_reason = None
    db.session.commit()
    return _ok(f"Driver #{did} unbanned.")

# ── Admin: Export rides as CSV ────────────────────────────────────
@ride_bp.route("/admin/export/rides", methods=["GET"])
def admin_export_rides():
    err = _require_admin()
    if err: return err
    from flask import Response
    rides = Ride.query.order_by(Ride.requested_at.desc()).limit(1000).all()
    lines = ["id,user_id,driver_id,pickup,drop,vehicle,distance_km,fare,final_fare,status,payment,requested_at,completed_at"]
    for r in rides:
        lines.append(f'{r.id},{r.user_id},{r.driver_id or ""},"{r.pickup_name}","{r.drop_name}",{r.vehicle_type},{r.distance_km or ""},{ r.fare or ""},{r.final_fare or ""},{r.status},{r.payment_method},{r.requested_at},{r.completed_at or ""}')
    csv = "\n".join(lines)
    return Response(csv, mimetype="text/csv",
                    headers={"Content-Disposition": "attachment;filename=rides_export.csv"})

# ── Captain: Leaderboard ──────────────────────────────────────────
@ride_bp.route("/captain/leaderboard", methods=["GET"])
def captain_leaderboard():
    from sqlalchemy import func
    period = request.args.get("period", "week")
    today = datetime.utcnow()
    if period == "week":
        since = today - timedelta(days=7)
    elif period == "month":
        since = today - timedelta(days=30)
    else:
        since = datetime(2000, 1, 1)

    results = db.session.query(
        Driver.id, Driver.name, Driver.vehicle_type, Driver.rating,
        func.count(Ride.id).label("rides"),
        func.sum(Ride.final_fare).label("earnings")
    ).join(Ride, Ride.driver_id == Driver.id).filter(
        Ride.status == "completed",
        Ride.completed_at >= since
    ).group_by(Driver.id).order_by(func.count(Ride.id).desc()).limit(10).all()

    board = [{"rank": i+1, "id": r.id, "name": r.name, "vehicle_type": r.vehicle_type,
              "rating": r.rating, "rides": r.rides, "earnings": round(float(r.earnings or 0), 2)}
             for i, r in enumerate(results)]
    return _ok("Leaderboard fetched.", leaderboard=board, period=period)

# ── Captain: Acceptance rate warning ─────────────────────────────
@ride_bp.route("/captain/<int:driver_id>/acceptance-warning", methods=["GET"])
def acceptance_warning(driver_id):
    driver = Driver.query.get(driver_id)
    if not driver: return _bad("Driver not found.", 404)
    warn = driver.acceptance_rate < 70
    return _ok("Checked.", warn=warn, rate=driver.acceptance_rate,
               message="⚠️ Your acceptance rate is low! Declining too many rides may affect your account." if warn else "✅ Good acceptance rate!")

# ── Nearby Ride Requests for Rider/User (self-service dispatch) ───────────────
@ride_bp.route("/rides/nearby-requests", methods=["GET"])
def nearby_ride_requests():
    """Return open (requested) rides near a given lat/lng — for user profile dispatch panel."""
    import math
    lat  = request.args.get("lat",  type=float)
    lng  = request.args.get("lng",  type=float)
    radius = float(request.args.get("radius", 10.0))  # km default 10km

    rides = Ride.query.filter_by(status="requested", driver_id=None).order_by(Ride.requested_at.desc()).limit(30).all()

    def haversine(lat1, lon1, lat2, lon2):
        R = 6371.0
        d_lat = math.radians(lat2 - lat1)
        d_lon = math.radians(lon2 - lon1)
        a = math.sin(d_lat/2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(d_lon/2)**2
        return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))

    result = []
    for r in rides:
        dist_km = None
        if lat and lng and r.pickup_lat and r.pickup_lng:
            dist_km = round(haversine(lat, lng, float(r.pickup_lat), float(r.pickup_lng)), 2)
            if dist_km > radius:
                continue
        rd = r.to_dict()
        rd["dist_from_you_km"] = dist_km
        result.append(rd)

    return _ok("Nearby requests fetched.", rides=result)


@ride_bp.route("/rides/<int:ride_id>/self-accept", methods=["POST"])
def self_accept_ride(ride_id):
    """A logged-in user accepts a nearby ride as a casual driver (self-service mode)."""
    data      = request.get_json(silent=True) or {}
    user_id   = data.get("user_id")
    if not user_id:
        return _bad("user_id required.")

    ride = Ride.query.get(ride_id)
    if not ride:
        return _bad("Ride not found.", 404)
    if ride.status != "requested":
        return _bad(f"Ride is already {ride.status}.")
    if ride.user_id == user_id:
        return _bad("You cannot accept your own ride request.")

    ride.status    = "accepted"
    ride.driver_id = None            # no formal driver assigned
    ride.notes     = f"self-accepted by user_id={user_id}"
    db.session.commit()

    # Notify rider via Socket.IO
    try:
        from backend.extensions import socketio
        socketio.emit("ride_accepted", {"ride": ride.to_dict()}, room=f"user_{ride.user_id}")
    except Exception:
        pass

    return _ok("Ride accepted!", ride=ride.to_dict())


@ride_bp.route("/rides/<int:ride_id>/self-decline", methods=["POST"])
def self_decline_ride(ride_id):
    """User skips/declines a nearby ride request (does not cancel it — just hides for this user)."""
    ride = Ride.query.get(ride_id)
    if not ride:
        return _bad("Ride not found.", 404)
    return _ok("Ride skipped.")
