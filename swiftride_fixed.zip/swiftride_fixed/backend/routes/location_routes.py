"""
Location routes:
  POST /api/location  – store user's current lat/lng in MySQL
  GET  /api/location  – retrieve the most recent stored location for the session
"""

from datetime import datetime
from flask import Blueprint, request, jsonify, session
from backend.extensions import db

location_bp = Blueprint("location", __name__, url_prefix="/api")


def _bad(msg, code=400):
    return jsonify({"success": False, "message": msg}), code


def _ok(msg, **kwargs):
    return jsonify({"success": True, "message": msg, **kwargs})


# ─── UserLocation model (lazy-defined to avoid circular imports) ──────────────

def _get_model():
    """Return (or create) the UserLocation model class."""
    from backend.extensions import db as _db

    # Check if already registered
    if "user_locations" in _db.metadata.tables:
        # Return existing mapped class
        from backend.models.location_model import UserLocation
        return UserLocation

    # Otherwise import to trigger class definition
    from backend.models.location_model import UserLocation
    return UserLocation


# ─── POST /api/location ──────────────────────────────────────────────────────

@location_bp.route("/location", methods=["POST"])
def save_location():
    """
    Receives { latitude, longitude, address, type } from the frontend
    and stores it in the user_locations table.
    """
    data = request.get_json(silent=True) or {}

    lat  = data.get("latitude")
    lng  = data.get("longitude")
    addr = data.get("address", "")
    loc_type = data.get("type", "current")   # 'current' | 'tracking'

    # Validate
    if lat is None or lng is None:
        return _bad("latitude and longitude are required.")

    try:
        lat = float(lat)
        lng = float(lng)
    except (ValueError, TypeError):
        return _bad("latitude and longitude must be valid numbers.")

    if not (-90 <= lat <= 90) or not (-180 <= lng <= 180):
        return _bad("latitude/longitude out of valid range.")

    user_id = session.get("user_id")  # None if guest – still store for session

    try:
        UserLocation = _get_model()
        loc = UserLocation(
            user_id   = user_id,
            latitude  = lat,
            longitude = lng,
            address   = addr[:500] if addr else "",
            loc_type  = loc_type,
            session_id = session.get("_id", ""),
            created_at = datetime.utcnow(),
        )
        db.session.add(loc)
        db.session.commit()

        return _ok(
            "Location saved.",
            location_id = loc.id,
            latitude    = lat,
            longitude   = lng,
            address     = addr,
        )

    except Exception as e:
        db.session.rollback()
        print(f"[location_route] DB error: {e}")
        return _bad(f"Database error: {str(e)}", 500)


# ─── GET /api/location ───────────────────────────────────────────────────────

@location_bp.route("/location", methods=["GET"])
def get_last_location():
    """Return the most recent saved location for the current user/session."""
    user_id = session.get("user_id")

    try:
        UserLocation = _get_model()

        if user_id:
            loc = (UserLocation.query
                   .filter_by(user_id=user_id)
                   .order_by(UserLocation.created_at.desc())
                   .first())
        else:
            loc = None

        if not loc:
            return _ok("No location found.", location=None)

        return _ok("OK", location={
            "id":        loc.id,
            "latitude":  loc.latitude,
            "longitude": loc.longitude,
            "address":   loc.address,
            "type":      loc.loc_type,
            "saved_at":  loc.created_at.isoformat(),
        })

    except Exception as e:
        print(f"[location_route] GET error: {e}")
        return _bad(f"Database error: {str(e)}", 500)
