import time, threading, logging, json
from datetime import datetime
from flask import request
from flask_socketio import emit, join_room, leave_room
from backend.extensions import socketio, db
from backend.models.models import Ride, Driver
from backend.utils.geo_utils import interpolate_position, is_within_geofence

logger = logging.getLogger(__name__)
_active_threads: dict = {}
_threads_lock = threading.Lock()
# captain sid mapping: driver_id → socket sid
_captain_sids: dict = {}

def _simulate_driver_movement(app, ride_id: int, stop_event: threading.Event):
    with app.app_context():
        try:
            ride = Ride.query.get(ride_id)
            if not ride or not ride.driver:
                return
            driver = ride.driver
            room   = f"ride_{ride_id}"
            STEP, STEPS = 1.5, 25

            def emit_loc(lat, lng, status, progress):
                socketio.emit("location_update", {"ride_id":ride_id,"lat":lat,"lng":lng,"status":status,"progress":progress}, room=room)

            # Phase 1: driver → pickup
            s_lat, s_lng = driver.lat, driver.lng
            e_lat, e_lng = ride.pickup_lat, ride.pickup_lng
            for step in range(STEPS+1):
                if stop_event.is_set(): return
                frac=step/STEPS
                lat,lng=interpolate_position(s_lat,s_lng,e_lat,e_lng,frac)
                emit_loc(lat,lng,"accepted",int(frac*35))
                # Geo-fence check
                within,meters=is_within_geofence(lat,lng,e_lat,e_lng)
                if within:
                    socketio.emit("geo_event",{"type":"captain_arrived_pickup","ride_id":ride_id,"meters":meters},room=room)
                time.sleep(STEP)

            with app.app_context():
                r=Ride.query.get(ride_id)
                if r: r.status="ongoing"; r.started_at=datetime.utcnow(); db.session.commit()
            socketio.emit("ride_status",{"ride_id":ride_id,"status":"ongoing"},room=room)

            # Phase 2: pickup → drop (through stops if any)
            s_lat,s_lng=ride.pickup_lat,ride.pickup_lng
            e_lat,e_lng=ride.drop_lat,ride.drop_lng
            for step in range(STEPS+1):
                if stop_event.is_set(): return
                frac=step/STEPS
                lat,lng=interpolate_position(s_lat,s_lng,e_lat,e_lng,frac)
                emit_loc(lat,lng,"ongoing",35+int(frac*60))
                # Geo-fence drop
                within,meters=is_within_geofence(lat,lng,e_lat,e_lng)
                if within:
                    socketio.emit("geo_event",{"type":"approaching_drop","ride_id":ride_id,"meters":meters},room=room)
                time.sleep(STEP)

            # Phase 3: complete
            with app.app_context():
                r=Ride.query.get(ride_id)
                if r:
                    r.status="completed"; r.completed_at=datetime.utcnow()
                    if r.driver:
                        r.driver.available=True; r.driver.lat=ride.drop_lat; r.driver.lng=ride.drop_lng
                        r.driver.total_rides_completed=(r.driver.total_rides_completed or 0)+1
                        r.driver.idle_since=datetime.utcnow()
                    db.session.commit()
            socketio.emit("ride_status",{"ride_id":ride_id,"status":"completed"},room=room)
            emit_loc(e_lat,e_lng,"completed",100)
        except Exception as exc:
            logger.error("Tracking error ride %s: %s", ride_id, exc)
        finally:
            with _threads_lock: _active_threads.pop(ride_id,None)


@socketio.on("start_tracking")
def handle_start_tracking(data):
    from flask import current_app
    ride_id=data.get("ride_id")
    if not ride_id: emit("error",{"message":"ride_id required."}); return
    ride=Ride.query.get(ride_id)
    if not ride: emit("error",{"message":"Ride not found."}); return
    room=f"ride_{ride_id}"
    join_room(room)
    if ride.status in ("completed","cancelled"):
        emit("ride_status",{"ride_id":ride_id,"status":ride.status}); return
    with _threads_lock:
        if ride_id in _active_threads:
            emit("tracking_started",{"ride_id":ride_id,"message":"Already tracking."}); return
        stop_event=threading.Event()
        _active_threads[ride_id]=stop_event
    app=current_app._get_current_object()
    threading.Thread(target=_simulate_driver_movement,args=(app,ride_id,stop_event),daemon=True,name=f"tracker-{ride_id}").start()
    emit("tracking_started",{"ride_id":ride_id,"message":"Tracking started."})

@socketio.on("stop_tracking")
def handle_stop_tracking(data):
    ride_id=data.get("ride_id")
    if ride_id:
        with _threads_lock: ev=_active_threads.pop(ride_id,None)
        if ev: ev.set()
        leave_room(f"ride_{ride_id}")
    emit("tracking_stopped",{"ride_id":ride_id})

# ── Captain real-time events ──────────────────────────────────────────────────
@socketio.on("captain_join")
def handle_captain_join(data):
    driver_id=data.get("driver_id")
    if not driver_id: emit("error",{"message":"driver_id required."}); return
    room=f"captain_{driver_id}"
    join_room(room)
    _captain_sids[driver_id]=request.sid
    emit("captain_ready",{"message":f"Captain {driver_id} connected to ride notifications."})
    logger.info("[WS] Captain %s joined room %s", driver_id, room)

@socketio.on("captain_location")
def handle_captain_location(data):
    """Real GPS from captain's device — update DB and broadcast."""
    from flask import current_app
    driver_id=data.get("driver_id")
    try: lat=float(data["lat"]); lng=float(data["lng"])
    except: emit("error",{"message":"lat/lng required."}); return
    with current_app.app_context():
        driver=Driver.query.get(driver_id)
        if driver:
            driver.lat=lat; driver.lng=lng; db.session.commit()
            active=Ride.query.filter_by(driver_id=driver_id,status="accepted").first()
            if active:
                room=f"ride_{active.id}"
                socketio.emit("location_update",{"ride_id":active.id,"lat":lat,"lng":lng,"status":"accepted","progress":10},room=room)
                within,meters=is_within_geofence(lat,lng,active.pickup_lat,active.pickup_lng)
                if within:
                    socketio.emit("geo_event",{"type":"captain_arrived_pickup","ride_id":active.id,"meters":int(meters)},room=room)

@socketio.on("captain_respond")
def handle_captain_respond(data):
    from flask import current_app
    ride_id=data.get("ride_id"); action=data.get("action"); driver_id=data.get("driver_id")
    with current_app.app_context():
        ride=Ride.query.get(ride_id)
        if not ride: return
        room=f"ride_{ride_id}"
        if action=="accept":
            ride.status="accepted"; ride.accepted_at=datetime.utcnow()
            driver=Driver.query.get(driver_id)
            if driver: driver.available=False
            db.session.commit()
            socketio.emit("captain_accepted",{"driver":driver.to_dict() if driver else None,"ride_id":ride_id},room=room)
        elif action=="decline":
            declined=json.loads(ride.declined_drivers or "[]")
            if driver_id not in declined: declined.append(driver_id)
            ride.declined_drivers=json.dumps(declined)
            ride.reassign_count=(ride.reassign_count or 0)+1
            # Update acceptance rate
            driver=Driver.query.get(driver_id)
            if driver:
                driver.acceptance_rate=max(0,round((driver.acceptance_rate or 100)*0.93,1))
            db.session.commit()
            # Try reassign
            from backend.utils.geo_utils import find_best_driver
            avail=Driver.query.filter_by(available=True,verification_status="approved").all()
            new_driver,_=find_best_driver(ride.pickup_lat,ride.pickup_lng,avail,exclude_ids=declined)
            if new_driver:
                ride.driver_id=new_driver.id; new_driver.available=False; db.session.commit()
                # Notify new captain
                socketio.emit("new_ride_request",{"ride":ride.to_dict()},room=f"captain_{new_driver.id}")
                socketio.emit("ride_reassigned",{"ride_id":ride_id,"new_driver":new_driver.to_dict()},room=room)
            else:
                ride.status="cancelled"; db.session.commit()
                socketio.emit("ride_status",{"ride_id":ride_id,"status":"cancelled","reason":"No drivers available."},room=room)

@socketio.on("connect")
def handle_connect(): logger.info("[WS] Connected: %s", request.sid)

@socketio.on("disconnect")
def handle_disconnect(): logger.info("[WS] Disconnected: %s", request.sid)
