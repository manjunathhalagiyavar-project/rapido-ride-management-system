"""
Configuration settings for the SwiftRide application.
"""

import os
from datetime import timedelta

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass


class Config:
    # ─── Flask ───────────────────────────────────────────────
    SECRET_KEY = os.environ.get("SECRET_KEY", "swiftride-secret-key-2024")
    DEBUG      = os.environ.get("DEBUG", "True") == "True"

    # ─── MySQL Database ───────────────────────────────────────
    DB_HOST     = os.environ.get("DB_HOST",     "localhost")
    DB_PORT     = int(os.environ.get("DB_PORT", 3306))
    DB_USER     = os.environ.get("DB_USER",     "root")
    DB_PASSWORD = os.environ.get("DB_PASSWORD", "")
    DB_NAME     = os.environ.get("DB_NAME",     "swiftride")

    SQLALCHEMY_DATABASE_URI = (
        f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # ─── SocketIO ────────────────────────────────────────────
    SOCKETIO_CORS_ALLOWED_ORIGINS = "*"

    # ─── Session ─────────────────────────────────────────────
    SESSION_COOKIE_SECURE      = False
    PERMANENT_SESSION_LIFETIME = timedelta(days=7)

    # ─── Twilio SMS ───────────────────────────────────────────
    TWILIO_ACCOUNT_SID  = os.environ.get("TWILIO_ACCOUNT_SID",  "")
    TWILIO_AUTH_TOKEN   = os.environ.get("TWILIO_AUTH_TOKEN",   "")
    TWILIO_FROM_NUMBER  = os.environ.get("TWILIO_FROM_NUMBER",  "")

    # ─── Gmail SMTP (for email OTP) ───────────────────────────
    MAIL_USERNAME       = os.environ.get("MAIL_USERNAME", "")
    MAIL_PASSWORD       = os.environ.get("MAIL_PASSWORD", "")

    # ─── OTP Settings ─────────────────────────────────────────
    OTP_EXPIRY_MINUTES  = int(os.environ.get("OTP_EXPIRY_MINUTES", 5))
    OTP_LENGTH          = int(os.environ.get("OTP_LENGTH", 6))
    OTP_MAX_RETRIES     = int(os.environ.get("OTP_MAX_RETRIES", 3))

