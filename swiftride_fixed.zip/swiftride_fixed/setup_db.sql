-- ============================================================
--  SwiftRide — Full MySQL Schema (Updated)
--  Run this in phpMyAdmin or MySQL Workbench
-- ============================================================

CREATE DATABASE IF NOT EXISTS swiftride CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE swiftride;

-- Users
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) UNIQUE,
  phone VARCHAR(15) UNIQUE,
  verified TINYINT(1) DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Drivers/Captains
CREATE TABLE IF NOT EXISTS drivers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) UNIQUE,
  phone VARCHAR(15) NOT NULL UNIQUE,
  password_hash VARCHAR(128),
  vehicle VARCHAR(100) NOT NULL,
  vehicle_type VARCHAR(50) DEFAULT 'Bike',
  vehicle_model VARCHAR(100),
  vehicle_color VARCHAR(50),
  lat DOUBLE DEFAULT 15.3647,
  lng DOUBLE DEFAULT 75.1240,
  available TINYINT(1) DEFAULT 0,
  is_online TINYINT(1) DEFAULT 0,
  rating DOUBLE DEFAULT 4.5,
  total_ratings INT DEFAULT 0,
  acceptance_rate DOUBLE DEFAULT 100.0,
  total_rides_completed INT DEFAULT 0,
  idle_since DATETIME,
  verification_status VARCHAR(20) DEFAULT 'pending',
  rejection_reason VARCHAR(500),
  verified_at DATETIME,
  doc_license VARCHAR(255),
  doc_rc VARCHAR(255),
  doc_insurance VARCHAR(255),
  doc_photo VARCHAR(255),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Ride Pools
CREATE TABLE IF NOT EXISTS ride_pools (
  id INT AUTO_INCREMENT PRIMARY KEY,
  driver_id INT, vehicle_type VARCHAR(50) DEFAULT 'Auto',
  route_key VARCHAR(100), max_seats INT DEFAULT 2,
  seats_taken INT DEFAULT 0, status VARCHAR(20) DEFAULT 'open',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (driver_id) REFERENCES drivers(id)
);

-- Rides
CREATE TABLE IF NOT EXISTS rides (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  driver_id INT,
  pickup_name VARCHAR(255) NOT NULL,
  pickup_lat DOUBLE NOT NULL,
  pickup_lng DOUBLE NOT NULL,
  drop_name VARCHAR(255) NOT NULL,
  drop_lat DOUBLE NOT NULL,
  drop_lng DOUBLE NOT NULL,
  vehicle_type VARCHAR(50) DEFAULT 'Bike',
  distance_km DOUBLE,
  duration_min DOUBLE,
  fare DOUBLE,
  surge_multiplier DOUBLE DEFAULT 1.0,
  payment_method VARCHAR(20) DEFAULT 'cash',
  promo_code VARCHAR(30),
  discount DOUBLE DEFAULT 0,
  final_fare DOUBLE,
  paid TINYINT(1) DEFAULT 0,
  status VARCHAR(20) DEFAULT 'requested',
  ride_pin VARCHAR(4),
  share_token VARCHAR(64),
  reassign_count INT DEFAULT 0,
  declined_drivers TEXT,
  pool_id INT,
  requested_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  accepted_at DATETIME,
  started_at DATETIME,
  completed_at DATETIME,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (driver_id) REFERENCES drivers(id),
  FOREIGN KEY (pool_id) REFERENCES ride_pools(id)
);

-- Ride Stops (multi-stop)
CREATE TABLE IF NOT EXISTS ride_stops (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ride_id INT NOT NULL,
  stop_order INT NOT NULL,
  name VARCHAR(255) NOT NULL,
  lat DOUBLE NOT NULL,
  lng DOUBLE NOT NULL,
  reached TINYINT(1) DEFAULT 0,
  reached_at DATETIME,
  FOREIGN KEY (ride_id) REFERENCES rides(id) ON DELETE CASCADE
);

-- User Wallets
CREATE TABLE IF NOT EXISTS user_wallets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  balance DOUBLE DEFAULT 0.0,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Wallet Transactions
CREATE TABLE IF NOT EXISTS wallet_transactions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  wallet_id INT NOT NULL,
  user_id INT NOT NULL,
  ride_id INT,
  txn_type VARCHAR(20) NOT NULL,
  amount DOUBLE NOT NULL,
  description VARCHAR(255) NOT NULL,
  balance_after DOUBLE NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (wallet_id) REFERENCES user_wallets(id),
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (ride_id) REFERENCES rides(id)
);

-- Promo Codes
CREATE TABLE IF NOT EXISTS promo_codes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(30) NOT NULL UNIQUE,
  discount_type VARCHAR(10) DEFAULT 'percent',
  discount_value DOUBLE NOT NULL,
  max_discount DOUBLE,
  min_fare DOUBLE DEFAULT 0,
  max_uses INT DEFAULT 100,
  uses_per_user INT DEFAULT 1,
  used_count INT DEFAULT 0,
  valid_from DATETIME DEFAULT CURRENT_TIMESTAMP,
  valid_until DATETIME,
  is_active TINYINT(1) DEFAULT 1,
  cashback_percent DOUBLE DEFAULT 0,
  description VARCHAR(255),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Promo Usages
CREATE TABLE IF NOT EXISTS promo_usages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  promo_id INT NOT NULL,
  user_id INT NOT NULL,
  ride_id INT,
  used_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (promo_id) REFERENCES promo_codes(id),
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Ride Ratings
CREATE TABLE IF NOT EXISTS ride_ratings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ride_id INT NOT NULL UNIQUE,
  user_id INT NOT NULL,
  driver_id INT NOT NULL,
  stars INT NOT NULL,
  review VARCHAR(500),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (ride_id) REFERENCES rides(id),
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (driver_id) REFERENCES drivers(id)
);

-- Scheduled Rides
CREATE TABLE IF NOT EXISTS scheduled_rides (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  pickup_name VARCHAR(255) NOT NULL,
  pickup_lat DOUBLE NOT NULL,
  pickup_lng DOUBLE NOT NULL,
  drop_name VARCHAR(255) NOT NULL,
  drop_lat DOUBLE NOT NULL,
  drop_lng DOUBLE NOT NULL,
  vehicle_type VARCHAR(50) DEFAULT 'Bike',
  scheduled_at DATETIME NOT NULL,
  status VARCHAR(20) DEFAULT 'pending',
  ride_id INT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Captain Bonuses
CREATE TABLE IF NOT EXISTS captain_bonuses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  driver_id INT NOT NULL,
  bonus_type VARCHAR(30) NOT NULL,
  amount DOUBLE NOT NULL,
  description VARCHAR(255),
  paid TINYINT(1) DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (driver_id) REFERENCES drivers(id)
);

-- Fraud Logs
CREATE TABLE IF NOT EXISTS fraud_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  driver_id INT,
  ride_id INT,
  reason VARCHAR(255) NOT NULL,
  severity VARCHAR(10) DEFAULT 'medium',
  reviewed TINYINT(1) DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (driver_id) REFERENCES drivers(id)
);

-- SOS Alerts
CREATE TABLE IF NOT EXISTS sos_alerts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  ride_id INT,
  lat DOUBLE,
  lng DOUBLE,
  message VARCHAR(255) DEFAULT 'SOS triggered by user',
  resolved TINYINT(1) DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (ride_id) REFERENCES rides(id)
);

-- OTP Verifications
CREATE TABLE IF NOT EXISTS otp_verifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  contact VARCHAR(150) NOT NULL,
  contact_type VARCHAR(10) NOT NULL,
  otp VARCHAR(10) NOT NULL,
  purpose VARCHAR(20) DEFAULT 'register',
  expiry_time DATETIME NOT NULL,
  attempts INT DEFAULT 0,
  verified TINYINT(1) DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Driver Payment Methods
CREATE TABLE IF NOT EXISTS driver_payment_methods (
  id INT AUTO_INCREMENT PRIMARY KEY,
  driver_id INT NOT NULL,
  method_type VARCHAR(10) NOT NULL,
  upi_id VARCHAR(100),
  account_no VARCHAR(30),
  ifsc VARCHAR(20),
  holder_name VARCHAR(100),
  bank_name VARCHAR(100),
  is_primary TINYINT(1) DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (driver_id) REFERENCES drivers(id)
);

-- Driver Withdrawals
CREATE TABLE IF NOT EXISTS driver_withdrawals (
  id INT AUTO_INCREMENT PRIMARY KEY,
  driver_id INT NOT NULL,
  amount DOUBLE NOT NULL,
  method_type VARCHAR(10) NOT NULL,
  destination VARCHAR(200) NOT NULL,
  status VARCHAR(20) DEFAULT 'pending',
  note VARCHAR(255),
  requested_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  processed_at DATETIME,
  FOREIGN KEY (driver_id) REFERENCES drivers(id)
);

-- Notifications
CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  driver_id INT,
  user_id INT,
  ride_id INT,
  type VARCHAR(50) NOT NULL,
  title VARCHAR(200) NOT NULL,
  message VARCHAR(500) NOT NULL,
  is_read TINYINT(1) DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (driver_id) REFERENCES drivers(id),
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Ride Messages
CREATE TABLE IF NOT EXISTS ride_messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ride_id INT NOT NULL,
  sender VARCHAR(10) NOT NULL,
  message VARCHAR(500) NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (ride_id) REFERENCES rides(id) ON DELETE CASCADE
);

-- Seed default promo codes
INSERT IGNORE INTO promo_codes (code,discount_type,discount_value,max_discount,min_fare,max_uses,uses_per_user,cashback_percent,description)
VALUES
  ('FIRST50','percent',50,100,50,1000,1,0,'50% off your first ride'),
  ('FLAT30','flat',30,NULL,80,500,2,10,'Flat ₹30 off + 10% cashback'),
  ('WALLET20','percent',20,50,100,200,3,0,'20% off when paying with wallet');

-- Default admin user (password: admin123)
INSERT IGNORE INTO users (name,email,phone,verified) VALUES ('Admin','admin@swiftride.com','0000000000',1);

SELECT 'Schema created successfully!' AS status;
show tables;