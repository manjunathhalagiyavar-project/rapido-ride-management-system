/**
 * SwiftRide — App Bootstrap
 * Initializes map, tracker, auth, booking, handles login/logout UI.
 */

document.addEventListener('DOMContentLoaded', async () => {

  // ── Page Loader ───────────────────────────────────────────────
  const loader = document.getElementById('page-loader');
  setTimeout(() => loader?.classList.add('hidden'), 900);

  // ── Map + Real-Time Tracker ───────────────────────────────────
  if (document.getElementById('map')) {
    try {
      MapManager.init('map');
    } catch(e) { console.error('[App] MapManager.init error:', e); }
    try {
      Tracker.init();
    } catch(e) { console.error('[App] Tracker.init error:', e); }
  }

  // ── Booking Panel (always render, even if map fails) ──────────
  function initBookingPanel() {
    try {
      if (document.getElementById('booking-panel')) {
        if (typeof BookingUI !== 'undefined') {
          BookingUI.init();
        } else {
          console.error('[App] BookingUI is not defined — map.js may have failed to load.');
        }
      }
    } catch(e) { console.error('[App] BookingUI.init error:', e); }
  }
  initBookingPanel();

  // ── Auth callbacks ────────────────────────────────────────────
  window.onAuthLogin = (user) => {
    updateNavbar(user);
  };
  window.onAuthLogout = () => {
    updateNavbar(null);
    try { BookingUI.resetBooking(); } catch(e) { console.error('[App] resetBooking error:', e); }
  };

  // ── Check existing session ────────────────────────────────────
  const loggedIn = await Auth.checkSession();
  updateNavbar(loggedIn ? Auth.getUser() : null);

  // ── Safety: re-render booking panel if it is still empty ─────
  const bp = document.getElementById('booking-panel');
  if (bp && bp.innerHTML.trim() === '') {
    initBookingPanel();
  }

  // ── History page ──────────────────────────────────────────────
  if (document.getElementById('rides-list')) {
    loadHistory();
  }
});


// ── Navbar update ─────────────────────────────────────────────

function updateNavbar(user) {
  const loginBtn = document.getElementById('nav-login-btn');
  const userInfo = document.getElementById('nav-user');
  const userName = document.getElementById('nav-user-name');

  if (user) {
    loginBtn?.classList.add('hidden');
    userInfo?.classList.remove('hidden');
    if (userName) userName.textContent = user.name;
  } else {
    loginBtn?.classList.remove('hidden');
    userInfo?.classList.add('hidden');
  }
}


// ── History Page ──────────────────────────────────────────────

async function loadHistory() {
  const container = document.getElementById('rides-list');
  if (!container) return;

  const authRes = await API.get('/api/me');
  if (!authRes.success) {
    container.innerHTML = `
      <div style="text-align:center;padding:3rem;color:var(--text-muted);">
        <div style="font-size:3rem;margin-bottom:1rem;">🔒</div>
        <p>Please login to view your ride history.</p>
        <button class="btn btn-primary" style="margin-top:1rem;"
                onclick="Auth.open('login')">Login</button>
      </div>`;
    return;
  }

  container.innerHTML = `<div class="skeleton" style="height:80px;border-radius:14px;"></div>`.repeat(3);

  const res = await API.get('/api/rides');
  if (!res.success) {
    container.innerHTML = `<p style="color:var(--error);">Failed to load rides.</p>`;
    return;
  }

  if (!res.rides.length) {
    container.innerHTML = `
      <div style="text-align:center;padding:4rem;color:var(--text-muted);">
        <div style="font-size:4rem;margin-bottom:1rem;">🏍️</div>
        <h3 style="color:var(--text-secondary);">No rides yet</h3>
        <p style="margin-top:0.5rem;">Book your first ride!</p>
        <a href="/" class="btn btn-primary" style="margin-top:1.5rem;display:inline-flex;">Book a Ride</a>
      </div>`;
    return;
  }

  const statusIcons = {
    completed: '✅', ongoing: '🚀', accepted: '🏍️', requested: '⏳', cancelled: '❌'
  };

  container.innerHTML = res.rides.map(ride => `
    <div class="ride-card">
      <div>
        <div class="ride-card-route">
          <div class="pickup">🟢 ${(ride.pickup_name || '').slice(0, 55)}${(ride.pickup_name || '').length > 55 ? '…' : ''}</div>
          <div class="dropoff" style="margin-top:4px;">🔴 ${(ride.drop_name || '').slice(0, 55)}${(ride.drop_name || '').length > 55 ? '…' : ''}</div>
        </div>
        <div class="stats-row" style="margin-top:0.75rem;">
          <div class="stat-chip"><span class="label">Dist</span><span class="value">${formatDist(ride.distance_km)}</span></div>
          <div class="stat-chip"><span class="label">Time</span><span class="value">${Math.round(ride.duration_min)} min</span></div>
          <span class="ride-status-badge badge-${ride.status}" style="font-size:0.72rem;">
            ${statusIcons[ride.status] || ''} ${ride.status}
          </span>
        </div>
      </div>
      <div class="ride-card-meta">
        <div class="ride-card-fare">${formatCurrency(ride.fare)}</div>
        <div class="ride-card-date">${formatDate(ride.requested_at)}</div>
        ${ride.driver ? `<div style="font-size:0.75rem;color:var(--text-muted);margin-top:4px;">
          🧑‍✈️ ${ride.driver.name}
        </div>` : ''}
      </div>
    </div>`).join('');
}
