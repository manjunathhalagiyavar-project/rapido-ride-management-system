/**
 * SwiftRide — Map + Real-Time Tracking
 * Region: Hubli–Dharwad, Karnataka
 * Features: Leaflet map, real driver tracking, double-tap new ride
 */

/* ═══════════════════════════════════════════════════════════════
   MAP MANAGER
   ═══════════════════════════════════════════════════════════════ */

const MapManager = (() => {
  let map, pickupMarker, dropMarker, driverMarker, routePolyline;
  let _doubletapTimer = null;

  // ── Hubli–Dharwad region center ──────────────────────────────
  const HUBLI_CENTER   = [15.3647, 75.1240];
  const DHARWAD_CENTER = [15.4589, 74.9869];
  const REGION_CENTER  = [15.4100, 75.0600];  // midpoint

  // ── Popular locations preset ──────────────────────────────────
  const PRESET_LOCATIONS = [
    { name: "Hubli Railway Station",       lat: 15.3297, lng: 75.1352 },
    { name: "Hubli Old Town",              lat: 15.3647, lng: 75.1240 },
    { name: "Dharwad Bus Stand",           lat: 15.4589, lng: 74.9869 },
    { name: "Dharwad Railway Station",     lat: 15.4513, lng: 75.0059 },
    { name: "KLE Technological University",lat: 15.3781, lng: 75.1265 },
    { name: "Unkal Lake Hubli",            lat: 15.3870, lng: 75.1530 },
    { name: "Durgad Bali Dharwad",         lat: 15.4612, lng: 74.9980 },
    { name: "Hubli Airport",               lat: 15.3613, lng: 75.0849 },
    { name: "Navanagar Hubli",             lat: 15.3560, lng: 75.1670 },
    { name: "Karnataka University Dharwad",lat: 15.4520, lng: 74.9980 },
    { name: "Vidyanagar Hubli",            lat: 15.3750, lng: 75.1420 },
    { name: "Keshwapur Hubli",             lat: 15.3500, lng: 75.1100 },
  ];

  // Custom icons
  function _icon(emoji, size = 36) {
    return L.divIcon({
      html: `<div style="font-size:${size}px;filter:drop-shadow(0 2px 6px rgba(0,0,0,.6));">${emoji}</div>`,
      iconSize:   [size, size],
      iconAnchor: [size / 2, size],
      className:  '',
    });
  }

  function init(containerId = 'map') {
    map = L.map(containerId, {
      center:      REGION_CENTER,
      zoom:        12,
      zoomControl: false,
    });

    // OpenStreetMap tiles (no API key needed)
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© <a href="https://openstreetmap.org">OpenStreetMap</a>',
      maxZoom:     19,
    }).addTo(map);

    L.control.zoom({ position: 'bottomright' }).addTo(map);

    // ── Add region boundary markers ────────────────────────────
    _addCityMarkers();

    // ── Double-tap / double-click to start new ride ────────────
    map.on('dblclick', (e) => {
      e.originalEvent.preventDefault();
      _onDoubleTap(e.latlng);
    });

    // Single tap — place pickup/drop if booking panel is open
    map.on('click', (e) => {
      if (BookingUI && typeof BookingUI.onMapClick === 'function') {
        BookingUI.onMapClick(e.latlng);
      }
    });

    // Real-time pulse animation for driver
    _startDriverPulse();

    return map;
  }

  function _addCityMarkers() {
    // Hubli city label
    L.marker(HUBLI_CENTER, { icon: _icon('🏙️', 28) })
      .addTo(map)
      .bindPopup('<b>Hubli</b><br>Karnataka, India', { className: 'custom-popup' });

    // Dharwad city label
    L.marker(DHARWAD_CENTER, { icon: _icon('🌆', 28) })
      .addTo(map)
      .bindPopup('<b>Dharwad</b><br>Karnataka, India', { className: 'custom-popup' });

    // Draw Hubli–Dharwad corridor line
    L.polyline(
      [HUBLI_CENTER, DHARWAD_CENTER],
      { color: '#FF6B00', weight: 2, opacity: 0.3, dashArray: '6 6' }
    ).addTo(map);
  }

  // ── Double-tap: reset and start fresh ─────────────────────────
  function _onDoubleTap(latlng) {
    clearAll();
    if (BookingUI && typeof BookingUI.resetBooking === 'function') {
      BookingUI.resetBooking();
    }
    Toast.info('🆕 Double-tap detected — starting new ride from this location!');

    // Reverse-geocode with Nominatim
    fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latlng.lat}&lon=${latlng.lng}`)
      .then(r => r.json())
      .then(data => {
        const name = data.display_name
          ? data.display_name.split(',').slice(0, 2).join(', ')
          : `${latlng.lat.toFixed(4)}, ${latlng.lng.toFixed(4)}`;
        if (BookingUI && typeof BookingUI.setPickupFromMap === 'function') {
          BookingUI.setPickupFromMap(latlng.lat, latlng.lng, name);
        }
      })
      .catch(() => {
        const name = `${latlng.lat.toFixed(4)}, ${latlng.lng.toFixed(4)}`;
        if (BookingUI && typeof BookingUI.setPickupFromMap === 'function') {
          BookingUI.setPickupFromMap(latlng.lat, latlng.lng, name);
        }
      });
  }

  // ── Markers ───────────────────────────────────────────────────
  function setPickup(lat, lng, name) {
    if (pickupMarker) map.removeLayer(pickupMarker);
    pickupMarker = L.marker([lat, lng], { icon: _icon('🟢') })
      .addTo(map)
      .bindPopup(`<b>Pickup</b><br>${name}`, { className: 'custom-popup' });
    pickupMarker.openPopup();
    _fitBounds();
  }

  function setDrop(lat, lng, name) {
    if (dropMarker) map.removeLayer(dropMarker);
    dropMarker = L.marker([lat, lng], { icon: _icon('🔴') })
      .addTo(map)
      .bindPopup(`<b>Drop</b><br>${name}`, { className: 'custom-popup' });
    dropMarker.openPopup();
    _fitBounds();
    _drawRoute();
  }

  // ── Real-time driver position (smooth animation) ───────────────
  let _driverAnimFrame = null;

  function setDriverPosition(lat, lng, name = 'Driver', heading = null) {
    if (!driverMarker) {
      driverMarker = L.marker([lat, lng], { icon: _icon('🏍️', 32) })
        .addTo(map)
        .bindPopup(`<b>${name}</b><br>Your driver`, { className: 'custom-popup' });
    } else {
      // Cancel previous animation
      if (_driverAnimFrame) cancelAnimationFrame(_driverAnimFrame);

      const start  = driverMarker.getLatLng();
      const target = L.latLng(lat, lng);
      const startTime = performance.now();
      const duration  = 1200; // ms — smooth 1.2s interpolation

      function animate(now) {
        const elapsed = now - startTime;
        const frac    = Math.min(elapsed / duration, 1);
        const ease    = 1 - Math.pow(1 - frac, 3); // ease-out cubic

        driverMarker.setLatLng([
          start.lat + (target.lat - start.lat) * ease,
          start.lng + (target.lng - start.lng) * ease,
        ]);

        if (frac < 1) {
          _driverAnimFrame = requestAnimationFrame(animate);
        } else {
          _driverAnimFrame = null;
        }
      }
      _driverAnimFrame = requestAnimationFrame(animate);
    }
  }

  // ── Pulsing ring around driver (real-time feel) ────────────────
  let _pulseLayer = null;

  function _startDriverPulse() {
    // Pulse updated whenever driver marker moves
  }

  function _updateDriverPulse() {
    if (!driverMarker) return;
    const pos = driverMarker.getLatLng();
    if (_pulseLayer) map.removeLayer(_pulseLayer);
    _pulseLayer = L.circleMarker([pos.lat, pos.lng], {
      radius:      22,
      color:       '#FF6B00',
      fillColor:   '#FF6B00',
      fillOpacity: 0.08,
      weight:      2,
      opacity:     0.5,
    }).addTo(map);
  }

  function removeDriver() {
    if (driverMarker) { map.removeLayer(driverMarker); driverMarker = null; }
    if (_pulseLayer)  { map.removeLayer(_pulseLayer);  _pulseLayer  = null; }
    if (_driverAnimFrame) { cancelAnimationFrame(_driverAnimFrame); _driverAnimFrame = null; }
  }

  function clearAll() {
    [pickupMarker, dropMarker, driverMarker, routePolyline, _pulseLayer].forEach(l => {
      if (l) map.removeLayer(l);
    });
    pickupMarker = dropMarker = driverMarker = routePolyline = _pulseLayer = null;
    if (_driverAnimFrame) { cancelAnimationFrame(_driverAnimFrame); _driverAnimFrame = null; }
  }

  // ── Route drawing ─────────────────────────────────────────────
  function _drawRoute() {
    if (!pickupMarker || !dropMarker) return;
    if (routePolyline) map.removeLayer(routePolyline);

    // Try OSRM routing (Hubli–Dharwad area)
    const p = pickupMarker.getLatLng();
    const d = dropMarker.getLatLng();

    fetch(`https://router.project-osrm.org/route/v1/driving/${p.lng},${p.lat};${d.lng},${d.lat}?overview=full&geometries=geojson`)
      .then(r => r.json())
      .then(data => {
        if (data.code === 'Ok' && data.routes[0]) {
          const coords = data.routes[0].geometry.coordinates.map(c => [c[1], c[0]]);
          if (routePolyline) map.removeLayer(routePolyline);
          routePolyline = L.polyline(coords, {
            color:   '#FF6B00',
            weight:  5,
            opacity: 0.8,
          }).addTo(map);
          _fitBounds();
        } else {
          _drawStraightRoute(p, d);
        }
      })
      .catch(() => _drawStraightRoute(p, d));
  }

  function _drawStraightRoute(p, d) {
    if (routePolyline) map.removeLayer(routePolyline);
    routePolyline = L.polyline([p, d], {
      color:     '#FF6B00',
      weight:    4,
      opacity:   0.6,
      dashArray: '10 8',
    }).addTo(map);
    _fitBounds();
  }

  function _fitBounds() {
    const markers = [pickupMarker, dropMarker, driverMarker].filter(Boolean);
    if (!markers.length) return;
    const group = L.featureGroup(markers);
    map.fitBounds(group.getBounds().pad(0.2), { animate: true, duration: 0.8 });
  }

  // ── Geocoding (Hubli–Dharwad biased) ──────────────────────────
  async function geocode(query) {
    const viewbox = '74.85,15.25,75.25,15.55';  // Hubli–Dharwad bounding box
    const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&viewbox=${viewbox}&bounded=0&limit=6&countrycodes=in`;

    try {
      const res  = await fetch(url, { headers: { 'Accept-Language': 'en' } });
      const data = await res.json();
      return data.map(item => ({
        name: item.display_name.split(',').slice(0, 3).join(', '),
        lat:  parseFloat(item.lat),
        lng:  parseFloat(item.lon),
      }));
    } catch {
      return [];
    }
  }

  function getPresets() { return PRESET_LOCATIONS; }
  function getMap()     { return map; }

  function flyTo(lat, lng, zoom = 15) {
    if (map) map.flyTo([lat, lng], zoom, { animate: true, duration: 1 });
  }

  return { init, setPickup, setDrop, setDriverPosition, removeDriver, clearAll, geocode, getPresets, getMap, flyTo };
})();


/* ═══════════════════════════════════════════════════════════════
   REAL-TIME TRACKER  (Socket.IO)
   ═══════════════════════════════════════════════════════════════ */

const Tracker = (() => {
  let socket      = null;
  let currentRide = null;
  let _watchId    = null;
  let _lastUpdate = 0;

  function init() {
    socket = io({ transports: ['websocket', 'polling'] });

    socket.on('connect', () => {
      console.log('[WS] Connected:', socket.id);
      _updateConnectionStatus(true);
    });

    socket.on('disconnect', () => {
      console.log('[WS] Disconnected');
      _updateConnectionStatus(false);
    });

    socket.on('location_update', (data) => {
      const now = Date.now();
      // Throttle UI updates to max 10/sec
      if (now - _lastUpdate < 100) return;
      _lastUpdate = now;

      MapManager.setDriverPosition(data.lat, data.lng);
      _updateProgressBar(data.progress || 0);
      _updateETADisplay(data);
    });

    socket.on('ride_status', (data) => {
      if (!currentRide || currentRide.id !== data.ride_id) return;
      currentRide.status = data.status;
      if (typeof BookingUI !== 'undefined') {
        BookingUI.onStatusUpdate(data);
      }
    });

    socket.on('tracking_started', (data) => {
      console.log('[Tracker] Tracking started for ride', data.ride_id);
    });

    socket.on('error', (data) => {
      console.warn('[Tracker] Socket error:', data.message);
    });
  }

  function startTracking(ride) {
    currentRide = ride;
    if (socket && socket.connected) {
      socket.emit('start_tracking', { ride_id: ride.id });
    } else if (socket) {
      socket.once('connect', () => socket.emit('start_tracking', { ride_id: ride.id }));
    }
    console.log('[Tracker] Start tracking ride', ride.id);
  }

  function stopTracking() {
    if (currentRide && socket) {
      socket.emit('stop_tracking', { ride_id: currentRide.id });
    }
    currentRide = null;
  }

  function _updateProgressBar(progress) {
    const bar = document.getElementById('ride-progress');
    if (bar) bar.style.width = `${progress}%`;
  }

  function _updateETADisplay(data) {
    const eta = document.getElementById('live-eta');
    if (!eta || !data.progress) return;
    const remaining = Math.max(0, Math.round((100 - data.progress) * 0.3));
    eta.textContent = remaining > 0 ? `~${remaining} min away` : 'Arriving…';
  }

  function _updateConnectionStatus(connected) {
    const dot = document.getElementById('ws-status');
    if (!dot) return;
    dot.style.background = connected ? '#22c55e' : '#ef4444';
    dot.title = connected ? 'Live tracking active' : 'Reconnecting…';
  }

  return { init, startTracking, stopTracking };
})();


/* ═══════════════════════════════════════════════════════════════
   GEOCODING (Nominatim — Hubli/Dharwad biased)
   ═══════════════════════════════════════════════════════════════ */

const Geocoder = (() => {
  const cache = {};

  async function search(query) {
    const key = query.toLowerCase();
    if (cache[key]) return cache[key];
    try {
      // Bias toward Hubli-Dharwad region
      const viewbox = '74.85,15.25,75.25,15.55';
      const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query + ', Karnataka, India')}&format=json&limit=6&viewbox=${viewbox}&bounded=0&addressdetails=1`;
      const res  = await fetch(url, { headers: { 'Accept-Language': 'en' } });
      const data = await res.json();
      cache[key] = data;
      return data;
    } catch { return []; }
  }

  return { search };
})();


/* ═══════════════════════════════════════════════════════════════
   LOCATION SEARCH UI (with preset suggestions)
   ═══════════════════════════════════════════════════════════════ */

function setupLocationSearch(inputId, hiddenLatId, hiddenLngId, onSelect) {
  const input = document.getElementById(inputId);
  if (!input) return;

  let dropdown = null;
  let debounce = null;

  input.addEventListener('input', () => {
    clearTimeout(debounce);
    const q = input.value.trim();
    if (!q) { _closeDropdown(); return; }
    if (q.length < 2) {
      // Show presets immediately
      _showResults(MapManager.getPresets().filter(p =>
        p.name.toLowerCase().includes(q.toLowerCase())
      ).map(p => ({ display_name: p.name, lat: p.lat, lon: p.lng })));
      return;
    }
    debounce = setTimeout(async () => {
      // Mix presets + geocoder results
      const presets = MapManager.getPresets()
        .filter(p => p.name.toLowerCase().includes(q.toLowerCase()))
        .map(p => ({ display_name: p.name, lat: p.lat, lon: p.lng, _preset: true }));

      const remote = await Geocoder.search(q);
      const filtered = remote.filter(r =>
        !presets.some(p => p.display_name === r.display_name)
      );
      _showResults([...presets, ...filtered].slice(0, 7));
    }, 350);
  });

  input.addEventListener('focus', () => {
    if (!input.value.trim()) {
      // Show all presets on empty focus
      _showResults(MapManager.getPresets().map(p => ({
        display_name: p.name, lat: p.lat, lon: p.lng, _preset: true,
      })));
    }
  });

  input.addEventListener('blur', () => setTimeout(_closeDropdown, 200));

  function _showResults(results) {
    _closeDropdown();
    if (!results.length) return;

    dropdown = document.createElement('div');
    dropdown.className = 'suggestions-dropdown';
    dropdown.style.cssText = `
      position:absolute; z-index:1000; width:100%;
      background:var(--bg-elevated); border:1px solid var(--border);
      border-radius:var(--radius-md); margin-top:4px;
      box-shadow:var(--shadow-card); overflow:hidden; max-height:260px; overflow-y:auto;`;

    results.forEach(r => {
      const item = document.createElement('div');
      item.style.cssText = `
        padding:0.6rem 1rem; cursor:pointer; font-size:0.83rem;
        display:flex;align-items:center;gap:0.5rem;
        border-bottom:1px solid var(--border); transition:background .15s;`;
      const shortName = r.display_name.split(',').slice(0, 2).join(', ');
      item.innerHTML = `<span style="opacity:.6">${r._preset ? '📍' : '🔍'}</span><span>${shortName}</span>`;
      item.addEventListener('mouseenter', () => item.style.background = 'var(--bg-input)');
      item.addEventListener('mouseleave', () => item.style.background = '');
      item.addEventListener('mousedown', () => {
        input.value = shortName;
        document.getElementById(hiddenLatId).value = r.lat;
        document.getElementById(hiddenLngId).value = r.lon || r.lng;
        _closeDropdown();
        onSelect(parseFloat(r.lat), parseFloat(r.lon || r.lng), shortName);
      });
      dropdown.appendChild(item);
    });

    const wrap = input.closest('.input-wrap') || input.parentElement;
    wrap.style.position = 'relative';
    wrap.appendChild(dropdown);
  }

  function _closeDropdown() {
    if (dropdown) { dropdown.remove(); dropdown = null; }
  }
}


/* ═══════════════════════════════════════════════════════════════
   BOOKING UI
   ═══════════════════════════════════════════════════════════════ */

const BookingUI = (() => {
  let currentRide  = null;
  let pickupCoords = null;
  let dropCoords   = null;
  let _mapClickMode = null; // 'pickup' | 'drop' | null

  function init() {
    _renderBookingForm();
    _bindLocationSearch();
  }

  function _bindLocationSearch() {
    setupLocationSearch('pickup-input', 'pickup-lat', 'pickup-lng', (lat, lng, name) => {
      pickupCoords = { lat, lng, name };
      MapManager.setPickup(lat, lng, name);
      _updateEstimate();
    });
    setupLocationSearch('drop-input', 'drop-lat', 'drop-lng', (lat, lng, name) => {
      dropCoords = { lat, lng, name };
      MapManager.setDrop(lat, lng, name);
      _updateEstimate();
    });
  }

  // Called from MapManager double-tap
  function setPickupFromMap(lat, lng, name) {
    pickupCoords = { lat, lng, name };
    MapManager.setPickup(lat, lng, name);
    const inp = document.getElementById('pickup-input');
    if (inp) inp.value = name;
    _updateEstimate();
  }

  // Single-tap on map → set drop if pickup is already set
  function onMapClick(latlng) {
    if (!pickupCoords) return;
    if (dropCoords) return; // already have both
    fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latlng.lat}&lon=${latlng.lng}`)
      .then(r => r.json())
      .then(data => {
        const name = data.display_name
          ? data.display_name.split(',').slice(0, 2).join(', ')
          : `${latlng.lat.toFixed(4)}, ${latlng.lng.toFixed(4)}`;
        dropCoords = { lat: latlng.lat, lng: latlng.lng, name };
        MapManager.setDrop(latlng.lat, latlng.lng, name);
        const inp = document.getElementById('drop-input');
        if (inp) inp.value = name;
        _updateEstimate();
      });
  }

  function resetBooking() {
    currentRide = pickupCoords = dropCoords = null;
    _renderBookingForm(true);
    _bindLocationSearch();
    const btn = document.getElementById('book-btn');
    if (btn) btn.disabled = true;
    const est = document.getElementById('estimate-card');
    if (est) est.style.display = 'none';
    const status = document.getElementById('ride-status-panel');
    if (status) status.innerHTML = '';
    Tracker.stopTracking();
  }

  function _renderBookingForm(force = false) {
    const panel = document.getElementById('booking-panel');
    if (!panel) return;

    // If already rendered (pre-rendered in HTML), skip unless forced
    if (!force && document.getElementById('pickup-input')) return;

    panel.innerHTML = `
      <div style="display:flex;flex-direction:column;gap:1rem;">
        <!-- Live connection indicator -->
        <div style="display:flex;align-items:center;gap:0.5rem;font-size:0.75rem;color:var(--text-muted);">
          <span id="ws-status" style="width:8px;height:8px;border-radius:50%;background:#ef4444;display:inline-block;" title="Connecting…"></span>
          <span>Live tracking</span>
          <span style="margin-left:auto;font-size:0.7rem;opacity:.6;">Double-tap map = new ride</span>
        </div>

        <!-- Pickup -->
        <div class="form-group">
          <label class="form-label">📍 Pickup Location</label>
          <div class="input-wrap">
            <span class="input-icon">🟢</span>
            <input class="form-input has-icon" id="pickup-input"
              type="text" placeholder="Search Hubli / Dharwad…"
              autocomplete="off"/>
            <input type="hidden" id="pickup-lat"/>
            <input type="hidden" id="pickup-lng"/>
          </div>
        </div>

        <!-- Drop -->
        <div class="form-group">
          <label class="form-label">🏁 Drop Location</label>
          <div class="input-wrap">
            <span class="input-icon">🔴</span>
            <input class="form-input has-icon" id="drop-input"
              type="text" placeholder="Where to? (or tap map)"
              autocomplete="off"/>
            <input type="hidden" id="drop-lat"/>
            <input type="hidden" id="drop-lng"/>
          </div>
        </div>

        <!-- Quick presets row -->
        <div style="display:flex;gap:0.4rem;flex-wrap:wrap;">
          <button class="btn btn-ghost btn-sm" onclick="BookingUI.quickSet('hubli_station')" style="font-size:0.72rem;">🚂 Hubli Stn</button>
          <button class="btn btn-ghost btn-sm" onclick="BookingUI.quickSet('dharwad_bs')"   style="font-size:0.72rem;">🚌 Dwd Bus Std</button>
          <button class="btn btn-ghost btn-sm" onclick="BookingUI.quickSet('airport')"       style="font-size:0.72rem;">✈️ Airport</button>
          <button class="btn btn-ghost btn-sm" onclick="BookingUI.quickSet('kle')"           style="font-size:0.72rem;">🎓 KLE Univ</button>
        </div>

        <!-- Estimate card -->
        <div id="estimate-card" style="display:none;" class="card animate-fade-in">
          <div class="card-title">💰 Fare Estimate</div>
          <div class="stats-row">
            <div class="stat-chip"><span class="label">Distance</span><span class="value" id="est-dist">—</span></div>
            <div class="stat-chip"><span class="label">ETA</span><span class="value" id="est-time">—</span></div>
            <div class="stat-chip"><span class="label">Fare</span><span class="value" id="est-fare" style="color:var(--accent);">—</span></div>
          </div>
        </div>

        <!-- Book button -->
        <button class="btn btn-primary btn-lg" id="book-btn" onclick="BookingUI.bookRide()" disabled>
          🏍️ Book Ride
        </button>

        <!-- Ride status -->
        <div id="ride-status-panel"></div>
      </div>`;
  }

  // Quick preset setter
  const _QUICK = {
    hubli_station: { name: 'Hubli Railway Station', lat: 15.3297, lng: 75.1352 },
    dharwad_bs:    { name: 'Dharwad Bus Stand',     lat: 15.4589, lng: 74.9869 },
    airport:       { name: 'Hubli Airport',          lat: 15.3613, lng: 75.0849 },
    kle:           { name: 'KLE Technological University', lat: 15.3781, lng: 75.1265 },
  };

  let _bothSetToastTimer = null;

  function quickSet(key) {
    const loc = _QUICK[key];
    if (!loc) return;
    if (!pickupCoords) {
      pickupCoords = loc;
      MapManager.setPickup(loc.lat, loc.lng, loc.name);
      const inp = document.getElementById('pickup-input');
      if (inp) inp.value = loc.name;
    } else if (!dropCoords) {
      dropCoords = loc;
      MapManager.setDrop(loc.lat, loc.lng, loc.name);
      const inp = document.getElementById('drop-input');
      if (inp) inp.value = loc.name;
      _updateEstimate();
    } else {
      // Guard: only show this toast once every 3 seconds to prevent spam
      if (!_bothSetToastTimer) {
        Toast.info('Both locations already set. Double-tap map for new ride.');
        _bothSetToastTimer = setTimeout(() => { _bothSetToastTimer = null; }, 3000);
      }
    }
  }

  async function _updateEstimate() {
    if (!pickupCoords || !dropCoords) return;

    function _haversineKm(lat1, lng1, lat2, lng2) {
      const R = 6371, dLat = (lat2-lat1)*Math.PI/180, dLng = (lng2-lng1)*Math.PI/180;
      const a = Math.sin(dLat/2)**2 + Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLng/2)**2;
      return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    }

    function _showEstimate(distKm, durationMin, fare) {
      document.getElementById('est-dist').textContent = formatDist(distKm);
      document.getElementById('est-time').textContent = `${Math.round(durationMin)} min`;
      document.getElementById('est-fare').textContent = formatCurrency(fare);
      document.getElementById('estimate-card').style.display = 'block';
      document.getElementById('book-btn').disabled = false;
      window._bookingPickupLat = pickupCoords.lat;
      window._bookingPickupLng = pickupCoords.lng;
      window._bookingDropLat   = dropCoords.lat;
      window._bookingDropLng   = dropCoords.lng;
      if (typeof window.onBookingFormReady === 'function') window.onBookingFormReady();
    }

    try {
      const res = await API.post('/api/estimate', {
        pickup_lat: pickupCoords.lat, pickup_lng: pickupCoords.lng,
        drop_lat:   dropCoords.lat,   drop_lng:   dropCoords.lng,
      });
      if (res.success && res.options && res.options.length) {
        const opt = res.options.find(o => o.vehicle_type === 'Bike') || res.options[0];
        _showEstimate(opt.distance_km, opt.duration_min, opt.fare);
        return;
      }
    } catch (e) {
      console.warn('[BookingUI] /api/estimate failed, using local fallback:', e);
    }

    // Fallback: compute locally so the card always appears
    const distKm      = _haversineKm(pickupCoords.lat, pickupCoords.lng, dropCoords.lat, dropCoords.lng) * 1.3;
    const durationMin = distKm / 30 * 60;
    const fare        = Math.max(30, Math.round(distKm * 12));
    _showEstimate(distKm, durationMin, fare);
  }

  async function bookRide() {
    if (!Auth.getUser()) { Auth.open('login'); return; }
    if (!pickupCoords || !dropCoords) {
      Toast.error('Please select pickup and drop locations.');
      return;
    }
    const btn = document.getElementById('book-btn');
    setButtonLoading(btn, true);

    const extra = (typeof window._bookingExtraData === 'function') ? window._bookingExtraData() : {};
    const res = await API.post('/api/book-ride', {
      ...extra,
      pickup_name: pickupCoords.name,
      pickup_lat:  pickupCoords.lat,
      pickup_lng:  pickupCoords.lng,
      drop_name:   dropCoords.name,
      drop_lat:    dropCoords.lat,
      drop_lng:    dropCoords.lng,
    });

    setButtonLoading(btn, false, '🏍️ Book Ride');

    if (!res.success) { Toast.error(res.message); return; }

    currentRide = res.ride;
    Toast.success(`Ride booked! 🔐 Your PIN: ${res.ride.ride_pin} — share with driver`);
    btn.disabled = true;

    _renderRideStatus(currentRide);
    Tracker.startTracking(currentRide);
  }

  function onStatusUpdate(data) {
    if (!currentRide || currentRide.id !== data.ride_id) return;
    currentRide.status = data.status;
    _renderRideStatus(currentRide);

    const messages = {
      ongoing:   '🚀 Your ride has started!',
      completed: '✅ Arrived! Ride completed.',
      cancelled: '❌ Ride was cancelled.',
    };
    if (messages[data.status]) {
      const type = data.status === 'completed' ? 'success'
                 : data.status === 'cancelled' ? 'error' : 'info';
      Toast[type](messages[data.status]);
    }

    if (data.status === 'completed' || data.status === 'cancelled') {
      Tracker.stopTracking();
      setTimeout(() => {
        MapManager.removeDriver();
        const btn = document.getElementById('book-btn');
        if (btn) btn.disabled = false;
        if (data.status === 'completed') {
          Toast.info('Double-tap the map to start a new ride!');
        }
      }, 3000);
    }
  }

  function _renderRideStatus(ride) {
    const panel = document.getElementById('ride-status-panel');
    if (!panel) return;
    const d = ride.driver;
    const statusMap = {
      requested: { label: 'Finding Driver',  class: 'badge-requested', icon: '⏳' },
      accepted:  { label: 'Driver Coming',   class: 'badge-accepted',  icon: '🏍️' },
      ongoing:   { label: 'On the Way',      class: 'badge-ongoing',   icon: '🚀' },
      completed: { label: 'Completed',        class: 'badge-completed', icon: '✅' },
      cancelled: { label: 'Cancelled',        class: 'badge-cancelled', icon: '❌' },
    };
    const s = statusMap[ride.status] || statusMap.requested;

    panel.innerHTML = `
      <div class="ride-status-card">
        <div class="ride-status-header">
          <div>
            <div style="font-size:.75rem;opacity:.8;font-weight:600;">RIDE #${ride.id}</div>
            <div class="ride-status-badge ${s.class}" style="margin-top:4px;">${s.icon} ${s.label}</div>
          </div>
          ${ride.status === 'accepted' || ride.status === 'ongoing'
            ? `<button class="btn btn-danger btn-sm" onclick="BookingUI.cancelRide(${ride.id})">Cancel</button>`
            : ''}
        </div>

        ${ride.status === 'accepted' && ride.ride_pin ? `
        <div style="background:linear-gradient(135deg,#1a0a2e,#0d1b2a);border:2px solid var(--accent);border-radius:14px;padding:0.9rem 1rem;margin:0.75rem 0;text-align:center;">
          <div style="font-size:0.7rem;text-transform:uppercase;letter-spacing:1.5px;color:var(--text-muted);margin-bottom:0.3rem;">🔐 Your Ride PIN — Share with driver to start</div>
          <div style="font-size:2.2rem;font-weight:900;letter-spacing:0.35em;color:var(--accent);font-family:'Syne',sans-serif;">${ride.ride_pin}</div>
          <div style="font-size:0.68rem;color:var(--text-muted);margin-top:0.25rem;">Do NOT share with anyone other than your driver</div>
        </div>` : ''}

        <div class="ride-status-body">
          ${d ? `<div class="driver-info">
            <div class="driver-avatar">🧑‍✈️</div>
            <div class="driver-details">
              <h4>${d.name}</h4>
              <span>${d.vehicle_type} · ${d.vehicle} · ⭐ ${d.rating}</span>
            </div>
          </div>` : ''}

          <div style="display:flex;align-items:center;gap:0.5rem;margin:.5rem 0;font-size:.75rem;color:var(--text-muted);">
            <span id="ws-status2" style="width:7px;height:7px;border-radius:50%;background:#22c55e;display:inline-block;"></span>
            <span id="live-eta">Calculating ETA…</span>
          </div>

          <div class="progress-bar-wrap">
            <div class="progress-bar" id="ride-progress" style="width:${_progress(ride.status)}%;transition:width 1s ease;"></div>
          </div>

          <div class="route-info">
            <div class="route-point">
              <div class="route-dot pickup"></div>
              <span>${(ride.pickup_name || '').slice(0, 50)}</span>
            </div>
            <div class="route-line-connector" style="margin-left:4px;"></div>
            <div class="route-point">
              <div class="route-dot dropoff"></div>
              <span>${(ride.drop_name || '').slice(0, 50)}</span>
            </div>
          </div>

          <div class="stats-row">
            <div class="stat-chip"><span class="label">Distance</span><span class="value">${formatDist(ride.distance_km)}</span></div>
            <div class="stat-chip"><span class="label">ETA</span><span class="value">${Math.round(ride.duration_min)} min</span></div>
          </div>
          <div class="fare-row">
            <span class="fare-label">Estimated Fare</span>
            <span class="fare-value">${formatCurrency(ride.fare)}</span>
          </div>
        </div>
      </div>`;

    if (d) MapManager.setDriverPosition(d.lat, d.lng, d.name);
  }

  function _progress(status) {
    return { requested: 5, accepted: 30, ongoing: 65, completed: 100, cancelled: 0 }[status] || 0;
  }

  async function cancelRide(rideId) {
    const res = await API.post(`/api/rides/${rideId}/cancel`);
    if (!res.success) { Toast.error(res.message); return; }
    Tracker.stopTracking();
    Toast.info('Ride cancelled.');
    if (currentRide) currentRide.status = 'cancelled';
    _renderRideStatus(currentRide || { id: rideId, status: 'cancelled' });
    MapManager.removeDriver();
    setTimeout(() => {
      const btn = document.getElementById('book-btn');
      if (btn) btn.disabled = false;
    }, 2000);
  }

  return { init, bookRide, cancelRide, setPickupFromMap, onMapClick, onStatusUpdate, resetBooking, quickSet };
})();

// ── Self-init fallback: render booking form as soon as map.js loads ──
// This ensures the form is visible even if app.js has issues.
document.addEventListener('DOMContentLoaded', () => {
  const panel = document.getElementById('booking-panel');
  if (panel && panel.innerHTML.trim() === '') {
    try { BookingUI.init(); } catch(e) { console.error('[map.js fallback] BookingUI.init error:', e); }
  }
});
