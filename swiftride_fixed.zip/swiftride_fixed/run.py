"""
Entry point — run with:  python run.py
Or use start.bat / run_all_terminals.bat on Windows.
"""

import logging
import os

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)

# Suppress noisy werkzeug/socketio logs in dev
logging.getLogger("werkzeug").setLevel(logging.WARNING)
logging.getLogger("engineio").setLevel(logging.WARNING)
logging.getLogger("socketio").setLevel(logging.WARNING)

from backend.app import create_app
from backend.extensions import socketio

app = create_app()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print(f"\n{'═'*55}")
    print(f"  🏍️  SWIFTRIDE — Hubli / Dharwad")
    print(f"  Running at  http://localhost:{port}")
    print(f"  Double-tap the map to start a new ride")
    print(f"  Login/Register with email or Indian phone number")
    print(f"{'═'*55}\n")

    socketio.run(
        app,
        host="0.0.0.0",
        port=port,
        debug=app.config.get("DEBUG", True),
        use_reloader=False,   # prevents double-seeding on reload
        allow_unsafe_werkzeug=True,
    )
